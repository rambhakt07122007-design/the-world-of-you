const fs = require('fs');
const zlib = require('zlib');

fs.mkdirSync('dist', { recursive: true });
if (fs.existsSync('index.html.gz')) {
  fs.writeFileSync('dist/index.html', zlib.gunzipSync(fs.readFileSync('index.html.gz')));
} else if (fs.existsSync('index.html')) {
  fs.copyFileSync('index.html', 'dist/index.html');
  if (fs.existsSync('chunks')) {
    fs.cpSync('chunks', 'dist/chunks', { recursive: true });
  }
}
