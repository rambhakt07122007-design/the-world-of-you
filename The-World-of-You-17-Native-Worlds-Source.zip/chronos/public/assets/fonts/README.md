# Self-hosted typefaces

These Latin-subset variable WOFF2 files are served locally to keep the experience functional without runtime font-CDN requests. They are sourced from the Google Fonts distribution for the named families and supplied under the SIL Open Font License 1.1. The matching license texts are included beside the font files.
