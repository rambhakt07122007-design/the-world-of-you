# Verified obsolete gift art removed

These JSX subtrees were explicitly hidden after native replacements. Their actions were duplicated by retained accessible controls; no content-source module changed. Corresponding legacy decorative CSS is removed only for the listed selectors.

- `<div className={`gift-letter__desk${open ? " is-open" : ""}`} hidden>`
- `<div className={`gift-flower__landscape growth-${stage}`} hidden>`
- `<div hidden className={`gift-cassette__deck${inserted ? " has-cassette" : ""}${audio.playing ? " is-playing" : ""}`}>`
- `<div hidden className="gift-wishes__sky">`
- `<div className="gift-crown__palace" hidden>`
- `<div hidden className={`gift-machine__workshop${running ? " is-running" : ""}`}>`
- `<div hidden className="gift-vinyl__studio">`
- `<div hidden className={`gift-future-garden__landscape growth-${growth}`}>`
- `<div className="gift-ultimate__sky" hidden><div className="gift-ultimate__portal" />`