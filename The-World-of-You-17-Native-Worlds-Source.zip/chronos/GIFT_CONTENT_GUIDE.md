# Gift Content Guide

**Updated:** 3 November 2026

## Sources of truth

- `src/content/giftsContent.ts` — names, experience IDs, gift presentation, blank private-copy slots and readiness flags.
- `src/content/chronosContent.ts` — verified relationship dates, the existing source letter and messages, ten source wishes, gallery/audio slots, speculative postcards and finale source copy.

The experience code reads these modules directly. Do not copy personal text into component JSX; keep approved copy in content data so it remains reviewable and editable.

## Editable slots currently waiting for owner copy

| File / field | Slots | Rules |
|---|---:|---|
| `reasonNotes[].text` | 17 | Add only reasons the author chooses to say. Do not infer personality traits or memories. |
| `openWhenLetters[].message` | 4 | The prompts are present; write an actual private letter for each, or leave it blank. |
| `couponEntries[].title` / `description` | 6 | Add only offers/promises explicitly approved by the owner. Blank coupons are intentionally not redeemable. |
| `futureGardenLeaves[].text` | 8 | Future hopes only; do not present them as plans, events or promises. |
| `chronosContent.music.tracks[].src` | 3 | Use a local, properly licensed or owner-provided audio file. Never autoplay. |
| `chronosContent.gallery.photos[].src` / `caption` | 6 | Use genuine owner-supplied photos and accurate captions only. No generated substitute or invented date. |
| Gift 03 hidden message | 1 | Add a short owner-written message only after supplied. |
| Gift 05 voice recording/transcript | 1 | Real recording and a text alternative/captions are required before playback is enabled. |

## Source copy reused by the experiences

- Gift 01 displays the existing birthday letter from `chronosContent.letters.letters[0]`; do not alter its attribution without owner direction.
- Gift 04 shows only the verified dates in `chronosContent.dates.firstConnectionLabel` and `proposalLabel`.
- Gifts 07 and 10 may reveal only the ten wishes in `chronosContent.flowerGarden.wishes`.
- Gift 08, Gift 16 and Gift 17 reuse existing archive messages rather than creating new private claims.
- Gift 11 uses four existing generated postcard scenes. Keep their “possible future / not a fact” framing.

## Adding an audio recording safely

1. Obtain a recording the owner supplied and approved; do not generate a voice clone or synthetic personal message.
2. Add the local file under `public/assets/audio/` and use a relative URL such as `/assets/audio/voice-note-01.mp3` in the corresponding track source.
3. Add a transcript/caption in the content source. Keep the player paused on load and require a user Play action.
4. Test play, pause, stop, seek/volume where available, error handling, dialog close/unmount cleanup, keyboard operation and reduced motion. Do not fetch remote audio.
5. Verify that an empty `src` still results in disabled controls and no failed network request.

## Adding photographs or personal content

- Add only owner-provided photographs to `public/assets/gallery/`; supply truthful alt text, a caption and a date only if the date is verified.
- Keep placeholder fields explicitly empty until real files/copy exist. Do not use generated portraits, fake memories, fabricated conversations, unapproved promises or unverified dates.
- Bhumi’s birthday year remains unspecified. Keep future-postcard and future-garden copy speculative unless a real, mutual hope is supplied.
