from pathlib import Path
from PIL import Image
for path in Path('public/assets/gift-previews').glob('*.png'):
    Image.open(path).save(path.with_suffix('.webp'), 'WEBP', quality=85, method=6)
    path.unlink()
