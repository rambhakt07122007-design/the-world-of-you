import { chromium, request, expect } from '@playwright/test';
import fs from 'node:fs/promises';
const url='https://the-world-of-you-birthday-storybook.vercel.app';
const http=await request.newContext();
await expect.poll(async()=>{const r=await http.get(url);return r.ok()&&(await r.text()).includes('/assets/index-DCop_qA0.js');},{timeout:90000,intervals:[2000,4000,6000]}).toBe(true);
const browser=await chromium.launch({args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1280,height:900},reducedMotion:'reduce'});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto(url+'/#flower-garden');const garden=page.locator('#flower-garden');await garden.locator('.cinematic-viewport').scrollIntoViewIfNeeded();
 await expect(garden.locator('.cinematic-viewport__status')).toHaveText('Real-time 3D ready',{timeout:45000});
 await garden.getByRole('button',{name:'Release wish 1',exact:true}).click();
 await expect(garden.locator('.conservatory-wish')).toContainText('WISH 01');
 expect(errors).toEqual([]);
 const result={url,latestEntry:'/assets/index-DCop_qA0.js',http:200,garden3DRendered:true,wishSelectionPassed:true,pageErrors:errors,scope:'Desktop Chromium smoke only; not full hosted regression or hardware microphone testing'};
 await fs.writeFile('qa-production.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{await browser.close();await http.dispose();}
