from pathlib import Path
import tarfile,hashlib,json
with tarfile.open('/home/user/backups/chronos-before-letter-refinement.tar.gz') as t:
 result=[]
 for p in Path('src/content').glob('*.ts'):
  old=t.extractfile('./'+str(p)).read();result.append({'file':str(p),'unchanged':hashlib.sha256(old).digest()==hashlib.sha256(p.read_bytes()).digest()})
 Path('qa-letter-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(result)
