import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
const browser = await chromium.launch({ args: ['--no-sandbox'] });
try {
  const page = await browser.newPage();
  await page.goto('http://localhost:4181/', { waitUntil: 'networkidle' });
  // Resolve the offline-only exporter before beginning the actual file loop.
  try { await page.evaluate(() => import('/src/three/exportModels.ts')); }
  catch (error) {
    if (!String(error).includes('Execution context was destroyed')) throw error;
    await page.waitForLoadState('networkidle');
    await page.evaluate(() => import('/src/three/exportModels.ts'));
  }
  await fs.mkdir('public/assets/models', { recursive: true });
  for (const name of ['garden', 'cake', 'letter-desk', 'eternal-rose', 'crown', 'portal', 'observatory']) {
    const base64 = await page.evaluate(async (name) => { const module = await import('/src/three/exportModels.ts'); return module.exportModel(name); }, name);
    const bytes = Buffer.from(base64, 'base64');
    if (bytes.toString('utf8', 0, 4) !== 'glTF') throw new Error('Invalid GLB output');
    await fs.writeFile(`public/assets/models/${name}.glb`, bytes);
    console.log(`${name}.glb: ${bytes.length} bytes`);
  }
} finally { await browser.close(); }
