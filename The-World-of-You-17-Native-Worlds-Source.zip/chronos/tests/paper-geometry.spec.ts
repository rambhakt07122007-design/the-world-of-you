import {test,expect} from '@playwright/test';
import {createFoldedPaper} from '../src/three/letter';
test('paper geometry: closed thickness surface, rounded crease transport and stable width',()=>{
 const {geometry,deform}=createFoldedPaper();const edges=new Map<string,number>();const index=geometry.index!;
 for(let i=0;i<index.count;i+=3){const triangle=[index.getX(i),index.getX(i+1),index.getX(i+2)];for(let j=0;j<3;j++){const a=triangle[j],b=triangle[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');edges.set(key,(edges.get(key)??0)+1);}}
 expect([...edges.values()].every(n=>n===2)).toBe(true);
 const spans=[];for(const [upper,lower] of [[0,0],[.5,0],[1,.5],[1,1]]){deform(upper,lower);geometry.computeBoundingBox();const b=geometry.boundingBox!;spans.push({x:b.max.x-b.min.x,y:b.max.y-b.min.y,z:b.max.z-b.min.z});expect([...geometry.attributes.position.array].every(Number.isFinite)).toBe(true);expect([...geometry.attributes.normal.array].every(Number.isFinite)).toBe(true);}
 expect(spans[0].y).toBeLessThan(1.1);expect(spans[3].y).toBeCloseTo(2.79,2);expect(spans[3].z).toBeLessThan(.03);expect(spans[1].z).toBeGreaterThan(.2);for(const s of spans)expect(s.x).toBeCloseTo(2.06,2);geometry.dispose();
});
