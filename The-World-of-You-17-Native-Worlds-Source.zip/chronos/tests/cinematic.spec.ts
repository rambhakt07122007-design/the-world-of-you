import { test, expect } from "@playwright/test";
import { isBlowLike } from "../src/hooks/useBlowDetection";

const errors: string[] = [];
test.beforeEach(async ({ page }) => { errors.length = 0; page.on("pageerror", (error) => errors.push(error.message)); page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); }); });
test.afterEach(async () => { expect(errors).toEqual([]); });

test("airflow classifier rejects quiet, tonal and low-band signals", () => {
  expect(isBlowLike(0.01, 0.01, 0.5, 0.01)).toBe(false);
  expect(isBlowLike(0.15, 0.01, 0.5, 0.8)).toBe(false);
  expect(isBlowLike(0.15, 0.01, 0.05, 0.01)).toBe(false);
  expect(isBlowLike(0.15, 0.01, 0.5, 0.01)).toBe(true);
});

test("garden: 3D rendering, ten wishes, planting, replay and removal", async ({ page }) => {
  await page.goto("/#flower-garden");
  const garden = page.locator("#flower-garden");
  await garden.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(garden.locator(".cinematic-viewport__status")).toHaveText("Real-time 3D ready");
  await expect(garden.locator("canvas")).toHaveCount(1);
  for (let i = 1; i <= 10; i++) { await garden.getByRole("button", { name: `Release wish ${i}`, exact: true }).click(); await expect(garden.locator(".conservatory-wish")).toContainText(`WISH ${String(i).padStart(2, "0")}`); }
  await garden.getByLabel("Your wish").fill("A quiet day with more time outside.");
  await garden.getByRole("button", { name: "Plant my wish", exact: true }).click();
  await expect(garden.locator(".conservatory-wish")).toContainText("A quiet day with more time outside.");
  await garden.getByRole("button", { name: "Replay bloom" }).click();
  await garden.getByRole("button", { name: "Close wish" }).click();
  await garden.getByRole("button", { name: "My wish", exact: true }).click();
  await garden.getByRole("button", { name: "Remove my wish" }).click();
  await expect(garden.getByRole("button", { name: "My wish", exact: true })).toHaveCount(0);
  await garden.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(garden.locator(".cinematic-viewport__canvas")).toHaveAttribute("data-scene-active", "true");
  await page.screenshot({ path: "qa/garden-desktop.png" });
});

test("cake: all baking stages, light, manual wish/blowout and replay", async ({ page }) => {
  await page.goto("/#birthday-cake"); const cake = page.locator("#birthday-cake");
  await cake.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(cake.locator(".cinematic-viewport__status")).toHaveText("Real-time 3D ready");
  await expect(cake.getByRole("button", { name: "Light the candles", exact: true })).toBeDisabled();
  for (let i = 1; i <= 4; i++) { await cake.getByRole("button", { name: new RegExp(`^Step ${i}:`) }).click(); await expect(cake.locator(".cake-bake-journey__current")).toContainText(`STEP ${i} OF 4`); }
  await cake.getByRole("button", { name: "Light the candles", exact: true }).click();
  await expect(cake.getByRole("button", { name: "Blow them out", exact: true })).toBeEnabled();
  await cake.locator(".cinematic-viewport").screenshot({ path: "qa/cake-lit.png" });
  await cake.getByRole("button", { name: "Make a wish", exact: true }).click();
  await expect(cake.locator(".cake-ritual__status")).toContainText("Candles out");
  await expect(cake.locator(".cake-fireworks")).not.toHaveClass(/is-bursting/);
  await cake.getByRole("button", { name: "Light the candles", exact: true }).click();
  await cake.getByRole("button", { name: "Blow them out", exact: true }).click();
  await expect(cake.locator(".cake-ritual__status")).toContainText("Candles out");
});

test("letters: folded paper renders; open, fold, reopen, escape and focus return", async ({ page }) => {
  await page.goto("/#letters"); const opener = page.locator(".letter-envelope").first(); await opener.click();
  const dialog = page.locator("dialog[open]"); await expect(dialog).toBeVisible();
  await expect(dialog.locator(".cinematic-viewport__status")).toHaveText("Real-time 3D ready");
  await expect(dialog.locator(".physical-letter-copy")).toBeHidden();
  await dialog.getByRole("button", { name: "Open Letter" }).click();
  await expect(dialog.locator(".physical-letter-copy")).toBeVisible();
  await dialog.locator(".cinematic-viewport").screenshot({ path: "qa/letter-open.png" });
  await dialog.getByRole("button", { name: "Close Letter" }).click();
  await expect(dialog.locator(".physical-letter-copy")).toBeHidden();
  await dialog.getByRole("button", { name: "Open Letter" }).click();
  await page.keyboard.press("Escape"); await expect(dialog).toHaveCount(0); await expect(opener).toBeFocused();
});

test("all 17 existing gifts open, run their primary control, reset and close", async ({ page }) => {
  test.setTimeout(360000);
  await page.goto("/#gifts"); const buttons = page.locator(".gift-parcel"); await expect(buttons).toHaveCount(17);
  for (let i = 0; i < 17; i++) {
    await buttons.nth(i).click(); const dialog = page.locator("dialog[open]"); await expect(dialog).toBeVisible();
    await expect(dialog.locator(".gift-experience")).toBeVisible();
    const control = dialog.locator(".gift-control--primary:enabled").first();
    if (await control.count()) await control.click();
    const replay = dialog.locator(".gift-experience-shell__footer button").first();
    if (await replay.count()) await replay.click();
    await dialog.getByRole("button", { name: "Close dialog", exact: true }).click();
    await expect(page.locator("dialog[open]")).toHaveCount(0);
    await expect(page.locator("dialog canvas")).toHaveCount(0);
  }
});

test("microphone denial is recoverable; manual fallback still works", async ({ page }) => {
  await page.addInitScript(() => { navigator.mediaDevices.getUserMedia = async () => { throw new DOMException("Denied for test", "NotAllowedError"); }; });
  await page.goto("/#birthday-cake"); const cake = page.locator("#birthday-cake");
  await cake.getByRole("button", { name: "Skip to finished cake" }).click();
  await cake.getByRole("button", { name: "Light the candles", exact: true }).click();
  await cake.getByRole("button", { name: "Enable microphone for this wish" }).click();
  await expect(cake.locator("#mic-privacy")).toContainText("Permission denied");
  await cake.getByRole("button", { name: "Blow them out", exact: true }).click();
  await expect(cake.locator(".cake-ritual__status")).toContainText("Candles out");
});

test("synthetic broadband input triggers calibrated mic and stops tracks", async ({ page }) => {
  await page.addInitScript(() => {
    const w = window as unknown as { stoppedTracks: number; testAudio?: AudioContext; testGain?: GainNode }; w.stoppedTracks = 0;
    navigator.mediaDevices.getUserMedia = async () => {
      const audio = new AudioContext(); w.testAudio = audio; const output = audio.createMediaStreamDestination();
      const gain = audio.createGain(); gain.gain.value = 0; gain.connect(output);
      const noise = audio.createBufferSource(); const buffer = audio.createBuffer(1, audio.sampleRate * 2, audio.sampleRate);
      const samples = buffer.getChannelData(0); for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      noise.buffer = buffer; noise.loop = true; noise.connect(gain); noise.start(); await audio.resume();
      w.testGain = gain;
      const track = output.stream.getTracks()[0]; const original = track.stop.bind(track); track.stop = () => { w.stoppedTracks++; original(); void audio.close(); };
      return output.stream;
    };
  });
  await page.goto("/#birthday-cake"); const cake = page.locator("#birthday-cake");
  await cake.getByRole("button", { name: "Skip to finished cake" }).click(); await cake.getByRole("button", { name: "Light the candles", exact: true }).click();
  await cake.getByRole("button", { name: "Enable microphone for this wish" }).click();
  await expect(cake.locator("#mic-privacy")).toContainText("Take a deep breath", { timeout: 12000 });
  await page.evaluate(() => { (window as unknown as { testGain: GainNode }).testGain.gain.value = 0.2; });
  await expect(cake.locator(".cake-ritual__status")).toContainText("Candles out", { timeout: 22000 });
  expect(await page.evaluate(() => (window as unknown as { stoppedTracks: number }).stoppedTracks)).toBe(1);
  console.log("Synthetic mic graphics fallback:", await page.locator("[data-graphics-failure]").count());
});

test("responsive portrait/landscape/tablet: no horizontal overflow, keyboard wish control", async ({ page }) => {
  for (const size of [{ width: 390, height: 844 }, { width: 844, height: 390 }, { width: 768, height: 1024 }]) {
    await page.setViewportSize(size); await page.goto("/#flower-garden");
    const button = page.getByRole("button", { name: "Release wish 1", exact: true }); await button.focus(); await page.keyboard.press("Enter");
    await expect(button).toHaveAttribute("aria-pressed", "true");
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    await page.screenshot({ path: `qa/garden-${size.width}x${size.height}.png` });
  }
});

test("WebGL failure leaves garden content and planting available", async ({ page }) => {
  await page.addInitScript(() => { const get = HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext = function (type: string, ...args: unknown[]) { if (type === "webgl2" || type === "webgl") return null; return get.apply(this, [type, ...args] as never); } as typeof get; });
  // Three.js logs a diagnostic when graphics initialization is deliberately blocked.
  errors.length = 0;
  await page.goto("/#flower-garden"); const garden = page.locator("#flower-garden"); await garden.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(garden.locator(".cinematic-viewport__status")).toContainText("3D is unavailable");
  await garden.getByRole("button", { name: "Release wish 4", exact: true }).click();
  await expect(garden.locator(".conservatory-wish")).toContainText("WISH 04");
  for (let i = errors.length - 1; i >= 0; i--) if (errors[i].includes("Error creating WebGL context")) errors.splice(i, 1);
});

test("normal-motion shader and bloom render; inactive garden stops rendering", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/#flower-garden"); const garden = page.locator("#flower-garden");
  await garden.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(garden.locator(".cinematic-viewport__status")).toHaveText("Real-time 3D ready");
  const host = garden.locator(".cinematic-viewport__canvas");
  await expect(host).toHaveAttribute("data-reduced-motion", "false");
  await garden.getByRole("button", { name: "Release wish 2", exact: true }).click();
  await page.waitForTimeout(1800);
  await garden.locator(".cinematic-viewport").scrollIntoViewIfNeeded();
  await expect(host).toHaveAttribute("data-scene-active", "true");
  await page.screenshot({ path: "qa/garden-normal-motion.png" });
  const frames = Number(await host.getAttribute("data-render-frames")); expect(frames).toBeGreaterThan(2);
  await page.locator("#gifts").scrollIntoViewIfNeeded(); await expect(host).toHaveAttribute("data-scene-active", "false");
  const stopped = await host.getAttribute("data-render-frames"); await page.waitForTimeout(250); expect(await host.getAttribute("data-render-frames")).toBe(stopped);
});

test("cancelling a pending microphone permission stops a late stream", async ({ page }) => {
  await page.addInitScript(() => {
    const w = window as unknown as { resolveLate: () => void; lateStops: number }; w.lateStops = 0;
    navigator.mediaDevices.getUserMedia = () => new Promise<MediaStream>((resolve) => { w.resolveLate = () => resolve({ getTracks: () => [{ stop: () => { w.lateStops++; } }] } as unknown as MediaStream); });
  });
  await page.goto("/#birthday-cake"); const cake = page.locator("#birthday-cake");
  await cake.getByRole("button", { name: "Skip to finished cake" }).click(); await cake.getByRole("button", { name: "Light the candles", exact: true }).click();
  await cake.getByRole("button", { name: "Enable microphone for this wish" }).click();
  await cake.getByRole("button", { name: "Cancel microphone" }).click();
  await page.evaluate(() => (window as unknown as { resolveLate: () => void }).resolveLate());
  await expect.poll(() => page.evaluate(() => (window as unknown as { lateStops: number }).lateStops)).toBe(1);
  await expect(cake.locator(".microphone-panel")).toContainText("Microphone off");
});

test("all twelve chapter anchors exist and all local anchor links resolve", async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("[data-chapter]")).toHaveCount(12);
  expect(await page.locator('a[href^="#"]').evaluateAll((links) => links.map((link) => link.getAttribute("href")!).filter((href) => href.length > 1 && !document.getElementById(decodeURIComponent(href.slice(1)))))).toEqual([]);
});
