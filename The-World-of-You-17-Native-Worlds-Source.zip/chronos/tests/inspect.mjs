import { chromium } from '@playwright/test';
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
await page.goto('http://localhost:4181/#flower-garden');await page.locator('#flower-garden').scrollIntoViewIfNeeded();await page.waitForTimeout(4500);
console.log(await page.locator('.cinematic-viewport__status').allTextContents());await page.screenshot({path:'qa-garden-desktop.png'});
await page.getByRole('button',{name:'Release wish 3',exact:true}).click();await page.waitForTimeout(2500);await page.screenshot({path:'qa-garden-focused.png'});
console.log('errors',errors);await browser.close();
