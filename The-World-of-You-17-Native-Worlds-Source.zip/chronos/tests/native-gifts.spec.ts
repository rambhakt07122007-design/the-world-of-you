import { test, expect } from "@playwright/test";
for (const [index, kind, title] of [[2, "flower", "Eternal rose"], [7, "crown", "Crown"], [16, "portal", "Portal"]] as const) {
  test(`${title}: native mesh renders and original controls remain usable`, async ({ page }) => {
    const errors: string[] = []; page.on("pageerror", (error) => errors.push(error.message)); page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
    await page.goto("/#gifts"); await page.locator(".gift-parcel").nth(index).click();
    const dialog = page.locator("dialog[open]"); const viewport = dialog.locator(`[data-gift-world="${kind}"]`);
    await viewport.scrollIntoViewIfNeeded();
    await expect(viewport.locator(".gift-native-status")).toHaveText("Real-time 3D ready");
    await expect(viewport.locator("[data-native-ready=true]")).toHaveAttribute("data-render-frames", /[1-9]/);
    if (kind === "flower") { for (let i = 0; i < 4; i++) await dialog.locator(".gift-control--primary").click(); }
    if (kind === "crown") { await dialog.getByRole("button", { name: "Rotate right", exact: true }).click(); await dialog.getByRole("button", { name: "The jewels", exact: true }).click(); }
    if (kind === "portal") { await dialog.getByRole("button", { name: "Gather the sixteen lights" }).click(); await dialog.getByRole("button", { name: "Open the portal", exact: true }).click(); }
    await viewport.scrollIntoViewIfNeeded(); await viewport.screenshot({ path: `qa/gift-${kind}.png` });
    if (kind === "portal") { await dialog.getByRole("button", { name: "Enter the Birthday Ballroom" }).click(); await expect(page.locator("dialog[open]")).toHaveCount(0); await expect(page.locator("#birthday-cake")).toBeInViewport(); }
    else { await dialog.getByRole("button", { name: "Close dialog", exact: true }).click(); await expect(page.locator("dialog canvas")).toHaveCount(0); }
    expect(errors).toEqual([]);
  });
}
