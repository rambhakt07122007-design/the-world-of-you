# Cinematic implementation plan

1. Backup and inventory all existing components/assets; preserve baseline interactions.
2. Add isolated Three.js lifecycle, quality tiers, WebGL failure path, reduced-motion and visibility handling.
3. Highest priority: procedural garden with curved petal meshes, staged growth, leaves, instanced grass, botanical variations, scenery, butterflies, pointer picking and camera focus. DOM wish/plant/replay controls.
4. Add warm real-time cake with procedural sponge/frosting/piping, mesh flame deformation and candlelight linked to ritual. Add opt-in calibrated microphone analyser, fallback button and guaranteed track cleanup.
5. Add reversible paper-fold desk experience without replacing existing letter content.
6. Browser-test local desktop/mobile/reduced-motion and all 17 retained gifts. Build/audit. Fix reproduced errors.
7. Record exact completed scope and remaining targets. Do not represent 17 CSS/SVG gifts or legacy illustrated scenes as rebuilt 3D experiences. Future passes cover their object-specific 3D conversions and detailed baking choreography.

Deployments are not automatic in this transformation pass; retain known production until local QA and user review.

## Implemented versus next work
Native garden, staged 3D cake, microphone, reversible paper desk, 3D clock and five native gift object views are now implemented. Original GLB snapshots exported. Remaining object conversions: jar, universe, cassette, cinema, wishes sky, machine, map, vinyl, mirror, coupons, tree and treasure chest. Invitation, hero garden, gallery, music, postcards, full ballroom and bespoke interscene transformations still need their requested depth. Photorealistic art direction, advanced optical effects, smoke ribbons/true handwriting, DOF and device profiling are not complete. Personal-content gates remain.
