import * as T from "three";
export type {Stage,Choreography,SceneState} from "./runtime";
export function material(color: string, roughness = 0.75, metalness = 0) { return new T.MeshStandardMaterial({ color, roughness, metalness }); }
export function mesh(geometry: T.BufferGeometry, mat: T.Material, parent: T.Object3D, x = 0, y = 0, z = 0) {
  const item = new T.Mesh(geometry, mat); item.position.set(x, y, z); item.castShadow = true; item.receiveShadow = true; parent.add(item); return item;
}
export function noiseTexture(base: string, seed: number, strength = 22) {
  const canvas = document.createElement("canvas"); canvas.width = canvas.height = 128;
  const ctx = canvas.getContext("2d")!; ctx.fillStyle = base; ctx.fillRect(0, 0, 128, 128);
  const pixels = ctx.getImageData(0, 0, 128, 128);
  let n = seed;
  for (let i = 0; i < pixels.data.length; i += 4) {
    n = (Math.imul(n, 1664525) + 1013904223) | 0;
    const offset = ((n >>> 0) / 4294967295 - 0.5) * strength;
    for (let c = 0; c < 3; c++) pixels.data[i + c] += offset;
  }
  ctx.putImageData(pixels, 0, 0);
  const texture = new T.CanvasTexture(canvas); texture.colorSpace = T.SRGBColorSpace; texture.wrapS = texture.wrapT = T.RepeatWrapping; return texture;
}
