// Offline authoring endpoint: never imported by the application.
import * as T from 'three';
import {createGift,giftKinds} from './giftFactory';
import {disposeTree} from './disposeTree';
import type {SceneState} from './runtime';
let renderer:T.WebGLRenderer|undefined;
export async function renderGiftPreview(index:number){
 if(!renderer){renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setSize(480,360);renderer.setPixelRatio(1);renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;}
 const scene=new T.Scene(),camera=new T.PerspectiveCamera(38,4/3,.1,80);scene.add(new T.HemisphereLight('#fff0d7','#526b63',1.3));const key=new T.DirectionalLight('#ffe3bf',3.5);key.position.set(-4,7,5);scene.add(key);const fill=new T.DirectionalLight('#b9d9e7',1);fill.position.set(4,3,-3);scene.add(fill);
 const choreography=createGift({scene,camera,quality:'low',pick:()=>{}},giftKinds[index]);
 const presets:Record<string,SceneState>={letter:{open:true},jar:{open:true,selected:3},flower:{growth:4},universe:{selected:0},cassette:{open:true},cinema:{open:true},wishes:{collected:[1,4,6]},crown:{detail:'crown'},cabinet:{selected:1,open:true},machine:{selected:0},adventure:{selected:1,growth:3},vinyl:{open:true},mirror:{growth:1},coupons:{selected:0},'hope-tree':{growth:8},treasure:{open:true},portal:{open:true,growth:2}};
 try{choreography.frame(4,1,presets[giftKinds[index]],true,1);scene.updateMatrixWorld(true);renderer.render(scene,camera);return renderer.domElement.toDataURL('image/png').split(',')[1];}finally{choreography.dispose?.();disposeTree(scene);}
}
export function finishPreviews(){renderer?.dispose();renderer?.forceContextLoss();renderer=undefined;}
