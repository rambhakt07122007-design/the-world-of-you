import * as T from "three";
import { material, mesh, noiseTexture, type Stage, type Choreography } from "./scenePrimitives";

function blade(length: number, width: number, curl: number) {
  const geometry = new T.PlaneGeometry(1, 1, 16, 24); const a = geometry.attributes.position;
  for (let i = 0; i < a.count; i++) { const u = a.getX(i) * 2; const v = a.getY(i) + 0.5; a.setXYZ(i, u * width * Math.sin(Math.PI * v), v * length, curl * (v * v + u * u * 0.35)); }
  geometry.computeVertexNormals(); return geometry;
}
export function buildBotanicalGift({ scene, camera }: Stage): Choreography {
  scene.background = new T.Color("#425849"); scene.fog = new T.FogExp2("#425849", 0.055); camera.position.set(0, 2.6, 6); camera.lookAt(0, 1, 0);
  const earth = material("#5c4934"); earth.map = noiseTexture("#5c4934", 19, 55);
  const terrain=mesh(new T.CylinderGeometry(1.65,1.45,.72,64,8),earth,scene,0,-.22,0);
  earth.bumpMap=earth.map;earth.bumpScale=.065;
  const terrainPos=terrain.geometry.attributes.position;
  for(let i=0;i<terrainPos.count;i++){if(terrainPos.getY(i)>.3){const x=terrainPos.getX(i),z=terrainPos.getZ(i);terrainPos.setY(i,.36+Math.sin(x*9)*Math.cos(z*8)*.035);}}terrain.geometry.computeVertexNormals();
  const seed = mesh(new T.SphereGeometry(0.23,24,16),material("#7b5137"),scene,0,.22,.14);seed.scale.set(.75,1.1,.8);
  const roots=new T.Group();scene.add(roots);
  for(let i=0;i<9;i++){const a=i*2.39996;const path=new T.CatmullRomCurve3([new T.Vector3(0,.14,.2),new T.Vector3(Math.cos(a)*.3,-.15,.55),new T.Vector3(Math.cos(a)*.8,-.5,.85)]);mesh(new T.TubeGeometry(path,20,.019,7,false),material("#bda37c"),roots);}
  for(let i=0;i<55;i++){const a=i*2.39996,r=Math.sqrt((i+.5)/55)*1.5;mesh(new T.DodecahedronGeometry(.025+i%3*.012),material(i%2?"#9d815e":"#46382a"),scene,Math.cos(a)*r,.17,Math.sin(a)*r);}
  const plant = new T.Group(); scene.add(plant); const green = material("#4f7144"); green.side = T.DoubleSide;
  const stem = mesh(new T.CylinderGeometry(0.025, 0.045, 1.8, 10, 12), green, plant, 0, 0.9, 0);
  const leafGeo = blade(0.6, 0.14, 0.08);
  const leaves = Array.from({ length: 3 }, (_, i) => { const pivot = new T.Group(); pivot.position.y = 0.5 + i * 0.32; pivot.rotation.y = i * 2.4; plant.add(pivot); const leaf = mesh(leafGeo, green, pivot); leaf.rotation.x = 1.2; return pivot; });
  const head = new T.Group(); head.position.y = 1.8; plant.add(head);
  const petalMat = new T.MeshPhysicalMaterial({ color: "#d6a1af", roughness: 0.45, side: T.DoubleSide, clearcoat: 0.12 }); petalMat.map = noiseTexture("#d6a1af", 87, 15); petalMat.bumpMap = petalMat.map; petalMat.bumpScale = 0.025;
  const petalGeo = new T.PlaneGeometry(1,1,24,30);const petalPosition=petalGeo.attributes.position;
  for(let i=0;i<petalPosition.count;i++){const u=petalPosition.getX(i)*2,v=petalPosition.getY(i)+.5;petalPosition.setXYZ(i,u*.34*Math.pow(Math.sin(Math.PI*v),.55),v*.69,-.12*Math.sin(v*Math.PI)+.12*v*v*v+u*u*.075);}
  petalGeo.computeVertexNormals();
  const petals = Array.from({ length: 21 }, (_, i) => { const radial = new T.Group(); radial.rotation.y = i * 2.39996; radial.position.y = Math.floor(i / 7) * 0.035; head.add(radial); const hinge = new T.Group(); radial.add(hinge); mesh(petalGeo, petalMat, hinge); return hinge; });
  const center = mesh(new T.SphereGeometry(0.1, 16, 12), material("#a78445"), head); center.scale.y = 0.6;
  const pollenGeometry=new T.BufferGeometry();const pollenPositions=new Float32Array(24*3);for(let i=0;i<24;i++)pollenPositions.set([Math.sin(i*2.4)*.8,1.6+(i%7)*.12,Math.cos(i*2.4)*.7],i*3);pollenGeometry.setAttribute("position",new T.BufferAttribute(pollenPositions,3));const pollen=new T.Points(pollenGeometry,new T.PointsMaterial({color:"#e8cda0",size:.018,transparent:true,opacity:.5}));scene.add(pollen);
  let growth = 0;
  return { frame(time, dt, state, reduced) {
    const target = (state.growth ?? 0) / 4; growth = reduced ? target : T.MathUtils.damp(growth, target, 1.7, dt);
    pollen.visible=growth>.75;pollen.rotation.y=reduced?0:time*.05;
    seed.visible = growth < .42; roots.scale.setScalar(Math.max(.001,T.MathUtils.smoothstep(growth,0,.25))); plant.visible = growth > .28;
    const stemGrowth = T.MathUtils.smoothstep(growth, .28, .65); stem.scale.y = Math.max(0.01, stemGrowth); stem.position.y = 0.9 * stemGrowth; head.position.y = 1.8 * stemGrowth;
    leaves.forEach((leaf, i) => { leaf.visible = growth > 0.18 + i * 0.04; leaf.rotation.z = (1 - T.MathUtils.smoothstep(growth, 0.2 + i * 0.05, 0.6)) * 1.2; });
    petals.forEach((petal, i) => { petal.rotation.x = 0.08 + T.MathUtils.smoothstep(growth, 0.4 + i / 60, 0.7 + i / 80) * (1.12 - Math.floor(i / 7) * 0.34 - i % 7 * 0.018); });
    plant.rotation.y = state.turn ?? 0; plant.rotation.z = reduced ? 0 : Math.sin(time * 0.7) * 0.025; camera.position.set(0,2+stemGrowth*.6,camera.aspect<1?8.2:6.8);camera.lookAt(0,.2+stemGrowth*.8,0);
  } };
}
export function buildCrown({ scene, camera }: Stage): Choreography {
  scene.background = new T.Color("#2d2632"); camera.position.set(0, 2.8, 6.5); camera.lookAt(0, 0.7, 0);
  mesh(new T.CylinderGeometry(1.5, 1.65, 0.4, 64), material("#684354", 0.98), scene, 0, -0.15, 0);
  const crown = new T.Group(); scene.add(crown); const gold = material("#c4a05e", 0.23, 0.9);
  mesh(new T.CylinderGeometry(1, 1, 0.18, 64, 1, true), gold, crown, 0, 0.2, 0).material.side = T.DoubleSide;
  for (const y of [0.1, 0.31]) { const ring = mesh(new T.TorusGeometry(1, 0.035, 10, 64), gold, crown, 0, y, 0); ring.rotation.x = Math.PI / 2; }
  const jewels: T.Mesh[] = []; const points: T.Group[] = [];
  for (let i = 0; i < 8; i++) {
    const group = new T.Group(); group.rotation.y = i * Math.PI / 4; crown.add(group); const support = new T.Group(); support.position.set(0, 0.29, 0.99); group.add(support); points.push(support);
    const silhouette = new T.Shape(); silhouette.moveTo(-0.36, 0); silhouette.quadraticCurveTo(-0.14, 0.15, 0, 0.72); silhouette.quadraticCurveTo(0.14, 0.15, 0.36, 0); silhouette.closePath();
    mesh(new T.ExtrudeGeometry(silhouette, { depth: 0.045, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.015, bevelThickness: 0.015 }), gold, support);
    const gem = mesh(new T.OctahedronGeometry(0.12, 1), new T.MeshPhysicalMaterial({ color: i % 2 ? "#827da4" : "#b95c78", roughness: 0.08, metalness: 0.2, clearcoat: 1 }), support, 0, 0.22, 0.09); gem.scale.set(0.65, 1, 0.55); jewels.push(gem);
    mesh(new T.SphereGeometry(0.06, 12, 8), gold, support, 0, 0.71, 0.025);
  }
  let age = 0; const target = new T.Vector3();
  return { frame(_time, dt, state, reduced) {
    age = reduced ? 10 : age + dt;
    points.forEach((point, i) => { const settle = T.MathUtils.smoothstep(age, i * 0.15, i * 0.15 + 0.65); point.position.y = 0.29 + (1 - settle) * 1.5; point.rotation.x = (1 - settle) * -0.4; jewels[i].visible = age > 1.3 + i * 0.1; });
    crown.rotation.y = state.turn ?? 0;
    target.set(0, 2.8, state.detail === "jewels" ? 4.5 : state.detail === "velvet" ? 5.5 : 6.5); if (camera.aspect < 1) target.z += 1.5;
    camera.position.lerp(target, reduced ? 1 : 1 - Math.exp(-dt * 2)); camera.lookAt(0, state.detail === "velvet" ? 0.15 : 0.7, 0);
  } };
}
