import * as T from "three";
import {gsap} from "gsap";
import { material, mesh, noiseTexture, type Stage, type Choreography } from "./scenePrimitives";

export const LETTER_DURATION = 4.8;
const ease = (p: number, a: number, b: number) => T.MathUtils.smootherstep(p, a, b);

/** One continuous closed surface; its tangent bends across two rounded crease bands.
 * Integrating the tangent preserves paper arc length instead of scaling rigid panels. */
export function createFoldedPaper() {
  const columns = 32, rows = 120, width = 2.06, height = 2.79;
  const stride = columns + 1, count = stride * (rows + 1);
  const vertices = new Float32Array(count * 2 * 3), uv = new Float32Array(count * 2 * 2);
  const indices: number[] = [];
  for (let side = 0; side < 2; side++) for (let j = 0; j <= rows; j++) for (let i = 0; i <= columns; i++) {
    const n = side * count + j * stride + i;
    uv[n * 2] = i / columns; uv[n * 2 + 1] = j / rows;
    if (i < columns && j < rows) {
      const a = n, b = n + 1, c = n + stride, d = c + 1;
      indices.push(...(side ? [a, c, b, b, c, d] : [a, b, c, b, d, c]));
    }
  }
  const edge = (a: number, b: number) => indices.push(a, b, a + count, b, b + count, a + count);
  for (let i = 0; i < columns; i++) { edge(i + 1, i); edge(rows * stride + i, rows * stride + i + 1); }
  for (let j = 0; j < rows; j++) { edge(j * stride, (j + 1) * stride); edge((j + 1) * stride + columns, j * stride + columns); }
  const geometry = new T.BufferGeometry();
  geometry.setAttribute("position", new T.BufferAttribute(vertices, 3).setUsage(T.DynamicDrawUsage));
  geometry.setAttribute("uv", new T.BufferAttribute(uv, 2)); geometry.setIndex(indices);
  const deform = (upper: number, lower: number) => {
    const ys = new Float32Array(rows + 1), zs = new Float32Array(rows + 1), angles = new Float32Array(rows + 1);
    const tangent = (y: number) => y >= 0 ? Math.PI * (1 - upper) * ease(y, .405, .525) : -Math.PI * (1 - lower) * ease(-y, .44, .49);
    // Integrate outward from the central panel; negative path direction matters.
    for (const direction of [-1, 1]) for (let step = 1; step <= rows / 2; step++) {
      const j = rows / 2 + direction * step, prev = j - direction;
      const delta = direction * height / rows, y = (j / rows - .5) * height;
      const a = tangent(y - delta / 2); angles[j] = tangent(y);
      ys[j] = ys[prev] + Math.cos(a) * delta; zs[j] = zs[prev] + Math.sin(a) * delta;
    }
    for (let side = 0; side < 2; side++) for (let j = 0; j <= rows; j++) for (let i = 0; i <= columns; i++) {
      const x = (i / columns - .5) * width;
      const thickness = (side ? -1 : 1) * .0035;
      const edgeCurl = .016 * Math.pow(Math.abs(x) / (width / 2), 6);
      const n = (side * count + j * stride + i) * 3;
      vertices[n] = x;
      vertices[n + 1] = ys[j] - Math.sin(angles[j]) * thickness;
      vertices[n + 2] = zs[j] + Math.cos(angles[j]) * thickness + edgeCurl;
    }
    geometry.attributes.position.needsUpdate = true; geometry.computeVertexNormals(); geometry.computeBoundingSphere();
  };
  deform(0, 0);
  return { geometry, deform };
}

export function buildLetter({ scene, camera, report }: Stage): Choreography {
  const wood = material("#56382b", .63); wood.map = noiseTexture("#654535", 129, 32); wood.map.repeat.set(2, 32); wood.bumpMap = wood.map; wood.bumpScale = .025;
  mesh(new T.BoxGeometry(11, .25, 12), wood, scene, 0, -.22, -1);
  // Leather writing blotter gives a readable silhouette and receives contact shadows.
  mesh(new T.BoxGeometry(6.2, .025, 7), material("#34413b", .94), scene, 0, -.065, -1);
  const paper = material("#f4e9cf", .94); paper.map = noiseTexture("#f4e9cf", 33, 14); paper.bumpMap = paper.map; paper.bumpScale = .008;
  const envelopeMat = material("#ccb28d", .9); envelopeMat.map = noiseTexture("#d7c4a2", 17, 15);
  const envelope = new T.Group(); envelope.rotation.x = -Math.PI / 2; envelope.position.set(0, .015, 1.15); scene.add(envelope);
  const back = mesh(new T.BoxGeometry(2.4, 1.45, .018), envelopeMat, envelope);
  // Pocket face is separated from the back; the folded sheet occupies this real cavity.
  mesh(new T.BoxGeometry(2.4, 1.42, .018), envelopeMat, envelope, 0, -.015, .14);
  for (const x of [-1.19, 1.19]) mesh(new T.BoxGeometry(.025, 1.45, .14), envelopeMat, envelope, x, 0, .07);
  mesh(new T.BoxGeometry(2.4, .025, .14), envelopeMat, envelope, 0, -.71, .07);
  const flap = new T.Group(); flap.position.set(0, .725, .15); envelope.add(flap);
  const shape = new T.Shape(); shape.moveTo(-1.2, 0); shape.lineTo(1.2, 0); shape.lineTo(0, -.94); shape.closePath();
  mesh(new T.ExtrudeGeometry(shape, { depth: .012, bevelEnabled: false }), envelopeMat, flap);
  const wax = material("#8d3948", .31); const halves: T.Mesh[] = [];
  for (const sign of [-1, 1]) {
    const half = new T.Shape(); half.moveTo(0, -.18);
    for (let i = 0; i <= 24; i++) { const angle = -Math.PI / 2 + i / 24 * Math.PI; const r = .18 + .007 * Math.sin(i * 2.7); half.lineTo(sign * Math.cos(angle) * r, Math.sin(angle) * r); }
    half.lineTo(.009 * sign, .07); half.lineTo(-.007 * sign, -.03); half.closePath();
    halves.push(mesh(new T.ExtrudeGeometry(half, {depth:.035,bevelEnabled:true,bevelSize:.008,bevelThickness:.005,bevelSegments:2,steps:1}), wax, flap, 0, -.66, .025));
  }
  const stamp = mesh(new T.TorusGeometry(.125, .008, 8, 40), material("#bd7773", .44), flap, 0, -.66, .068);
  const folded = createFoldedPaper(); const sheet = mesh(folded.geometry, paper, envelope, 0, 0, .042);
  // Creases are actual bent bands; subtle tonal marks are painted into paper texture.
  const canvas = document.createElement("canvas"); canvas.width = 768; canvas.height = 1024;
  const ctx = canvas.getContext("2d")!; ctx.fillStyle = "#f4e9cf"; ctx.fillRect(0,0,768,1024);
  ctx.fillStyle = "#d7c8ab"; for (const y of [341,683]) ctx.fillRect(0,y,768,2);
  for(let i=0;i<1800;i++){ctx.fillStyle=i%2?'#f0e5ce':'#ede1c7';ctx.fillRect((i*71)%768,(i*97)%1024,1,1);}
  const paperTexture = new T.CanvasTexture(canvas); paperTexture.colorSpace = T.SRGBColorSpace; paper.map?.dispose(); paper.map = paperTexture; paper.bumpMap = paperTexture;
  const pen = mesh(new T.CylinderGeometry(.045,.06,2.3,16),material("#252b2b",.25,.45),scene,2.25,.04,-.15);pen.rotation.set(Math.PI/2,0,-.22);
  mesh(new T.CylinderGeometry(.24,.29,.46,12),material("#263c3c",.18,.2),scene,2.3,.2,-2.2);
  mesh(new T.CylinderGeometry(.17,.17,.08,24),material("#b99758",.28,.72),scene,2.3,.47,-2.2);
  mesh(new T.CylinderGeometry(.32,.38,.09,32),material("#b99758",.35,.7),scene,-2.35,0,-1.6);
  mesh(new T.CylinderGeometry(.21,.23,.85,32),material("#ecdbb9"),scene,-2.35,.45,-1.6);
  const flame=mesh(new T.SphereGeometry(.075,12,12),new T.MeshBasicMaterial({color:'#ffd296'}),scene,-2.35,.94,-1.6);flame.scale.y=1.8;
  const glow=new T.PointLight('#ffbd75',3.2,6);glow.position.set(-2.35,1.1,-1.6);scene.add(glow);
  back.userData.index=0;envelope.userData.index=0;
  const phases={split:0,flap:0,extraction:0,upper:0,lower:0};
  const timeline=gsap.timeline({paused:true,defaults:{ease:"power2.inOut"}})
    .to(phases,{split:1,duration:.5},.1)
    .to(phases,{flap:1,duration:1.1},.58)
    .to(phases,{extraction:1,duration:1.4},1.72)
    .to(phases,{upper:1,duration:.92},3.12)
    .to(phases,{lower:1,duration:.92},3.79)
    .to({}, {duration:.09},4.71);
  let progress=0,lastReplay: number|undefined, lastUpper=-1,lastLower=-1,lastReport=-1,lastText="";
  return {dispose(){timeline.kill();},pickables:[envelope],frame(_time,dt,state,reduced,timelineDt){
    if (state.detail && state.detail !== lastText) {
      lastText = state.detail;
      ctx.fillStyle = "#f4e9cf"; ctx.fillRect(0,0,768,1024);
      ctx.fillStyle = "#dac9ab"; for (const y of [341,683]) ctx.fillRect(0,y,768,2);
      ctx.font = "italic 19px Georgia, serif"; ctx.fillStyle = "#514638";
      let y = 62;
      for (const paragraph of state.detail.split("\n\n")) {
        let line = "";
        for (const word of paragraph.split(/\s+/)) {
          if(ctx.measureText(line + word).width > 654 && line) { ctx.fillText(line, 54, y); y += 25; line = ""; }
          line += word + " ";
        }
        ctx.fillText(line,54,y); y += 39;
      }
      paperTexture.needsUpdate = true;
    }
    if(state.replay!==lastReplay){if(lastReplay!==undefined)progress=0;lastReplay=state.replay;}
    const target=state.open?1:0;
    progress=reduced||state.immediate?target:T.MathUtils.clamp(progress+(target>progress?1:target<progress?-1:0)*(timelineDt ?? dt)/LETTER_DURATION,0,1);
    // Do not overshoot the requested endpoint after an interrupted reverse.
    if(Math.abs(progress-target)<.00001)progress=target;
    timeline.time(progress*LETTER_DURATION,false);
    const split=phases.split;
    halves.forEach((half,i)=>{half.position.x=(i?1:-1)*split*.07;half.rotation.z=(i?1:-1)*split*.12;half.visible=progress<.24;});stamp.visible=progress<.10;
    flap.rotation.x=-phases.flap*Math.PI;
    const extraction=phases.extraction;
    sheet.position.set(0,extraction*2.35,.042+Math.sin(extraction*Math.PI)*.24+extraction*.23);
    const upper=phases.upper,lower=phases.lower;
    if(upper!==lastUpper||lower!==lastLower){folded.deform(upper,lower);lastUpper=upper;lastLower=lower;}
    // Portrait fit based on vertical and horizontal extents, not desktop-only coordinates.
    const distance=Math.max(7.8,4.2/Math.max(.4,camera.aspect));const approach=ease(progress,0,.35);
    camera.position.set(.2*(1-approach),distance*.88-approach*.25,distance*.64-approach*.2);camera.lookAt(0,.15,-.35-approach*.1);
    if(Math.abs(progress-lastReport)>.008||progress===0||progress===1){if(progress!==lastReport){report?.(progress);lastReport=progress;}}
  }};
}
