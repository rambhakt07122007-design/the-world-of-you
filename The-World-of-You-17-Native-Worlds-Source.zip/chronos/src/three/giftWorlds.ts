import * as T from 'three';
import {material,mesh,noiseTexture,type Stage,type Choreography} from './scenePrimitives';

export type WorldKind='jar'|'universe'|'cassette'|'cinema'|'wishes'|'cabinet'|'machine'|'adventure'|'vinyl'|'mirror'|'coupons'|'hope-tree'|'treasure';
const gold=()=>material('#ba965b',.26,.82);
const paper=()=>{const m=material('#f3e5c9',.94);m.map=noiseTexture('#f3e5c9',39,15);m.bumpMap=m.map;m.bumpScale=.012;return m;};
const smooth=(v:number,t:number,dt:number,reduced:boolean)=>reduced?t:T.MathUtils.damp(v,t,4,dt);
function curve(parent:T.Object3D,points:number[][],radius:number,mat:T.Material){return mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p as [number,number,number]))),28,radius,8,false),mat,parent);}
function textTexture(text:string,bg='#f3e5c9',ink='#483e33'){
 const c=document.createElement('canvas');c.width=512;c.height=256;const x=c.getContext('2d')!;x.fillStyle=bg;x.fillRect(0,0,512,256);x.fillStyle=ink;x.font='24px Georgia';let y=50;for(const line of text.split('\n')){x.fillText(line,28,y,456);y+=42;}const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return t;
}
function plaque(parent:T.Object3D,text:string,w:number,h:number,x:number,y:number,z:number){const m=material('#ffffff',.9);m.map=textTexture(text);return mesh(new T.BoxGeometry(w,h,.015),m,parent,x,y,z);}
function stageBase({scene,camera}:Stage,color='#293e3a'){
 scene.background=new T.Color(color);scene.fog=new T.FogExp2(color,.025);camera.position.set(0,2.6,7.7);camera.lookAt(0,.9,0);
 const wood=material('#514338',.74);wood.map=noiseTexture('#514338',36,32);wood.map.repeat.set(2,14);mesh(new T.CylinderGeometry(3.8,4,.24,80),wood,scene,0,-.28,0);
 const rim=mesh(new T.TorusGeometry(3.7,.025,8,96),gold(),scene,0,-.14,0);rim.rotation.x=Math.PI/2;
 const fill=new T.DirectionalLight('#b9dbef',1.5);fill.position.set(4,3,-3);scene.add(fill);
}
function frameCamera(stage:Stage,targetY=1,z=7.7){stage.camera.position.z=Math.max(z,5.7/Math.max(.45,stage.camera.aspect));stage.camera.lookAt(0,targetY,0);}
function gear(parent:T.Object3D,r:number,x:number,y:number,z:number){const g=new T.Group();parent.add(g);g.position.set(x,y,z);mesh(new T.TorusGeometry(r,.055,8,40),gold(),g);for(let i=0;i<16;i++){const a=i*Math.PI/8;const tooth=mesh(new T.BoxGeometry(.09,.13,.12),gold(),g,Math.sin(a)*r,Math.cos(a)*r,0);tooth.rotation.z=-a;}mesh(new T.CylinderGeometry(.06,.06,.13,12),gold(),g).rotation.x=Math.PI/2;return g;}
function star(parent:T.Object3D,r:number,mat:T.Material,x:number,y:number,z:number){const shape=new T.Shape();for(let i=0;i<10;i++){const a=i*Math.PI/5;const q=i%2?r*.43:r;const px=Math.sin(a)*q,py=Math.cos(a)*q;if(i)shape.lineTo(px,py);else shape.moveTo(px,py);}shape.closePath();return mesh(new T.ExtrudeGeometry(shape,{depth:.045,bevelEnabled:true,bevelSize:.015,bevelThickness:.015,bevelSegments:2}),mat,parent,x,y,z);}

export function buildJar(stage:Stage):Choreography {
 stageBase(stage,'#263f3b');const {scene,quality}=stage;const jar=new T.Group();scene.add(jar);
 const profile=[[0,0],[.73,0],[.9,.14],[.96,.45],[.96,1.83],[.78,2.15],[.72,2.32],[.72,2.45],[.66,2.45],[.66,2.3],[.72,2.1],[.88,1.82],[.88,.42],[.8,.15],[0,.15]];
 const glass=new T.MeshPhysicalMaterial({color:'#d9eeea',roughness:.12,metalness:.05,transparent:true,opacity:quality==='high'?.72:.24,transmission:quality==='high'?.65:0,thickness:.08,ior:1.46,clearcoat:1,side:T.DoubleSide,depthWrite:false});
 const body=mesh(new T.LatheGeometry(profile.map(([r,y])=>new T.Vector2(r,y)),64),glass,jar);body.castShadow=false;body.renderOrder=3;
 for(const y of [2.31,2.38,2.44]){const thread=mesh(new T.TorusGeometry(.725,.024,8,64),material('#aac8c0',.18,.3),jar,0,y,0);thread.rotation.x=Math.PI/2;}
 const lid=new T.Group();lid.position.y=2.49;jar.add(lid);mesh(new T.CylinderGeometry(.8,.8,.18,64),gold(),lid);for(let i=0;i<48;i++){const a=i*Math.PI/24;const ridge=mesh(new T.BoxGeometry(.025,.1,.035),gold(),lid,Math.sin(a)*.8,0,Math.cos(a)*.8);ridge.rotation.y=a;}
 const ribbon=material('#9b6671',.85);curve(jar,[[-.9,1.89,.15],[0,1.86,.96],[.9,1.89,.15]],.045,ribbon);
 for(const sign of [-1,1]){const bow=mesh(new T.TorusGeometry(.18,.045,8,24),ribbon,jar,sign*.16,1.9,.94);bow.scale.set(1.1,.55,1);bow.rotation.z=sign*.45;}
 const notes=Array.from({length:17},(_,i)=>{const g=new T.Group();jar.add(g);const a=i*2.39996;g.position.set(Math.cos(a)*(.27+(i%3)*.13),.35+Math.floor(i/5)*.34,Math.sin(a)*.43);g.rotation.set(i*.19,a,.25*Math.sin(i));g.userData.index=i;mesh(new T.BoxGeometry(.43,.28,.018),paper(),g);const fold=mesh(new T.BoxGeometry(.43,.14,.015),paper(),g,0,.12,.035);fold.rotation.x=.38;plaque(g,String(i+1).padStart(2,'0'),.24,.1,0,-.025,.025);g.userData.home=g.position.clone();return g;});
 plaque(scene,'SEVENTEEN NOTES\nOWNER-WRITTEN WORDS ONLY',1.5,.5,-1.85,.25,.75);
 let lidP=0,turn=0,shuffle=0;return {pickables:notes,frame(time,dt,state,reduced){
  lidP=smooth(lidP,state.open?1:0,dt,reduced);lid.position.set(-lidP*1.05,2.49+lidP*.9,-lidP*.25);lid.rotation.set(lidP*.15, lidP*.65,lidP*.25);
  turn=smooth(turn,state.turn??0,dt,reduced);jar.rotation.y=turn;
  shuffle=smooth(shuffle,state.replay??0,dt,reduced);
  notes.forEach((n,i)=>{const home=n.userData.home as T.Vector3;const chosen=state.open&&state.selected===i;const mix=reduced?1:1-Math.exp(-dt*5);const a=i*2.39996+shuffle*.55;const target=chosen?new T.Vector3(1.65,2.85,.5):new T.Vector3(Math.cos(a)*(.27+(i%3)*.13),home.y,Math.sin(a)*.43);n.position.lerp(target,mix);n.rotation.y=smooth(n.rotation.y,chosen?-turn:a,dt,reduced);n.rotation.x=smooth(n.rotation.x,chosen?-.1:i*.19,dt,reduced);n.scale.setScalar(chosen?1.55:1);n.userData.pickDisabled=!state.open;});
  frameCamera(stage,1.3,7.8);void time;
 }};
}

export function buildUniverse(stage:Stage):Choreography {
 stageBase(stage,'#121d32');const {scene}=stage;const root=new T.Group();scene.add(root);root.position.y=1.1;
 const sun=mesh(new T.SphereGeometry(.46,40,24),new T.MeshStandardMaterial({color:'#e8b76f',emissive:'#ae6535',emissiveIntensity:.65,roughness:.7}),root);
 mesh(new T.CylinderGeometry(1.8,2,.12,64),gold(),scene,0,-.1,0);
 const planets=Array.from({length:5},(_,i)=>{const orbit=new T.Group();root.add(orbit);orbit.rotation.z=(i-2)*.12;const r=1+i*.36;const ring=mesh(new T.TorusGeometry(r,.008,6,100),gold(),orbit);ring.rotation.x=Math.PI/2;const p=mesh(new T.SphereGeometry(.12+i*.035,32,20),material(['#8fa6ab','#aa6c55','#d4bba0','#748d83','#8d83a5'][i],.54),orbit,r,0,0);if(i===2){const halo=mesh(new T.TorusGeometry(.28,.025,8,40),gold(),p);halo.rotation.x=1.2;}p.userData.index=i%2;return {orbit,p};});
 const stars=Array.from({length:2},(_,i)=>{const s=star(root,.18,new T.MeshStandardMaterial({color:'#fff0b0',emissive:'#b39352',emissiveIntensity:.5}),i?1.4:-1.4,.8,i?-.4:.4);s.userData.index=i;return s;});
 curve(root,[[-1.4,.8,.4],[0,1.1,0],[1.4,.8,-.4]],.008,gold());
 const pos=new Float32Array(160*3);for(let i=0;i<160;i++)pos.set([Math.sin(i*43)*8,2+Math.cos(i*17)*5,-3-i%9],i*3);const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(pos,3));scene.add(new T.Points(geo,new T.PointsMaterial({color:'#eadcc2',size:.025})));
 return {pickables:[...stars,...planets.map(p=>p.p)],frame(time,dt,state,reduced){root.rotation.y=smooth(root.rotation.y,state.turn??0,dt,reduced);planets.forEach(({orbit},i)=>{orbit.rotation.y=(reduced?i:time*(.1+i*.025))+i;});stars.forEach((s,i)=>s.scale.setScalar(state.selected===i?1.3:1));sun.rotation.y=reduced?0:time*.12;frameCamera(stage,1.1,8/(state.growth??1));}};
}

export function buildAudioWorld(stage:Stage,vinyl:boolean):Choreography {
 stageBase(stage,vinyl?'#352633':'#293a39');const {scene}=stage;const body=new T.Group();scene.add(body);body.position.y=.3;
 const wood=material('#5b3b2c',.64);wood.map=noiseTexture('#654633',73,30);mesh(new T.BoxGeometry(3.9,.6,2.6),wood,body);
 mesh(new T.BoxGeometry(3.82,.08,2.52),material('#333a3b',.3,.5),body,0,.34,0);
 const reels:T.Group[]=[];const tape=new T.Group();body.add(tape);let arm:T.Group|undefined;
 if(vinyl){const platter=mesh(new T.CylinderGeometry(1.04,1.04,.07,80),material('#99948d',.2,.85),body,-.55,.43,0);const record=new T.Group();record.position.set(-.55,.49,0);body.add(record);reels.push(record);mesh(new T.CylinderGeometry(.97,.97,.035,96),material('#171b1b',.25),record);for(let i=0;i<18;i++){const groove=mesh(new T.TorusGeometry(.34+i*.033,.0025,4,96),material('#626361',.45),record,0,.022,0);groove.rotation.x=Math.PI/2;}mesh(new T.CylinderGeometry(.28,.28,.04,48),material('#a06070',.6),record,0,.015,0);mesh(new T.CylinderGeometry(.025,.025,.14,16),gold(),record,0,.08,0);arm=new T.Group();arm.position.set(1.15,.5,-.7);body.add(arm);curve(arm,[[0,0,0],[0,.12,.3],[-.45,.12,1.15]],.027,gold());mesh(new T.BoxGeometry(.13,.09,.26),material('#20282a'),arm,-.45,.1,1.15);void platter;}
 else{tape.position.set(0,.55,0);mesh(new T.BoxGeometry(2.65,.18,1.6),material('#b3a58a',.52),tape);const windowMat=new T.MeshPhysicalMaterial({color:'#283b39',transparent:true,opacity:.45,roughness:.15});mesh(new T.BoxGeometry(2.2,.02,.8),windowMat,tape,0,.11,0);for(const x of [-.68,.68]){const g=new T.Group();g.position.set(x,.14,0);tape.add(g);reels.push(g);mesh(new T.CylinderGeometry(.32,.32,.035,48),material('#2e3330',.5),g);for(let j=0;j<6;j++){const a=j*Math.PI/3;const spoke=mesh(new T.BoxGeometry(.05,.05,.48),material('#e2d6b6'),g);spoke.rotation.y=a;}mesh(new T.CylinderGeometry(.065,.065,.06,16),gold(),g,0,.04,0);}plaque(tape,'BHUMI FM',1.5,.25,0,.12,.65).rotation.x=-Math.PI/2;}
 const buttons=Array.from({length:4},(_,i)=>mesh(new T.BoxGeometry(.3,.12,.22),i?gold():material('#9e5662'),body,-.65+i*.43,.42,1.02));
 const bars=Array.from({length:12},(_,i)=>mesh(new T.BoxGeometry(.07,.04,.07),new T.MeshStandardMaterial({color:'#d3b978',emissive:'#88632d',emissiveIntensity:.3}),body,1.4,.43,-.9+i*.14));
 let rotation=0;return {frame(_time,dt,state,reduced){if((state.playing||state.preview)&&!reduced)rotation+=dt*(vinyl?1.1:2.5);reels.forEach((r,i)=>r.rotation.y=rotation*(i%2?-1:1));tape.position.y=smooth(tape.position.y,state.open?.55:1.5,dt,reduced);if(arm)arm.rotation.y=smooth(arm.rotation.y,state.playing?-.34:0,dt,reduced);buttons[0].position.y=state.playing?.37:.42;bars.forEach((b,i)=>{b.scale.y=1+(state.spectrum?.[i]??0)*12;});frameCamera(stage,.4,7.3);}};
}

export function buildCinema(stage:Stage):Choreography {
 stageBase(stage,'#211e2a');const {scene}=stage;const projector=new T.Group();projector.position.set(-1.65,.6,1);scene.add(projector);
 const iron=material('#3e4746',.4,.65);mesh(new T.BoxGeometry(.9,1.05,.7),iron,projector);const reels=[gear(projector,.46,-.45,.8,0),gear(projector,.46,.45,.8,0)];for(const x of [-.45,.45])mesh(new T.TorusGeometry(.34,.016,6,40),material('#a99574'),projector,x,.8,.08);
 const lens=mesh(new T.CylinderGeometry(.19,.24,.58,40),gold(),projector,.6,.15,0);lens.rotation.z=Math.PI/2;mesh(new T.CylinderGeometry(.15,.15,.025,32),material('#839da1',.08,.75),lens,0,.29,0);
 curve(projector,[[-.45,.8,.08],[-.5,.4,.08],[.2,.4,.08],[.45,.8,.08]],.025,material('#514335'));
 const screen=new T.Group();screen.position.set(.7,1.25,-1.2);scene.add(screen);mesh(new T.BoxGeometry(3.2,2.1,.12),iron,screen);const panel=mesh(new T.PlaneGeometry(2.9,1.8),material('#ede4cf'),screen,0,0,.07);const blank=(panel.material as T.MeshStandardMaterial);blank.map=textTexture('MEMORY CINEMA\nHeld for real photographs\nNo personal photos supplied');
 const beam=mesh(new T.ConeGeometry(1.1,3.2,40,1,true),new T.MeshBasicMaterial({color:'#f4dba4',transparent:true,opacity:.065,depthWrite:false,side:T.DoubleSide}),scene,-.1,1.1,.0);beam.rotation.set(Math.PI/2,0,-.4);beam.castShadow=false;
 const lamp=new T.PointLight('#ffdb99',0,6);lamp.position.set(-1,1,.8);scene.add(lamp);let current='',request=0,disposed=false;const loader=new T.TextureLoader();
 return {dispose(){disposed=true;request++;},frame(time,dt,state,reduced){beam.visible=!!state.open;lamp.intensity=state.open?2:0;reels.forEach((r,i)=>r.rotation.z=state.open&&!reduced?time*(i?-1:1):0);if(state.artwork&&state.artwork!==current){current=state.artwork;const id=++request;loader.load(current,t=>{if(disposed||id!==request){t.dispose();return;}t.colorSpace=T.SRGBColorSpace;blank.map?.dispose();blank.map=t;blank.needsUpdate=true;});}frameCamera(stage,1,8);void dt;}};
}

function branchTree(parent:T.Object3D,mat:T.Material){curve(parent,[[0,0,0],[-.1,.8,0],[.1,1.7,0],[0,2.5,0]],.09,mat);for(let i=0;i<8;i++){const a=i*2.39996,y=.65+i*.2;curve(parent,[[0,y,0],[Math.cos(a)*.6,y+.25,Math.sin(a)*.6],[Math.cos(a)*1.1,y+.65,Math.sin(a)*1.1]],.035,mat);}}
export function buildWishes(stage:Stage):Choreography {
 stageBase(stage,'#192d32');const tree=new T.Group();stage.scene.add(tree);branchTree(tree,material('#876d4d',.85));
 const lamps=Array.from({length:10},(_,i)=>{const a=i*2.39996;const g=new T.Group();g.position.set(Math.cos(a)*1.2,.9+(i%5)*.38,Math.sin(a)*1.2);tree.add(g);curve(g,[[0,.3,0],[0,0,0]],.007,gold());const s=star(g,.13,new T.MeshStandardMaterial({color:'#d2b26f',emissive:'#af8b38',emissiveIntensity:.2}),0,0,0);s.userData.index=i;return s;});
 return {pickables:lamps,frame(time,dt,state,reduced){lamps.forEach((s,i)=>{const m=s.material as T.MeshStandardMaterial;m.emissiveIntensity=state.collected?.includes(i)?1.5:.15;s.rotation.y=reduced?0:Math.sin(time*.5+i)*.2;s.scale.setScalar(state.selected===i?1.3:1);});frameCamera(stage,1.2,8);void dt;}};
}

export function buildCabinet(stage:Stage):Choreography {
 stageBase(stage,'#3b3036');const {scene}=stage;const wood=material('#674a3c',.7);mesh(new T.BoxGeometry(3.8,2.7,.6),wood,scene,0,1.2,-.5);
 const slots=Array.from({length:4},(_,i)=>{const g=new T.Group();g.position.set((i%2?1:-1)*.9,Math.floor(i/2)*1.12+.65,0);scene.add(g);mesh(new T.BoxGeometry(1.65,.9,.14),paper(),g);plaque(g,String(i+1).padStart(2,'0'),.32,.22,-.52,-.23,.09);const flap=new T.Group();flap.position.set(0,.45,.09);g.add(flap);const sh=new T.Shape();sh.moveTo(-.825,0);sh.lineTo(.825,0);sh.lineTo(0,-.6);sh.closePath();mesh(new T.ExtrudeGeometry(sh,{depth:.01,bevelEnabled:false}),paper(),flap);const seal=mesh(new T.CylinderGeometry(.1,.1,.035,24),material('#9b5366',.4),flap,0,-.35,.04);seal.rotation.x=Math.PI/2;g.userData.index=i;return {g,flap,seal};});
 return {pickables:slots.map(s=>s.g),frame(_time,dt,state,reduced){slots.forEach(({g,flap,seal},i)=>{const chosen=state.selected===i;g.position.z=smooth(g.position.z,chosen?.55:0,dt,reduced);flap.rotation.x=smooth(flap.rotation.x,chosen&&state.open?-Math.PI:0,dt,reduced);seal.visible=!(chosen&&state.open);});frameCamera(stage,1.2,8);}};
}

export function buildMachine(stage:Stage):Choreography {
 stageBase(stage,'#343a32');const {scene}=stage;const brass=gold();mesh(new T.BoxGeometry(2.5,2.35,1.1),material('#3f625e',.46,.35),scene,0,1,0);for(const x of [-1.1,1.1])for(const y of [.05,1.95])mesh(new T.SphereGeometry(.055,12,8),brass,scene,x,y,.57);
 const gears=[gear(scene,.36,-.65,1.45,.67),gear(scene,.5,.2,1.35,.68),gear(scene,.25,.85,1.1,.68)];
 const lever=new T.Group();lever.position.set(1.4,.6,0);scene.add(lever);curve(lever,[[0,0,0],[.1,.8,0]],.055,brass);mesh(new T.SphereGeometry(.16,24,16),material('#984e59',.35),lever,.1,.82,0);
 mesh(new T.BoxGeometry(1.5,.09,.15),material('#151f21'),scene,0,.45,.63);const ticket=plaque(scene,'A SOURCE-ARCHIVE WISH',1.25,.6,0,.25,.76);let phase=0;return {frame(time,dt,state,reduced){phase=smooth(phase,state.open?1:0,dt,reduced);lever.rotation.z=-phase*.85;gears.forEach((g,i)=>{g.rotation.z=state.open&&!reduced?time*3*(i%2?-1:1):0;});ticket.position.y=.25+(state.selected===null?-.25:.2);ticket.scale.y=state.selected===null?.1:1;frameCamera(stage,1,7.6);}};
}

export function buildAdventure(stage:Stage):Choreography {
 stageBase(stage,'#2d4b45');const {scene}=stage;const land=mesh(new T.CylinderGeometry(2.5,2.7,.4,64),material('#97a383',.93),scene,0,.04,0);
 const geo=land.geometry.attributes.position;for(let i=0;i<geo.count;i++){const x=geo.getX(i),z=geo.getZ(i);if(geo.getY(i)>.1)geo.setY(i,.2+Math.sin(x*2)*Math.cos(z*2)*.08);}land.geometry.computeVertexNormals();
 const markers=Array.from({length:4},(_,i)=>{const a=i*Math.PI/2+.4;const g=new T.Group();g.position.set(Math.cos(a)*1.65,.3,Math.sin(a)*1.65);scene.add(g);mesh(new T.CylinderGeometry(.018,.025,.6,12),gold(),g,0,.3,0);const flag=mesh(new T.BoxGeometry(.35,.22,.02),material(['#c68183','#8ba8ad','#c6ac71','#a69ab9'][i]),g,.16,.55,0);g.userData.index=i;void flag;return g;});
 for(let i=0;i<3;i++){const a=markers[i].position,b=markers[i+1].position;curve(scene,[[a.x,.3,a.z],[0,.38,0],[b.x,.3,b.z]],.015,gold());}
 const boat=mesh(new T.ConeGeometry(.18,.5,4),material('#ebe1c9'),scene,0,.4,0);boat.rotation.z=Math.PI/2;
 return {pickables:markers,frame(_time,dt,state,reduced){markers.forEach((m,i)=>{m.scale.setScalar(state.selected===i?1.2:1);m.userData.pickDisabled=i>(state.growth??0);});const dest=markers[Math.min(3,state.selected??0)].position;boat.position.lerp(new T.Vector3(dest.x,.55,dest.z),reduced?1:1-Math.exp(-dt*3));stage.camera.position.set(0,5,Math.max(5.5,5.7/Math.max(.45,stage.camera.aspect)));stage.camera.lookAt(0,.2,0);}};
}

export function buildMirror(stage:Stage):Choreography {
 stageBase(stage,'#2b3941');const {scene}=stage;const frame=new T.Group();scene.add(frame);frame.position.y=1.35;
 const ring=mesh(new T.TorusGeometry(1.15,.085,12,80),gold(),frame);ring.scale.y=1.22;for(let i=0;i<24;i++){const a=i*Math.PI/12;const bead=mesh(new T.SphereGeometry(.06,12,8),gold(),frame,Math.sin(a)*1.15,Math.cos(a)*1.4,0);bead.scale.y=1.5;}
 const surface=mesh(new T.CircleGeometry(1.08,80),new T.MeshPhysicalMaterial({color:'#9caeb2',metalness:1,roughness:.13,clearcoat:1}),frame,0,0,-.02);surface.scale.y=1.22;
 const message=plaque(frame,'Happy Birthday, Bhumi.\nAn abstract reflection.\nNo portrait or camera.',1.6,.75,0,0,.03);
 const fogMat=new T.MeshPhysicalMaterial({color:'#dbe5de',transparent:true,opacity:.97,roughness:1,depthWrite:false});const fog=mesh(new T.CircleGeometry(1.07,80),fogMat,frame,0,0,.06);fog.scale.y=1.22;
 curve(scene,[[-.7,0,0],[-.7,.6,0]],.045,gold());curve(scene,[[.7,0,0],[.7,.6,0]],.045,gold());
 return {frame(_time,dt,state,reduced){fogMat.opacity=smooth(fogMat.opacity,1-(state.growth??0)*.98,dt,reduced);message.visible=(state.growth??0)>.1;frameCamera(stage,1.2,7);}};
}

export function buildCoupons(stage:Stage):Choreography {
 stageBase(stage,'#41392f');const {scene}=stage;const book=new T.Group();book.rotation.x=-.55;book.position.y=.35;scene.add(book);
 mesh(new T.BoxGeometry(3.2,2,.13),material('#865665',.8),book,0,0,-.1);for(let i=0;i<8;i++)mesh(new T.BoxGeometry(3.03,1.88,.014),paper(),book,.02,0,-.02+i*.018);
 for(let i=0;i<6;i++){const ring=mesh(new T.TorusGeometry(.09,.015,8,24),gold(),book,-1.48,-.75+i*.3,.03);ring.rotation.y=Math.PI/2;}
 const geo=new T.PlaneGeometry(2.98,1.88,40,16);geo.translate(1.49,0,0);const original=Float32Array.from(geo.attributes.position.array);const page=mesh(geo,paper(),book,-1.45,0,.15);page.material.side=T.DoubleSide;
 for(let i=0;i<20;i++)mesh(new T.BoxGeometry(.045,.007,.005),material('#9f8f74'),book,1.28,-.85+i*.09,.16);
 let last=-1,transport=1;return {frame(_time,dt,state,reduced){if(last!==(state.selected??0)){last=state.selected??0;transport=0;}transport=reduced?1:Math.min(1,transport+dt/1.1);const a=Math.sin(transport*Math.PI)*Math.PI*.9;const pos=geo.attributes.position;for(let i=0;i<pos.count;i++){const x=original[i*3],y=original[i*3+1],bend=a*x/2.98;pos.setXYZ(i,a<.001?x:Math.sin(bend)*2.98/a,y,a<.001?0:(1-Math.cos(bend))*2.98/a);}pos.needsUpdate=true;geo.computeVertexNormals();stage.camera.position.set(0,3.7,Math.max(5.5,5.3/Math.max(.45,stage.camera.aspect)));stage.camera.lookAt(0,.3,0);}};
}

export function buildHopeTree(stage:Stage):Choreography {
 stageBase(stage,'#3e5548');const {scene}=stage;const soil=material('#604835',1);soil.map=noiseTexture('#604835',57,65);soil.bumpMap=soil.map;soil.bumpScale=.09;
 const terrain=mesh(new T.CylinderGeometry(1.85,1.65,.8,80,8),soil,scene,0,.15,0);const ap=terrain.geometry.attributes.position;for(let i=0;i<ap.count;i++){const x=ap.getX(i),y=ap.getY(i),z=ap.getZ(i);if(y>.35)ap.setY(i,y+.05*Math.sin(x*8)*Math.cos(z*7));}terrain.geometry.computeVertexNormals();
 for(let i=0;i<75;i++){const a=i*2.39996,r=Math.sqrt((i+.5)/75)*1.7;const pebble=mesh(new T.DodecahedronGeometry(.025+(i%4)*.009,0),material(i%2?'#a18968':'#473d30'),scene,Math.cos(a)*r,.58,Math.sin(a)*r);pebble.scale.y=.6;}
 const seed=mesh(new T.SphereGeometry(.24,24,16),material('#805538',.8),scene,0,.68,.1);seed.scale.set(.7,1,.75);
 const roots=new T.Group();scene.add(roots);for(let i=0;i<9;i++){const a=i*2.39996;curve(roots,[[0,.55,.3],[Math.cos(a)*.35,.1,.4],[Math.cos(a)*.9,-.14,.8]],.025,material('#c4aa7d'));}
 const plant=new T.Group();plant.position.y=.57;scene.add(plant);branchTree(plant,material('#725838',.9));
 const leafGeo=new T.PlaneGeometry(.65,.32,18,8);const p=leafGeo.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i);const v=x/.65+.5;p.setY(i,y*Math.pow(Math.max(0,Math.sin(v*Math.PI)),.65));p.setZ(i,.09*Math.sin(v*Math.PI)+y*y*.2);}leafGeo.computeVertexNormals();const green=material('#6d8b56');green.side=T.DoubleSide;
 const leaves=Array.from({length:8},(_,i)=>{const a=i*2.39996;const g=new T.Group();g.position.set(Math.cos(a)*1.02,.65+i*.2+.55,Math.sin(a)*1.02);g.rotation.y=-a;plant.add(g);mesh(leafGeo,green,g);curve(g,[[-.3,0,0],[0,0,.09],[.3,0,0]],.006,material("#a2af7a"));g.userData.index=i;return g;});
 const blossom=new T.Group();plant.add(blossom);blossom.position.set(0,2.5,0);
 for(let i=0;i<11;i++){const a=i*Math.PI*2/11;const petal=mesh(new T.SphereGeometry(.12,16,10),material("#dcaeb7",.55),blossom,Math.sin(a)*.17,0,Math.cos(a)*.17);petal.scale.set(.6,.25,1.4);petal.rotation.y=a;}
 mesh(new T.SphereGeometry(.075,16,10),material("#c5a565"),blossom,0,.025,0);
 const pollenGeo=new T.BufferGeometry();const specks=new Float32Array(18*3);for(let i=0;i<18;i++)specks.set([Math.sin(i*17)*1.4,1.2+i%6*.2,Math.cos(i*9)*1.4],i*3);pollenGeo.setAttribute("position",new T.BufferAttribute(specks,3));const pollen=new T.Points(pollenGeo,new T.PointsMaterial({color:"#eadab1",size:.02,transparent:true,opacity:.45}));scene.add(pollen);
 const fireflies=Array.from({length:3},(_,i)=>mesh(new T.SphereGeometry(.018,8,6),new T.MeshStandardMaterial({color:"#e6df98",emissive:"#b9b557",emissiveIntensity:1.2}),scene,Math.sin(i*8)*1.4,1.1+i*.4,Math.cos(i*8)*1.3));
 const grassGeo=new T.ConeGeometry(.025,.23,4);const grass=new T.InstancedMesh(grassGeo,material('#697d4e'),80);const matrix=new T.Matrix4();for(let i=0;i<80;i++){const a=i*2.39996,r=1.2+(i%8)*.07;matrix.makeTranslation(Math.cos(a)*r,.67,Math.sin(a)*r);grass.setMatrixAt(i,matrix);}scene.add(grass);
 const butterfly=new T.Group();butterfly.position.set(1.3,1.9,.4);scene.add(butterfly);const wings=[-1,1].map(sign=>{const w=mesh(new T.SphereGeometry(.12,12,8),material('#c5a574'),butterfly,sign*.1,0,0);w.scale.set(1.2,.05,1);return w;});
 let growth=0;return {pickables:leaves,frame(time,dt,state,reduced){growth=smooth(growth,state.growth??0,dt,reduced);blossom.scale.setScalar(Math.max(.001,T.MathUtils.smoothstep(growth,7,8)));pollen.visible=growth>3;pollen.rotation.y=reduced?0:time*.06;fireflies.forEach((f,i)=>{f.position.y=1.1+i*.4+(reduced?0:Math.sin(time*.6+i)*.12);});roots.scale.setScalar(Math.max(.01,Math.min(1,growth)));seed.visible=growth<1.7;seed.rotation.z=growth*.15;plant.visible=growth>.7;const sprout=T.MathUtils.smoothstep(growth,.7,4);plant.scale.set(.35+sprout*.65,Math.max(.01,sprout),.35+sprout*.65);leaves.forEach((l,i)=>{const unfold=T.MathUtils.smoothstep(growth,i+.6,i+1.2);l.scale.setScalar(Math.max(.001,unfold)*(state.selected===i?1.15:1));l.rotation.z=(1-unfold)*1.2+(reduced?0:Math.sin(time*.7+i)*.025);});if(!reduced){butterfly.position.set(Math.cos(time*.4)*1.6,2+Math.sin(time*.8)*.25,Math.sin(time*.4)*1.2);wings.forEach((w,i)=>w.rotation.z=Math.sin(time*15)*(i?1:-1)*.6);}stage.camera.position.set(0,2.1+sprout,Math.max(6.8,5.7/Math.max(.45,stage.camera.aspect)));stage.camera.lookAt(0,.65+sprout*.6,0);}};
}

export function buildTreasure(stage:Stage):Choreography {
 stageBase(stage,'#283c3e');const {scene}=stage;const wood=material('#74513a',.72);wood.map=noiseTexture('#74513a',12,33);const brass=gold();mesh(new T.BoxGeometry(2.7,1.15,1.65),wood,scene,0,.48,0);
 const lid=new T.Group();lid.position.set(0,1.05,-.82);scene.add(lid);mesh(new T.BoxGeometry(2.75,.36,1.7),wood,lid,0,.12,.82);for(const x of [-1,1]){mesh(new T.BoxGeometry(.12,1.18,1.69),brass,scene,x,.48,0);mesh(new T.BoxGeometry(.12,.39,1.73),brass,lid,x,.12,.82);}
 const lock=mesh(new T.BoxGeometry(.3,.34,.12),brass,scene,0,.75,.89);mesh(new T.CircleGeometry(.045,20),material('#151e20'),lock,0,0,.07);
 const coins=Array.from({length:12},(_,i)=>{const c=mesh(new T.CylinderGeometry(.12,.12,.025,24),gold(),scene,Math.sin(i*3)*.8,.9+(i%3)*.04,Math.cos(i*2)*.5);c.rotation.x=.2;return c;});
 const key=new T.Group();scene.add(key);key.position.set(1.9,.25,.7);const bow=mesh(new T.TorusGeometry(.18,.035,8,32),brass,key);bow.rotation.x=Math.PI/2;mesh(new T.BoxGeometry(.035,.035,.65),brass,key,0,0,.4);mesh(new T.BoxGeometry(.15,.04,.05),brass,key,.05,0,.7);
 const tokens=Array.from({length:3},(_,i)=>{const t=mesh(new T.CylinderGeometry(.24,.24,.07,40),material(['#b47a84','#9baeb0','#b6a66b'][i],.36,.5),scene,-.7+i*.7,.13,1.45);t.userData.index=i;return t;});
 return {pickables:tokens,frame(_time,dt,state,reduced){lid.rotation.x=smooth(lid.rotation.x,state.open?-1.45:0,dt,reduced);coins.forEach(c=>c.visible=!!state.open);key.rotation.y=smooth(key.rotation.y,state.open?Math.PI:0,dt,reduced);tokens.forEach((t,i)=>t.position.y=smooth(t.position.y,state.selected===i?.33:.13,dt,reduced));frameCamera(stage,.7,7.8);}};
}

export function buildGiftWorld(stage:Stage,kind:WorldKind):Choreography {
 switch(kind){case'jar':return buildJar(stage);case'universe':return buildUniverse(stage);case'cassette':return buildAudioWorld(stage,false);case'vinyl':return buildAudioWorld(stage,true);case'cinema':return buildCinema(stage);case'wishes':return buildWishes(stage);case'cabinet':return buildCabinet(stage);case'machine':return buildMachine(stage);case'adventure':return buildAdventure(stage);case'mirror':return buildMirror(stage);case'coupons':return buildCoupons(stage);case'hope-tree':return buildHopeTree(stage);case'treasure':return buildTreasure(stage);}
}
