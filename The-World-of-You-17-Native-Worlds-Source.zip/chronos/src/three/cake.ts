import * as T from "three";
import { material, mesh, noiseTexture, type Stage, type Choreography } from "./scenePrimitives";

export function buildCake({ scene, camera, quality }: Stage): Choreography {
  scene.fog = new T.FogExp2("#302820", 0.035); camera.position.set(0, 3.5, 8.7); camera.lookAt(0, 1.3, 0);
  const wood = material("#674d3a"); wood.map = noiseTexture("#674d3a", 41, 28); wood.map.repeat.set(10, 2);
  mesh(new T.CylinderGeometry(5, 5, 0.2, 64), wood, scene, 0, -0.3, 0);
  const cake = new T.Group(); scene.add(cake);
  const board = material("#c6a875", 0.28, 0.75); mesh(new T.CylinderGeometry(1.9, 1.9, 0.07, 64), board, cake, 0, -0.12, 0);
  const cream = new T.MeshPhysicalMaterial({ color: "#fff0d7", roughness: 0.45, clearcoat: 0.12 });
  const sponge = material("#c79767", 0.95); sponge.map = noiseTexture("#c79767", 79, 82); sponge.bumpMap = sponge.map; sponge.bumpScale = 0.055; sponge.map.repeat.set(6, 2);
  const filling = material("#c9818e", 0.63);
  for (let layer = 0; layer < 3; layer++) { mesh(new T.CylinderGeometry(1.33, 1.33, 0.36, 72), sponge, cake, 0, 0.15 + layer * 0.47, 0); if (layer < 2) mesh(new T.CylinderGeometry(1.35, 1.35, 0.1, 72), filling, cake, 0, 0.38 + layer * 0.47, 0); }
  mesh(new T.CylinderGeometry(1.38, 1.39, 0.12, 72), cream, cake, 0, 1.32, 0);
  const dripPoints: T.Vector2[] = []; for (let i = 0; i <= 10; i++) { const t = i / 10; dripPoints.push(new T.Vector2(1.33 + Math.sin(t * Math.PI) * 0.045, 1.07 + t * 0.22)); }
  mesh(new T.LatheGeometry(dripPoints, 72), cream, cake);
  // Individual piped rosettes follow a small helix, rather than flat frosting disks.
  const pipingCount = quality === "low" ? 18 : 28;
  const rosettePoints = Array.from({ length: 30 }, (_, i) => { const t = i / 29; return new T.Vector3(Math.cos(t * Math.PI * 5) * 0.085 * (1 - t * 0.65), t * 0.14, Math.sin(t * Math.PI * 5) * 0.085 * (1 - t * 0.65)); });
  const pipeGeo = new T.TubeGeometry(new T.CatmullRomCurve3(rosettePoints), 30, 0.027, 5, false);
  for (let i = 0; i < pipingCount; i++) { const a = i / pipingCount * Math.PI * 2; mesh(pipeGeo, cream, cake, Math.cos(a) * 1.19, 1.39, Math.sin(a) * 1.19); }
  const berryMat = material("#9f354e", 0.36); berryMat.map = noiseTexture("#a43e56", 92, 40); berryMat.bumpMap = berryMat.map; berryMat.bumpScale = 0.035;
  for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; const berry = mesh(new T.SphereGeometry(0.12, 16, 12), berryMat, cake, Math.cos(a) * 0.94, 1.52, Math.sin(a) * 0.94); berry.scale.set(0.85, 1.2, 0.85); }
  const flameGeo = new T.SphereGeometry(1, 16, 20); flameGeo.translate(0, 1, 0);
  const candles = Array.from({ length: 5 }, (_, i) => {
    const a = i * Math.PI * 2 / 5 - Math.PI / 2; const group = new T.Group(); group.position.set(Math.cos(a) * 0.55, 1.38, Math.sin(a) * 0.55); cake.add(group);
    const wax = material(["#d0a0ac", "#dab778", "#abc1ad", "#dcae9b", "#cdc0da"][i], 0.4);
    mesh(new T.CylinderGeometry(0.045, 0.047, 0.55, 12), wax, group, 0, 0.28, 0);
    mesh(new T.CylinderGeometry(0.008, 0.008, 0.05, 6), material("#463227"), group, 0, 0.58, 0);
    const uniforms = { uTime: { value: 0 }, uWind: { value: 0 } };
    const flameMat = new T.ShaderMaterial({ uniforms, transparent: true, depthWrite: false,
      vertexShader: `uniform float uTime; uniform float uWind; varying float vHeight;
        void main(){ vec3 p=position; vHeight=p.y*0.5; float h=p.y*0.5; p.x*=0.8*(1.0-h*0.65); p.z*=0.65*(1.0-h*0.6); p.x+=sin(uTime*12.0+h*4.0)*h*h*0.12+uWind*h*h*1.2; p.y*=1.0+sin(uTime*9.0)*0.04; gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0); }`,
      fragmentShader: `varying float vHeight; void main(){ vec3 c=mix(vec3(1.0,0.97,0.65),vec3(1.0,0.28,0.025),smoothstep(0.1,0.95,vHeight)); gl_FragColor=vec4(c,0.92); }`,
    });
    const flame = mesh(flameGeo, flameMat, group, 0, 0.59, 0); flame.scale.set(0.055, 0.14, 0.055); flame.castShadow = false;
    const light = new T.PointLight("#ffb45f", 0, 2.5, 2); light.position.y = 0.78; group.add(light);
    const smoke = mesh(new T.PlaneGeometry(0.18, 0.6, 1, 8), new T.MeshBasicMaterial({ color: "#b6aaa0", transparent: true, opacity: 0, depthWrite: false, side: T.DoubleSide }), group, 0, 0.9, 0); smoke.visible = false;
    return { flame, light, uniforms, smoke, wasLit: false, smokeAge: 10 };
  });
  const assembled = cake.children.map((object, index) => ({ object, y: object.position.y, delay: index === 0 ? 0 : Math.min(4.8, index * 0.11) }));
  const preparation = new T.Group(); scene.add(preparation);
  const bowl = new T.Group(); bowl.position.set(-1.1, 0.35, 0); preparation.add(bowl);
  const ceramic = new T.MeshPhysicalMaterial({ color: "#eee1cd", roughness: 0.3, clearcoat: 0.5, side: T.DoubleSide });
  mesh(new T.SphereGeometry(0.68, 32, 20, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), ceramic, bowl);
  const rim = mesh(new T.TorusGeometry(0.68, 0.035, 8, 48), ceramic, bowl); rim.rotation.x = Math.PI / 2;
  const batterMat = material("#dbb57b", 0.36);
  const batter = mesh(new T.CircleGeometry(0.58, 40), batterMat, bowl, 0, -0.12, 0); batter.rotation.x = -Math.PI / 2;
  const tin = new T.Group(); tin.position.set(1, 0.05, 0); preparation.add(tin);
  const metal = material("#7e8585", 0.28, 0.8);
  mesh(new T.CylinderGeometry(0.72, 0.72, 0.06, 40), metal, tin);
  const wall = mesh(new T.CylinderGeometry(0.73, 0.73, 0.38, 40, 1, true), metal, tin, 0, 0.2, 0); wall.material.side = T.DoubleSide;
  const poured = mesh(new T.CylinderGeometry(0.69, 0.69, 0.28, 40), batterMat, tin, 0, 0.15, 0);
  const stream = mesh(new T.CylinderGeometry(0.045, 0.075, 1, 12), batterMat, preparation, 0.95, 0.75, 0);
  const flour = mesh(new T.BoxGeometry(0.65, 0.95, 0.45), material("#d8c3a3"), preparation, -2.3, 0.3, -0.8); flour.rotation.y = 0.2;
  const oven = new T.Group(); oven.position.set(0, 0.65, -0.5); scene.add(oven);
  const ovenMetal = material("#53615a", 0.4, 0.4);
  mesh(new T.BoxGeometry(2.5, 1.8, 1.3), ovenMetal, oven);
  mesh(new T.BoxGeometry(2.1, 1.35, 0.1), material("#251f1b"), oven, 0, -0.03, 0.7);
  const ovenDoor = new T.Group(); ovenDoor.position.set(0, -0.7, 0.8); oven.add(ovenDoor);
  const glass = new T.MeshPhysicalMaterial({ color: "#b78554", transparent: true, opacity: 0.35, roughness: 0.12, metalness: 0.2, side: T.DoubleSide });
  mesh(new T.BoxGeometry(2.05, 1.35, 0.045), glass, ovenDoor, 0, 0.66, 0);
  mesh(new T.BoxGeometry(1.65, 0.07, 0.1), metal, ovenDoor, 0, 1.14, 0.08);
  const ovenGlow = new T.PointLight("#ffac46", 0, 3); ovenGlow.position.set(0, 0.1, 0.9); oven.add(ovenGlow);
  const ovenSponge = mesh(new T.CylinderGeometry(0.68, 0.68, 0.4, 40), sponge, oven, 0, -0.25, 0.74);
  const dial = mesh(new T.TorusGeometry(0.13, 0.025, 8, 24), board, oven, 0.96, 0.7, 0.72);
  const timerHand = mesh(new T.BoxGeometry(0.02, 0.11, 0.02), board, dial, 0, 0.035, 0.02);
  let stageBefore = -1; let stageAge = 0;
  const curtain = material("#64544a"); for (const x of [-4, 4]) { const column = mesh(new T.CylinderGeometry(0.3, 0.3, 5, 16), curtain, scene, x, 2, -4); column.scale.x = 2; }
  const target = new T.Vector3();
  return { frame(time, dt, state, reduced) {
    const stage = state.bakeStage ?? 3;
    if (stage !== stageBefore) { stageBefore = stage; stageAge = 0; }
    stageAge = reduced ? 12 : stageAge + dt;
    preparation.visible = stage < 2; oven.visible = stage === 2; cake.visible = stage === 3;
    if (stage < 2) {
      const pour = stage === 1 ? T.MathUtils.smoothstep(stageAge, 0.7, 2.3) : 0;
      bowl.rotation.z = -pour * 0.95; bowl.position.y = 0.35 + pour * 1.1; bowl.position.x = -1.1 + pour * 1.4;
      stream.visible = stage === 1 && stageAge > 1.2 && stageAge < 3.5;
      poured.scale.y = stage === 0 ? 0.01 : Math.max(0.01, T.MathUtils.smoothstep(stageAge, 1.2, 3.6));
      batter.scale.setScalar(1 - pour * 0.3);
    }
    if (stage === 2) {
      const open = stageAge < 1 ? T.MathUtils.smoothstep(stageAge, 0, 0.6) : stageAge < 2 ? 1 - T.MathUtils.smoothstep(stageAge, 1.3, 2) : T.MathUtils.smoothstep(stageAge, 4, 4.8);
      ovenDoor.rotation.x = open * Math.PI * 0.47;
      ovenSponge.position.z = stageAge < 1.4 ? 1.7 - T.MathUtils.smoothstep(stageAge, 0.3, 1.4) * 0.96 : 0.74;
      ovenSponge.scale.y = 0.35 + T.MathUtils.smoothstep(stageAge, 2, 4) * 0.65;
      ovenGlow.intensity = stageAge > 1.5 ? 2 : 0;
      timerHand.rotation.z = -Math.min(stageAge / 4, 1) * Math.PI * 2;
    }
    assembled.forEach(({ object, y, delay }) => { const settle = T.MathUtils.smoothstep(stageAge, delay, delay + 0.6); object.visible = settle > 0; object.position.y = y + (1 - settle) * 1.8; });
    cake.rotation.y = reduced ? 0 : Math.sin(time * 0.13) * 0.13;
    candles.forEach((candle, i) => {
      const lit = i < (state.candles ?? 0);
      if (candle.wasLit && !lit) candle.smokeAge = 0; candle.wasLit = lit;
      candle.flame.visible = lit; candle.uniforms.uTime.value = reduced ? i : time + i * 2.3; candle.uniforms.uWind.value = state.blowing && !reduced ? 0.7 : 0;
      candle.light.intensity = lit ? (0.5 + (reduced ? 0 : Math.sin(time * 17 + i * 2.1) * 0.06 + Math.sin(time * 11 + i) * 0.03)) : 0;
      candle.smokeAge += dt; candle.smoke.visible = !reduced && !lit && candle.smokeAge < 1.6;
      candle.smoke.position.y = 0.85 + candle.smokeAge * 0.35; candle.smoke.position.x = Math.sin(candle.smokeAge * 3 + i) * 0.06;
      candle.smoke.lookAt(camera.position); (candle.smoke.material as T.MeshBasicMaterial).opacity = Math.max(0, 0.22 * (1 - candle.smokeAge / 1.6));
    });
    target.set(0, state.celebration ? 4.2 : 3.5, state.celebration ? 10 : camera.aspect < 1 ? 11 : 8.7);
    camera.position.lerp(target, reduced ? 1 : 1 - Math.exp(-dt * 1.5)); camera.lookAt(0, 1.2, 0);
  } };
}
