import {buildLetter} from './letter';
import {buildBotanicalGift,buildCrown} from './botanicalGift';
import {buildCelestial} from './celestial';
import {buildGiftWorld} from './giftWorlds';
import type {Stage,Choreography} from './runtime';
import type {GiftKind} from './GiftStage';
export const giftKinds:readonly GiftKind[]=['letter','jar','flower','universe','cassette','cinema','wishes','crown','cabinet','machine','adventure','vinyl','mirror','coupons','hope-tree','treasure','portal'];
export function createGift(stage:Stage,kind:GiftKind):Choreography{return kind==='letter'?buildLetter(stage):kind==='flower'?buildBotanicalGift(stage):kind==='crown'?buildCrown(stage):kind==='portal'?buildCelestial(stage,true):buildGiftWorld(stage,kind);}
