import * as T from 'three';
export function disposeTree(root:T.Object3D){
 const resources=new Set<{dispose:()=>void}>();
 root.traverse(o=>{if(o instanceof T.Mesh||o instanceof T.Points||o instanceof T.Line){resources.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material]){resources.add(m);for(const value of Object.values(m))if(value instanceof T.Texture)resources.add(value);}}if(o instanceof T.InstancedMesh)resources.add(o);if(o instanceof T.Light&&'shadow'in o)(o as T.DirectionalLight).shadow?.dispose();});
 resources.forEach(r=>r.dispose());root.clear();
}
