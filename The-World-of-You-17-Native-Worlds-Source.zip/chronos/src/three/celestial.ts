import * as T from "three";
import { mesh, material, type Stage, type Choreography } from "./scenePrimitives";

export function buildCelestial({ scene, camera, quality }: Stage, portal: boolean): Choreography {
  scene.background = new T.Color("#151d2b"); scene.fog = new T.FogExp2("#151d2b", 0.025);
  camera.position.set(0, 1, 8); camera.lookAt(0, 0.5, 0);
  const count = quality === "low" ? 160 : 500; const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) positions.set([Math.sin(i * 32.3) * 16, Math.cos(i * 16.7) * 10, -4 - (i % 40) * 0.7], i * 3);
  const geometry = new T.BufferGeometry(); geometry.setAttribute("position", new T.BufferAttribute(positions, 3));
  const stars = new T.Points(geometry, new T.PointsMaterial({ color: "#e9dbb9", size: 0.035, sizeAttenuation: true })); scene.add(stars);
  const gold = material("#b99b68", 0.26, 0.8); const silver = material("#d2c6a6", 0.3, 0.65);
  if (portal) {
    const rings = Array.from({ length: 3 }, (_, i) => { const ring = mesh(new T.TorusGeometry(1.8 + i * 0.12, 0.035, 12, 100), i % 2 ? silver : gold, scene, 0, 0.5, -i * 0.2); ring.rotation.x = i * 0.2; return ring; });
    const uniforms = { uTime: { value: 0 }, uOpen: { value: 0 } };
    const surface = mesh(new T.CircleGeometry(1.75, 80), new T.ShaderMaterial({ uniforms, transparent: true, side: T.DoubleSide,
      vertexShader: 'varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
      fragmentShader: 'varying vec2 vUv;uniform float uTime;uniform float uOpen;void main(){vec2 p=vUv-.5;float r=length(p);float a=atan(p.y,p.x);float ripple=sin(r*65.-uTime*1.6+a*3.)*.5+.5;vec3 c=mix(vec3(.13,.2,.32),vec3(.66,.44,.27),ripple*.6);float edge=smoothstep(.15,.5,r);gl_FragColor=vec4(c,edge*(.3+uOpen*.65));}'
    }), scene, 0, 0.5, -0.35);
    surface.castShadow = false;
    const lightGeo=new T.SphereGeometry(.055,12,8);const lightMat=new T.MeshStandardMaterial({color:"#f0dca0",emissive:"#b99145",emissiveIntensity:1.2});
    const gathered=Array.from({length:16},(_,i)=>mesh(lightGeo,lightMat,scene,Math.sin(i*19)*3.6,.5+Math.cos(i*13)*2.3,Math.sin(i*7)*1.5));

    return { frame(time, dt, state, reduced) { gathered.forEach((light,i)=>{const a=i*Math.PI/8;const target=(state.growth??(state.open?1:0))>0?new T.Vector3(Math.cos(a)*2.25,.5+Math.sin(a)*2.25,0):new T.Vector3(Math.sin(i*19)*3.6,.5+Math.cos(i*13)*2.3,Math.sin(i*7)*1.5);light.position.lerp(target,reduced?1:1-Math.exp(-dt*2));}); uniforms.uTime.value = reduced ? 0 : time; uniforms.uOpen.value = reduced ? (state.open ? 1 : 0) : T.MathUtils.damp(uniforms.uOpen.value, state.open ? 1 : 0, 2, dt); rings.forEach((ring, i) => { ring.rotation.z = reduced ? i * 0.3 : time * 0.07 * (i % 2 ? -1 : 1); ring.rotation.y = (state.open ? 0.05 : 0.3) * Math.sin(time * 0.2 + i); }); camera.position.z = reduced ? Math.max(state.open?6.5:8,5.6/Math.max(.45,camera.aspect)) : T.MathUtils.damp(camera.position.z, Math.max(state.open ? 6.5 : 8,5.6/Math.max(.45,camera.aspect)), 1.5, dt); } };
  }
  const clock = new T.Group(); scene.add(clock); clock.position.y = 0.7;
  const rim = mesh(new T.TorusGeometry(1.5, 0.07, 16, 80), gold, clock);
  mesh(new T.CylinderGeometry(1.45, 1.45, 0.12, 64), material("#253441", 0.65), clock).rotation.x = Math.PI / 2;
  for (let i = 0; i < 60; i++) { const a = i * Math.PI / 30; const tick = mesh(new T.BoxGeometry(0.02, i % 5 === 0 ? 0.16 : 0.06, 0.025), gold, clock, Math.sin(a) * 1.31, Math.cos(a) * 1.31, 0.09); tick.rotation.z = -a; }
  const hourPivot = new T.Group(); const minutePivot = new T.Group(); clock.add(hourPivot, minutePivot);
  mesh(new T.BoxGeometry(0.055, 0.7, 0.04), gold, hourPivot, 0, 0.3, 0.14); mesh(new T.BoxGeometry(0.028, 1.03, 0.03), silver, minutePivot, 0, 0.43, 0.18);
  mesh(new T.SphereGeometry(0.085, 16, 10), gold, clock, 0, 0, 0.2);
  const gears = Array.from({ length: 4 }, (_, i) => { const g = new T.Group(); g.position.set((i % 2 ? 1 : -1) * (1.7 + i * 0.12), -0.9 - i % 2 * 0.35, -0.05); scene.add(g); const r = 0.38 + i % 2 * 0.12; mesh(new T.TorusGeometry(r, 0.065, 8, 32), gold, g); for (let j = 0; j < 14; j++) { const a = j * Math.PI / 7; const tooth = mesh(new T.BoxGeometry(0.09, 0.14, 0.1), gold, g, Math.sin(a) * r, Math.cos(a) * r, 0); tooth.rotation.z = -a; } return g; });
  const pendulum = new T.Group(); pendulum.position.set(0, -0.8, 0); scene.add(pendulum); mesh(new T.CylinderGeometry(0.015, 0.015, 1.25, 8), gold, pendulum, 0, -0.63, 0); mesh(new T.SphereGeometry(0.2, 24, 16), gold, pendulum, 0, -1.3, 0);
  mesh(new T.SphereGeometry(0.55, 32, 24), material("#c7c7b5"), scene, 3.6, 2.4, -3);
  rim.rotation.z = 0;
  return { frame(time, dt, state, reduced) { const date = new Date(); hourPivot.rotation.z = -(date.getHours() % 12 + date.getMinutes() / 60) * Math.PI / 6; minutePivot.rotation.z = -(date.getMinutes() + date.getSeconds() / 60) * Math.PI / 30; gears.forEach((g, i) => { g.rotation.z = reduced ? 0 : time * 0.16 * (i % 2 ? -1 : 1); }); pendulum.rotation.z = reduced ? 0 : Math.sin(time * 1.8) * 0.16; stars.rotation.z = reduced ? 0 : time * 0.003; camera.position.z = T.MathUtils.damp(camera.position.z, state.open ? 6.8 : camera.aspect < 1 ? 11.5 : 8, 1.5, dt); camera.lookAt(0, 0.25, 0); } };
}
