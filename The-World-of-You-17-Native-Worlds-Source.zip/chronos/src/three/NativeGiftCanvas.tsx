import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import * as T from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {createGift} from './giftFactory';
import {disposeTree} from './disposeTree';
import type {Choreography,SceneState} from './runtime';
import type {GiftStageProps} from './GiftStage';

function World({props,reduced,active,host,quality}:{props:GiftStageProps;reduced:boolean;active:boolean;host:HTMLDivElement|null;quality:'low'|'medium'|'high'}){
 const {scene,camera,gl,invalidate,setDpr}=useThree();const latest=useRef(props);latest.current=props;const model=useRef<Choreography|null>(null);const elapsed=useRef(0);const slow=useRef(0);const stamp=useRef(performance.now());const spectrum=useRef(new Uint8Array(64));
 useLayoutEffect(()=>{
  const root=new T.Scene();scene.add(root);const hemi=new T.HemisphereLight('#fff0d6','#47544f',1.1);root.add(hemi);const key=new T.DirectionalLight('#ffe5c2',3.2);key.position.set(-3,7,5);key.castShadow=quality!=='low';key.shadow.mapSize.setScalar(quality==='high'?2048:1024);Object.assign(key.shadow.camera,{left:-5,right:5,top:6,bottom:-4});key.shadow.bias=-.0005;root.add(key);
  let target:T.WebGLRenderTarget|undefined;let studioTexture:T.CanvasTexture|undefined;
  if(quality!=='low'){const pmrem=new T.PMREMGenerator(gl);const room=new RoomEnvironment();target=pmrem.fromScene(room,.01,.1,100,{size:quality==='high'?128:64});root.environment=target.texture;scene.environment=target.texture;scene.environmentIntensity=.45;room.dispose();pmrem.dispose();} else {
    const c=document.createElement('canvas');c.width=128;c.height=64;const x=c.getContext('2d')!;const gradient=x.createLinearGradient(0,0,0,64);gradient.addColorStop(0,'#d7e2dd');gradient.addColorStop(.5,'#768b88');gradient.addColorStop(1,'#263b33');x.fillStyle=gradient;x.fillRect(0,0,128,64);x.fillStyle='#f2e6ce';x.fillRect(18,14,10,28);x.fillStyle='#dbeaf0';x.fillRect(86,18,15,24);studioTexture=new T.CanvasTexture(c);studioTexture.colorSpace=T.SRGBColorSpace;studioTexture.mapping=T.EquirectangularReflectionMapping;scene.environment=studioTexture;scene.environmentIntensity=.4;
  }

  const stage={scene:root,camera:camera as T.PerspectiveCamera,quality,pick:(i:number)=>latest.current.onPick?.(i),report:(p:number)=>latest.current.onProgress?.(p)};
  let choreography:Choreography;
  try{choreography=createGift(stage,props.kind);}
  catch(e){disposeTree(root);target?.dispose();studioTexture?.dispose();scene.remove(root);throw e;}
  model.current=choreography;scene.background=root.background;scene.fog=root.fog;
  if(host){host.dataset.nativeReady='true';host.dataset.nativeKind=props.kind;}
  const ray=new T.Raycaster(),point=new T.Vector2();let downX=0,downY=0;
  const down=(e:PointerEvent)=>{downX=e.clientX;downY=e.clientY;};
  const up=(e:PointerEvent)=>{if(Math.hypot(e.clientX-downX,e.clientY-downY)>12)return;const r=gl.domElement.getBoundingClientRect();point.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(point,camera);for(const hit of ray.intersectObjects(choreography.pickables??[],true)){let o:T.Object3D|null=hit.object;while(o&&o.userData.index===undefined)o=o.parent;if(o&&!o.userData.pickDisabled){latest.current.onPick?.(o.userData.index as number);break;}}};
  gl.domElement.addEventListener('pointerdown',down);gl.domElement.addEventListener('pointerup',up);invalidate();
  return()=>{model.current=null;gl.domElement.removeEventListener('pointerdown',down);gl.domElement.removeEventListener('pointerup',up);choreography.dispose?.();scene.remove(root);scene.environment=null;scene.fog=null;target?.dispose();studioTexture?.dispose();disposeTree(root);if(host)host.dataset.nativeReady='false';};
 },[props.kind,quality,scene,camera,gl,invalidate,host]);
 useEffect(()=>{stamp.current=performance.now();invalidate();},[reduced,active,invalidate]);
 useEffect(()=>{invalidate();},[props.state,invalidate]);
 useFrame((_frame,rawDt)=>{
  if(!active||!model.current)return;const dt=Math.min(rawDt,.05);if(!reduced)elapsed.current+=dt;
  let state:SceneState=latest.current.state;
  const analyser=latest.current.analyser;if(analyser&&state.playing){analyser.getByteFrequencyData(spectrum.current);state={...state,spectrum:Array.from({length:12},(_,i)=>spectrum.current[i*4]/255)};}
  const now=performance.now();const timelineDt=(now-stamp.current)/1000;stamp.current=now;
  model.current.frame(elapsed.current,dt,state,reduced,timelineDt);
  if(host){queueMicrotask(()=>{host.dataset.triangles=String(gl.info.render.triangles);});host.dataset.renderFrames=String(Number(host.dataset.renderFrames??0)+1);host.dataset.reducedMotion=String(reduced);host.dataset.sceneActive=String(active);}
  if(!reduced){if(rawDt>.055)slow.current+=rawDt;else slow.current=Math.max(0,slow.current-dt);if(slow.current>3){setDpr(1);slow.current=-100;}invalidate();}
 });return null;
}
export default function NativeGiftCanvas(props:GiftStageProps){
 const ref=useRef<HTMLDivElement>(null);const [host,setHost]=useState<HTMLDivElement|null>(null);const [active,setActive]=useState(true);const [reduced,setReduced]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches);const [quality,setQuality]=useState<'low'|'medium'|'high'>(()=>innerWidth<700||navigator.hardwareConcurrency<=4?'low':'medium');const [ready,setReady]=useState(false);
 useEffect(()=>{const node=ref.current;setHost(node);const pref=matchMedia('(prefers-reduced-motion: reduce)');let visible=true;const sync=()=>{setReduced(pref.matches);setActive(visible&&!document.hidden);};const observer=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;sync();});if(node)observer.observe(node);document.addEventListener('visibilitychange',sync);pref.addEventListener('change',sync);return()=>{observer.disconnect();document.removeEventListener('visibilitychange',sync);pref.removeEventListener('change',sync);};},[]);
 return <div className="gift-native-canvas" ref={ref} role="img" aria-label={props.label} data-reduced-motion={String(reduced)}>
  <Canvas key={quality} frameloop="demand" dpr={quality==='low'?1:quality==='high'?[1,1.7]:[1,1.35]} shadows={quality!=='low'} camera={{position:[0,2.6,8],fov:38,near:.1,far:80}} gl={{antialias:quality!=='low',powerPreference:'low-power'}} onCreated={({gl})=>{gl.toneMapping=T.ACESFilmicToneMapping;gl.toneMappingExposure=1;setReady(true);}} fallback={<div className="gift-stage-fallback" role="status">WebGL unavailable. Use the content and controls below.</div>}>
   <World props={props} host={host} quality={quality} reduced={reduced} active={active}/>
  </Canvas>
  <div className="gift-native-chrome"><span>THE WORLD OF YOU / {props.kind.toUpperCase()}</span><label>Detail <select aria-label={`${props.kind} graphics quality`} value={quality} onChange={e=>{setReady(false);setQuality(e.target.value as typeof quality);}}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label></div>
  <span className="gift-native-status" role="status">{ready?'Real-time 3D ready':'Preparing the real-time scene…'}</span>
 </div>;
}
