import { useEffect, useRef, useState } from "react";
import type { SceneState, SceneRuntime } from "./runtime";

export type Quality = "low" | "medium" | "high";
export function SceneCanvas({ kind, state, onPick, onProgress, label }: { kind: "garden" | "cake" | "letter" | "portal" | "observatory" | "flower" | "crown" | "postcard"; state: SceneState; onPick?: (index: number) => void; onProgress?: (progress: number) => void; label: string }) {
  const host = useRef<HTMLDivElement>(null);
  const runtime = useRef<SceneRuntime | null>(null);
  const latest = useRef(state);
  const pick = useRef(onPick);
  const progress = useRef(onProgress);
  progress.current = onProgress;
  const [quality, setQuality] = useState<Quality>(() => window.innerWidth < 700 || navigator.hardwareConcurrency <= 4 ? "low" : "medium");
  const [status, setStatus] = useState("Preparing the real-time scene…");
  const [failed, setFailed] = useState(false);
  latest.current = state;
  pick.current = onPick;
  useEffect(() => { runtime.current?.update(state); }, [state]);

  useEffect(() => {
    const node = host.current;
    if (!node) return;
    let cancelled = false;
    let loading = false;
    let visible = false;
    let current: SceneRuntime | null = null;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => current?.activity(visible && !document.hidden, preference.matches);
    const start = async () => {
      if (loading || current || cancelled) return;
      loading = true;
      try {
        const { createRuntime } = await import("./runtime");
        if (cancelled) return;
        current = createRuntime(node, kind, quality, latest.current, (index) => pick.current?.(index), (value) => progress.current?.(value), (reason) => {if (!cancelled) {setFailed(true);setStatus(reason);}});
        runtime.current = current;
        sync();
        setFailed(false);
        setStatus("Real-time 3D ready");
      } catch {
        if (!cancelled) { setFailed(true); setStatus("3D is unavailable on this device. All controls and content remain usable below."); }
      }
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) void start();
      sync();
    }, { rootMargin: "100px" });
    observer.observe(node);
    const lost = (event: Event) => {
      event.preventDefault();
      current?.activity(false, true);
      setFailed(true);
      setStatus("The graphics context was interrupted. Content controls below still work; change quality to reload 3D.");
    };
    node.addEventListener("webglcontextlost", lost, true);
    document.addEventListener("visibilitychange", sync);
    preference.addEventListener("change", sync);
    return () => {
      cancelled = true;
      observer.disconnect();
      node.removeEventListener("webglcontextlost", lost, true);
      document.removeEventListener("visibilitychange", sync);
      preference.removeEventListener("change", sync);
      current?.dispose();
      if (runtime.current === current) runtime.current = null;
    };
  }, [kind, quality]);

  return <div className={`cinematic-viewport cinematic-viewport--${kind}${failed ? " is-unavailable" : ""}`}>
    <div className="cinematic-viewport__canvas" ref={host} role="img" aria-label={label} />
    <div className="cinematic-viewport__top"><span>THE WORLD OF YOU <i> / </i> {kind === "garden" ? "BOTANICAL CONSERVATORY" : kind === "cake" ? "PÂTISSERIE" : kind === "letter" ? "THE WRITING DESK" : kind === "postcard" ? "POSSIBLE DAYS" : kind === "portal" ? "THE SEVENTEENTH DOOR" : kind === "flower" ? "THE ETERNAL ROSE" : kind === "crown" ? "THE CROWN JEWELS" : "THE MEMORY OBSERVATORY"}</span>
      <label>Detail <select value={quality} onChange={(event) => { setStatus("Preparing the real-time scene…"); setQuality(event.target.value as Quality); }} aria-label={`${kind} graphics quality`}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label></div>
    <span className="cinematic-viewport__status" role="status">{status}</span>
  </div>;
}
