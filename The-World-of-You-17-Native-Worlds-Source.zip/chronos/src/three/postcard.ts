import * as T from 'three';
import {material, mesh, noiseTexture, type Stage, type Choreography} from './scenePrimitives';

/** A tangible card, not a CSS-rotated image. DOM artwork/copy stays available below. */
export function buildPostcard({scene,camera}:Stage):Choreography {
  scene.background=new T.Color('#303b39');
  mesh(new T.BoxGeometry(12,.16,8),material('#586257',.92),scene,0,-1.65,0);
  const paper=material('#f3e4ca',.9);paper.map=noiseTexture('#f3e4ca',27,13);
  const card=mesh(new T.BoxGeometry(3.8,2.5,.035,32,24,1),paper,scene);
  const faceCanvas=document.createElement('canvas');faceCanvas.width=1024;faceCanvas.height=672;
  const ctx=faceCanvas.getContext('2d')!;
  const texture=new T.CanvasTexture(faceCanvas);texture.colorSpace=T.SRGBColorSpace;
  const ink=new T.MeshStandardMaterial({map:texture,roughness:.95,polygonOffset:true,polygonOffsetFactor:-1});
  const frontInk=new T.MeshStandardMaterial({color:"#ffffff",roughness:.9});
  const face=mesh(new T.PlaneGeometry(3.79,2.49),frontInk,card,0,0,.019);
  // Reverse-side message is correctly oriented when the card rotates through pi.
  const back=mesh(new T.PlaneGeometry(3.79,2.49),ink,card,0,0,-.019);back.rotation.y=Math.PI;
  let text='',turn=0,art='',disposed=false;
  let request=0;
  const loader=new T.TextureLoader();
  return {pickables:[card],dispose(){disposed=true;request++;},frame(time,dt,state,reduced,timelineDt){
    if(art!==state.artwork && state.artwork){
      art=state.artwork;const current=++request;
      loader.load(art,(loaded)=>{if(disposed||current!==request){loaded.dispose();return;}loaded.colorSpace=T.SRGBColorSpace;frontInk.map?.dispose();frontInk.map=loaded;frontInk.needsUpdate=true;},undefined,()=>{});
    }
    if(text!==state.detail){text=state.detail??'';ctx.fillStyle='#f3e4ca';ctx.fillRect(0,0,1024,672);ctx.strokeStyle='#b8a182';ctx.lineWidth=2;ctx.strokeRect(35,35,954,602);ctx.font='18px Georgia';ctx.fillStyle='#795f46';ctx.fillText('THE WORLD OF YOU  /  AN IMAGINED POSSIBILITY',65,85);ctx.font='italic 30px Georgia';ctx.fillStyle='#493d33';let y=155;for(const paragraph of text.split('\n')){let line='';for(const word of paragraph.split(/\s+/)){if(ctx.measureText(line+word).width>850){ctx.fillText(line,65,y);y+=43;line='';}line+=word+' ';}ctx.fillText(line,65,y);y+=65;}texture.needsUpdate=true;}
    const target=state.open?1:0;turn=reduced||state.immediate?target:T.MathUtils.clamp(turn+(target>turn?1:target<turn?-1:0)*(timelineDt??dt)/1.1,0,1);
    card.rotation.y=T.MathUtils.smootherstep(turn,0,1)*Math.PI;card.rotation.z=-.035;card.position.y=Math.sin(turn*Math.PI)*.12;
    face.visible=turn<.5;back.visible=turn>=.5;
    camera.position.set(0,.2,Math.max(6.3,6.2/Math.max(.4,camera.aspect)));camera.lookAt(0,0,0);
    card.userData.index=0;
    void time;
  }};
}
