// Offline authoring entry used by scripts/export-models.mjs, never imported by the app.
import * as T from "three";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { buildGarden } from "./garden";
import { buildCake } from "./cake";
import { buildLetter } from "./letter";
import { buildBotanicalGift, buildCrown } from "./botanicalGift";
import { buildCelestial } from "./celestial";
import type { Choreography, SceneState } from "./runtime";
export async function exportModel(name: string): Promise<string> {
  const scene = new T.Scene(); const camera = new T.PerspectiveCamera(38, 1.5, 0.1, 100);
  const stage = { scene, camera, quality: "low" as const, pick: () => {} };
  let model: Choreography; let state: SceneState = {};
  switch (name) {
    case "garden": model = buildGarden(stage); state = { selected: 0 }; break;
    case "cake": model = buildCake(stage); state = { bakeStage: 3 }; break;
    case "letter-desk": model = buildLetter(stage); state = { open: true }; break;
    case "eternal-rose": model = buildBotanicalGift(stage); state = { growth: 3 }; break;
    case "crown": model = buildCrown(stage); break;
    case "portal": model = buildCelestial(stage, true); state = { open: true }; break;
    case "observatory": model = buildCelestial(stage, false); break;
    default: throw new Error("Unknown authored model");
  }
  model.frame(0, 1, state, true); scene.updateMatrixWorld(true);
  // GLB is a static interchange snapshot. Runtime GLSL and instanced wind remain in source.
  const unsupported: T.Object3D[] = [];
  scene.traverse((object) => { if (object instanceof T.Mesh && (Array.isArray(object.material) ? object.material : [object.material]).some((mat) => mat instanceof T.ShaderMaterial)) unsupported.push(object); });
  unsupported.forEach((object) => object.removeFromParent());
  const result = await new GLTFExporter().parseAsync(scene, { binary: true, onlyVisible: true, maxTextureSize: 128 });
  const bytes = new Uint8Array(result as ArrayBuffer); let string = "";
  for (let i = 0; i < bytes.length; i += 8192) string += String.fromCharCode(...bytes.subarray(i, i + 8192));
  return btoa(string);
}
