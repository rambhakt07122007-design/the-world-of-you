import * as T from "three";
import { material, mesh, noiseTexture, type Stage, type Choreography } from "./scenePrimitives";

// Curved, tapered surface, with a narrow attachment point and raised petal edges.
function petalGeometry(length: number, width: number, cup: number, low = false) {
  const geo = new T.PlaneGeometry(1, 1, low ? 8 : 16, low ? 12 : 24); const positions = geo.attributes.position;
  for (let i = 0; i < positions.count; i++) {
    const u = positions.getX(i) * 2; const v = positions.getY(i) + 0.5;
    positions.setXYZ(i, u * width * Math.pow(Math.sin(Math.PI * v), 0.7), v * length, cup * (u * u * v + 0.4 * Math.sin(v * Math.PI)));
  }
  geo.computeVertexNormals(); return geo;
}
export function buildGarden({ scene, camera, quality }: Stage): Choreography {
  scene.fog = new T.FogExp2("#a6b4a1", 0.035);
  camera.position.set(0, 4.3, 12); camera.lookAt(0, 1.5, 0);
  const soil = material("#564b36"); soil.map = noiseTexture("#66513e", 17, 65); soil.map.repeat.set(12, 12);
  mesh(new T.CylinderGeometry(8, 8.4, 0.4, 64), soil, scene, 0, -0.3, 0);
  const green = material("#375337"); const leafMat = material("#4c7043"); leafMat.side = T.DoubleSide;
  const stone = material("#a7a48c");
  for (let i = 0; i < 34; i++) { const a = i * 2.4; const r = 5.6 + Math.sin(i * 3) * 0.5; const pebble = mesh(new T.DodecahedronGeometry(0.18 + i % 3 * 0.05, 1), stone, scene, Math.cos(a) * r, 0, Math.sin(a) * r); pebble.scale.set(1.4, 0.65, 1); pebble.rotation.set(i, i * 0.7, 0); }
  const hill = material("#6b806b");
  for (let i = 0; i < 7; i++) { const mound = mesh(new T.SphereGeometry(1, 24, 16), hill, scene, (i - 3) * 5, -1.5, -14 - i % 2 * 4); mound.scale.set(7, 3 + i % 3, 5); }
  const bark = material("#554a35");
  const treeLeaves = new T.InstancedMesh(new T.SphereGeometry(1, quality === "low" ? 4 : 6, quality === "low" ? 2 : 4), material("#56704b"), quality === "low" ? 1500 : 3500);
  const leafDummy = new T.Object3D();
  const perTree = treeLeaves.count / 5;
  for (let i = 0; i < 5; i++) {
    const x = (i - 2) * 4.5; const z = -6 - i % 2 * 2;
    mesh(new T.CylinderGeometry(0.10, 0.23, 3.8, 10), bark, scene, x, 1.7, z);
    for (let j = 0; j < 6; j++) { const branch = mesh(new T.CylinderGeometry(0.025, 0.07, 1.6, 7), bark, scene, x + Math.sin(j * 2.4) * 0.4, 2.7 + j % 3 * 0.35, z + Math.cos(j * 2.4) * 0.4); branch.rotation.z = Math.sin(j * 2.4) * 0.7; branch.rotation.x = Math.cos(j * 2.4) * 0.7; }
    for (let j = 0; j < perTree; j++) {
      const k = i * perTree + j; const a = j * 2.39996; const elevation = Math.acos(1 - 2 * ((j + 0.5) / perTree)); const radius = 0.7 + (Math.sin(j * 17.1) * 0.5 + 0.5) * 1.1;
      leafDummy.position.set(x + Math.sin(elevation) * Math.cos(a) * radius, 3.9 + Math.cos(elevation) * radius * 0.8, z + Math.sin(elevation) * Math.sin(a) * radius);
      leafDummy.rotation.set(j * 0.7, j * 1.3, j * 2.1); leafDummy.scale.set(0.17 + j % 3 * 0.02, 0.035, 0.32); leafDummy.updateMatrix(); treeLeaves.setMatrixAt(k, leafDummy.matrix); treeLeaves.setColorAt(k, new T.Color().setHSL(0.23 + j % 4 * 0.01, 0.24, 0.18 + j % 7 * 0.025));
    }
  }
  treeLeaves.computeBoundingSphere(); scene.add(treeLeaves);
  const windTime = { value: 0 };
  const grassMat = material("#5d7946"); grassMat.side = T.DoubleSide;
  grassMat.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = windTime;
    shader.vertexShader = "uniform float uWindTime;\n" + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace("#include <begin_vertex>", `#include <begin_vertex>
      float phase = instanceMatrix[3].x * 1.7 + instanceMatrix[3].z * 0.8;
      transformed.x += sin(uWindTime * 1.4 + phase) * pow(max(position.y, 0.0), 2.0) * 0.35;
      transformed.z += cos(uWindTime + phase) * pow(max(position.y, 0.0), 2.0) * 0.18;`);
  };
  const grassGeo = new T.ConeGeometry(0.018, 0.35, 3, 1, true); grassGeo.translate(0, 0.175, 0);
  const grass = new T.InstancedMesh(grassGeo, grassMat, quality === "high" ? 14000 : quality === "medium" ? 8500 : 4500);
  const dummy = new T.Object3D();
  for (let i = 0; i < grass.count; i++) { const a = i * 2.39996; const r = Math.sqrt((i + 0.5) / grass.count) * 7.6; dummy.position.set(Math.cos(a) * r, -0.07, Math.sin(a) * r); dummy.rotation.set(0, i, Math.sin(i * 3) * 0.15); dummy.scale.setScalar(0.7 + (i % 7) * 0.1); dummy.updateMatrix(); grass.setMatrixAt(i, dummy.matrix); grass.setColorAt(i, new T.Color().setHSL(0.22 + (i % 5) * 0.007, 0.28, 0.2 + i % 8 * 0.016)); }
  grass.computeBoundingSphere(); scene.add(grass);
  const roseGeo = petalGeometry(0.66, 0.27, 0.18, quality === "low"); const daisyGeo = petalGeometry(0.68, 0.13, 0.04, quality === "low"); const tulipGeo = petalGeometry(0.72, 0.31, 0.24, quality === "low"); const leafGeo = petalGeometry(0.65, 0.13, 0.05, quality === "low");
  const hues = ["#d498a8", "#f3e6c3", "#d19e78", "#b4b8d1", "#c9788d", "#f4d6b2", "#dcb1c4", "#f3ead5", "#e8ae85", "#b696b1", "#d4b783"];
  const flowers = Array.from({ length: 11 }, (_, index) => {
    const group = new T.Group(); group.userData.index = index; group.position.set(index === 10 ? 0 : (index % 5 - 2) * 1.65 + (index > 4 ? 0.35 : 0), 0, index === 10 ? 2.2 : index < 5 ? 0.5 : -1.7); scene.add(group);
    const stalk = new T.Group(); group.add(stalk); const height = 1.2 + (index % 4) * 0.22;
    mesh(new T.CylinderGeometry(0.025, 0.046, height, 8), green, stalk, 0, height / 2, 0);
    const leaves: T.Group[] = [];
    for (let j = 0; j < 3; j++) { const leaf = new T.Group(); leaf.position.y = height * (0.25 + j * 0.18); leaf.rotation.y = j * 2.6; const blade = mesh(leafGeo, leafMat, leaf); blade.rotation.x = 1.1; stalk.add(leaf); leaves.push(leaf); }
    const head = new T.Group(); head.position.y = height; stalk.add(head);
    const type = index % 3; const count = type === 0 ? 18 : type === 1 ? 13 : 6; const hinges: T.Group[] = [];
    const petalMat = material(hues[index], 0.48); petalMat.side = T.DoubleSide;
    petalMat.map = noiseTexture(hues[index], 30 + index, 15); petalMat.bumpMap = petalMat.map; petalMat.bumpScale = 0.035;
    for (let j = 0; j < count; j++) {
      const pivot = new T.Group(); pivot.rotation.y = j * 2.39996; head.add(pivot);
      const hinge = new T.Group(); hinge.position.set(0, (type === 0 ? Math.floor(j / 6) : 0) * 0.04, 0.035); pivot.add(hinge);
      const petal = mesh(type === 0 ? roseGeo : type === 1 ? daisyGeo : tulipGeo, petalMat, hinge); petal.rotation.z = Math.sin(j * 2) * 0.07; hinges.push(hinge);
    }
    const center = mesh(new T.SphereGeometry(type === 1 ? 0.18 : 0.12, 14, 10), material("#b88d39"), head, 0, 0.07, 0); center.scale.y = 0.6;
    if (quality !== "low") { for (let d = 0; d < 3; d++) { const drop = mesh(new T.SphereGeometry(0.023, 8, 6), new T.MeshPhysicalMaterial({ color: "#ffffff", roughness: 0, metalness: 0, transparent: true, opacity: 0.65, clearcoat: 1 }), head, Math.sin(d * 2) * 0.25, 0.08, Math.cos(d * 2) * 0.25); drop.scale.y = 0.6; } }
    return { group, stalk, leaves, hinges, head, progress: 0.15, type, index };
  });
  const butterflies = Array.from({ length: quality === "low" ? 2 : 4 }, (_, i) => {
    const body = new T.Group(); scene.add(body); const wings: T.Group[] = [];
    mesh(new T.CapsuleGeometry(0.025, 0.15, 3, 6), material("#3b2d25"), body);
    for (const side of [-1, 1]) { const wing = new T.Group(); body.add(wing); const m = material(i % 2 ? "#dca968" : "#d8c9e1", 0.65); m.side = T.DoubleSide; const surface = mesh(new T.SphereGeometry(1, 12, 8), m, wing, side * 0.17, 0, 0); surface.scale.set(0.18, 0.025, 0.25); const lower = mesh(new T.SphereGeometry(1, 10, 8), m, wing, side * 0.13, 0, 0.22); lower.scale.set(0.13, 0.02, 0.15); wings.push(wing); }
    body.userData.index = (i * 3) % 10;
    return { body, wings };
  });
  const pollenCount = quality === "low" ? 24 : 75; const coords = new Float32Array(pollenCount * 3);
  for (let i = 0; i < pollenCount; i++) { coords.set([Math.sin(i * 7) * 6, 0.7 + (i % 13) * 0.3, Math.cos(i * 13) * 4], i * 3); }
  const pollenGeo = new T.BufferGeometry(); pollenGeo.setAttribute("position", new T.BufferAttribute(coords, 3));
  const pollen = new T.Points(pollenGeo, new T.PointsMaterial({ color: "#fff0b1", size: 0.035, transparent: true, opacity: 0.55, depthWrite: false })); scene.add(pollen);
  let lastSelection: number | null | undefined = null; let lastReplay = 0;
  const look = new T.Vector3(0, 1.25, 0); const desiredLook = new T.Vector3(); const desiredCamera = new T.Vector3();
  return {
    pickables: [...flowers.map((flower) => flower.group), ...butterflies.map((butterfly) => butterfly.body)],
    frame(time, dt, state, reduced) {
      const selected = state.selected;
      if (selected !== lastSelection || state.replay !== lastReplay) { if (selected != null && flowers[selected]) flowers[selected].progress = reduced ? 1 : 0; lastSelection = selected; lastReplay = state.replay ?? 0; }
      flowers[10].group.visible = Boolean(state.planted);
      windTime.value = reduced ? 0 : time;
      for (const f of flowers) {
        const target = selected === f.index ? 1 : 0.55;
        f.progress = reduced ? target : T.MathUtils.damp(f.progress, target, selected === f.index ? 1.2 : 2, dt);
        const growth = T.MathUtils.smoothstep(f.progress, 0, 0.35); f.stalk.scale.y = 0.12 + 0.88 * growth;
        f.stalk.rotation.z = reduced ? 0 : Math.sin(time * 0.7 + f.index * 1.9) * 0.024;
        f.leaves.forEach((leaf, j) => { leaf.rotation.z = (1 - T.MathUtils.smoothstep(f.progress, 0.16 + j * 0.06, 0.5 + j * 0.06)) * 1.1; });
        f.hinges.forEach((hinge, j) => { const open = T.MathUtils.smoothstep(f.progress, 0.28 + j / f.hinges.length * 0.3, 0.75 + j / f.hinges.length * 0.25); hinge.rotation.x = 0.12 + open * (f.type === 2 ? 0.8 : f.type === 0 ? 1.45 - Math.floor(j / 6) * 0.35 : 1.45) + (reduced ? 0 : Math.sin(time * 0.9 + j + f.index) * 0.014 * open); });
      }
      butterflies.forEach((butterfly, i) => {
        const landing = Math.sin(time * 0.22 + i * 2) > 0.88;
        const flower = flowers[(i * 3) % 10];
        butterfly.body.position.lerp(new T.Vector3(landing ? flower.group.position.x : Math.sin(time * 0.3 + i * 2) * 3.7, landing ? flower.head.position.y + 0.16 : 2.3 + Math.sin(time * 0.6 + i) * 0.6, landing ? flower.group.position.z : Math.cos(time * 0.25 + i * 2) * 2.7), reduced ? 1 : 1 - Math.exp(-dt * 2));
        butterfly.body.rotation.y = time * 0.25 + i;
        butterfly.wings.forEach((wing, j) => { wing.rotation.z = reduced ? (j ? -0.3 : 0.3) : Math.sin(time * (landing ? 3 : 28) + i) * (landing ? 0.25 : 0.9) * (j ? -1 : 1); });
      });
      pollen.rotation.y = reduced ? 0 : time * 0.015;
      if (selected != null && flowers[selected]) { const f = flowers[selected]; desiredLook.set(f.group.position.x * 0.6, 1.25, f.group.position.z); desiredCamera.set(f.group.position.x * 0.4, 3.7, 8.5); }
      else { desiredLook.set(0, 1.25, -0.3); desiredCamera.set(0, 4.3, camera.aspect < 1 ? 15.5 : 12); }
      const blend = reduced ? 1 : 1 - Math.exp(-dt * 1.5); camera.position.lerp(desiredCamera, blend); look.lerp(desiredLook, blend); camera.lookAt(look);
    },
  };
}
