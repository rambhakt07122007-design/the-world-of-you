import * as T from "three";
import type { Quality } from "./SceneCanvas";
import { buildBotanicalGift, buildCrown } from "./botanicalGift";
import { buildCelestial } from "./celestial";
import { buildGarden } from "./garden";
import { buildCake } from "./cake";
import { buildPostcard } from "./postcard";
import { buildLetter } from "./letter";

export interface SceneState { growth?: number; turn?: number; detail?: string; bakeStage?: number; selected?: number | null; replay?: number; planted?: boolean; candles?: number; blowing?: boolean; celebration?: boolean; open?: boolean; immediate?: boolean; artwork?: string; playing?: boolean; preview?: boolean; spectrum?: number[]; collected?: number[]; }
export interface SceneRuntime { update: (state: SceneState) => void; activity: (active: boolean, reduced: boolean) => void; dispose: () => void; }
export interface Stage { scene: T.Scene; camera: T.PerspectiveCamera; quality: Quality; pick: (index: number) => void; report?: (progress: number) => void; }
export interface Choreography { frame: (time: number, dt: number, state: SceneState, reduced: boolean, timelineDt?: number) => void; pickables?: T.Object3D[]; dispose?: () => void; }

export {material,mesh,noiseTexture} from "./scenePrimitives";
export function createRuntime(host: HTMLElement, kind: "garden" | "cake" | "letter" | "portal" | "observatory" | "flower" | "crown" | "postcard", quality: Quality, initial: SceneState, pick: (index: number) => void, report?: (progress: number) => void, onFailure?: (reason: string) => void): SceneRuntime {
  const renderer = new T.WebGLRenderer({ antialias: quality !== "low", alpha: false, powerPreference: "low-power" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, quality === "high" ? 1.8 : quality === "medium" ? 1.35 : 1));
  renderer.shadowMap.enabled = quality !== "low"; renderer.shadowMap.type = T.PCFSoftShadowMap;
  renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
  renderer.domElement.setAttribute("aria-hidden", "true"); host.appendChild(renderer.domElement);
  const scene = new T.Scene(); const camera = new T.PerspectiveCamera(38, 1, 0.1, 100);
  scene.background = new T.Color(kind === "garden" ? "#83998d" : "#302820");
  scene.add(new T.HemisphereLight("#fff1d7", kind === "garden" ? "#39482b" : "#584137", 2.1));
  const sun = new T.DirectionalLight("#ffe0b0", 3.4); sun.position.set(-4, 9, 5); sun.castShadow = true;
  sun.shadow.mapSize.setScalar(quality === "high" ? 2048 : 1024); sun.shadow.camera.left = -9; sun.shadow.camera.right = 9; sun.shadow.camera.top = 9; sun.shadow.camera.bottom = -9; sun.shadow.bias = -0.001; scene.add(sun);
  const stage = { scene, camera, quality, pick, report };
  let choreography: Choreography;
  try { choreography = kind === "garden" ? buildGarden(stage) : kind === "cake" ? buildCake(stage) : kind === "letter" ? buildLetter(stage) : kind === "postcard" ? buildPostcard(stage) : kind === "flower" ? buildBotanicalGift(stage) : kind === "crown" ? buildCrown(stage) : buildCelestial(stage, kind === "portal"); }
  catch (error) { renderer.dispose(); renderer.domElement.remove(); throw error; }
  let state = initial; let active = false; let reduced = false; let frame = 0; let disposed = false; let previous = 0; let elapsed = 0; let graphicsFailed = false;
  renderer.debug.onShaderError = (gl, program) => { graphicsFailed = true; active = false; host.dataset.graphicsFailure = gl.getProgramInfoLog(program) || "GPU program validation failed"; onFailure?.("A graphics program could not run on this device. Readable content and controls remain available; choose a lower detail level to retry."); };
  const draw = (now: number) => {
    frame = 0;
    if (disposed || !active) return;
    const timelineDt = (now - previous) / 1000 || 0.016;
    const dt = Math.min(timelineDt, 0.05); previous = now;
    if (!reduced) elapsed += dt;
    choreography.frame(elapsed, dt, state, reduced, timelineDt);
    renderer.render(scene, camera);
    host.dataset.cameraPosition = camera.position.toArray().map((n) => n.toFixed(2)).join(",");
    host.dataset.triangles = String(renderer.info.render.triangles);
    host.dataset.renderFrames = String(Number(host.dataset.renderFrames ?? 0) + 1);
    if (!reduced && !graphicsFailed) frame = requestAnimationFrame(draw);
  };
  const invalidate = () => { if (active && !frame && !disposed) { previous = performance.now(); frame = requestAnimationFrame(draw); } };
  const resize = () => { const w = host.clientWidth || 600; const h = host.clientHeight || 500; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); invalidate(); };
  const observer = new ResizeObserver(resize); observer.observe(host); resize();
  const ray = new T.Raycaster(); const pointer = new T.Vector2(); let startX = 0; let startY = 0;
  const down = (event: PointerEvent) => { startX = event.clientX; startY = event.clientY; };
  const up = (event: PointerEvent) => {
    if (Math.hypot(event.clientX - startX, event.clientY - startY) > 12) return;
    const bounds = host.getBoundingClientRect(); pointer.set((event.clientX - bounds.left) / bounds.width * 2 - 1, -(event.clientY - bounds.top) / bounds.height * 2 + 1); ray.setFromCamera(pointer, camera);
    const hit = ray.intersectObjects(choreography.pickables ?? [], true)[0];
    if (hit) { let object: T.Object3D | null = hit.object; while (object && object.userData.index === undefined) object = object.parent; if (object) pick(object.userData.index as number); }
  };
  host.addEventListener("pointerdown", down); host.addEventListener("pointerup", up);
  return {
    update(next) { state = next; invalidate(); },
    activity(next, motion) { active = next && !graphicsFailed; reduced = motion; host.dataset.sceneActive = String(active); host.dataset.reducedMotion = String(reduced); if (!active && frame) { cancelAnimationFrame(frame); frame = 0; } invalidate(); },
    dispose() {
      disposed = true; choreography.dispose?.(); cancelAnimationFrame(frame); observer.disconnect(); host.removeEventListener("pointerdown", down); host.removeEventListener("pointerup", up);
      const resources = new Set<{ dispose: () => void }>();
      scene.traverse((object) => { if (object instanceof T.Mesh || object instanceof T.Points) { resources.add(object.geometry); for (const mat of Array.isArray(object.material) ? object.material : [object.material]) { resources.add(mat); for (const value of Object.values(mat)) if (value instanceof T.Texture) resources.add(value); } if (object instanceof T.InstancedMesh) resources.add(object); } if (object instanceof T.Light && "shadow" in object) (object as T.DirectionalLight).shadow?.dispose(); });
      resources.forEach((resource) => resource.dispose()); renderer.renderLists.dispose(); renderer.dispose(); renderer.forceContextLoss(); renderer.domElement.remove();
    },
  };
}
