import {Component,lazy,Suspense,type ReactNode} from 'react';
import type {SceneState} from './runtime';
import type {WorldKind} from './giftWorlds';
export type GiftKind=WorldKind|'letter'|'flower'|'crown'|'portal';
export interface GiftStageProps{kind:GiftKind;state:SceneState;label:string;onPick?:(index:number)=>void;onProgress?:(p:number)=>void;analyser?:AnalyserNode|null;}
const NativeGiftCanvas=lazy(()=>import('./NativeGiftCanvas'));
class SceneBoundary extends Component<{children:ReactNode},{failed:boolean}>{
 state={failed:false};static getDerivedStateFromError(){return {failed:true};}
 render(){return this.state.failed?<div className="gift-stage-fallback" role="status">3D is unavailable on this device. All readable content and controls remain below.</div>:this.props.children;}
}
export function GiftStage(props:GiftStageProps){return <div className="gift-native-stage" data-gift-world={props.kind}><SceneBoundary><Suspense fallback={<p className="gift-stage-fallback" role="status">Preparing your miniature world…</p>}><NativeGiftCanvas {...props}/></Suspense></SceneBoundary></div>;}
