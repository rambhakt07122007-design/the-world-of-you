export type WorldSectionId =
  | "invitation"
  | "garden"
  | "storybook"
  | "timepiece"
  | "letters"
  | "gallery"
  | "flower-garden"
  | "gifts"
  | "music-room"
  | "birthday-cake"
  | "future-postcards"
  | "finale";

export interface WorldSectionMeta {
  id: WorldSectionId;
  number: string;
  title: string;
  nav: string;
  summary: string;
}

/**
 * Personal-content source of truth for The World of You. Canonical facts and
 * authored source copy are carried forward from the supplied project reference.
 * Empty material must stay empty until Bhumi or Rudra supplies it.
 */
export const chronosContent = {
  meta: {
    herName: "Bhumi",
    hisName: "Rudra",
    docTitle: "The World of You — A Birthday Surprise for Bhumi",
    brand: "THE WORLD OF YOU",
    tagline: "A little world, created just for you.",
  },
  dates: {
    firstConnection: "2025-05-11",
    firstConnectionLabel: "11 May 2025",
    firstConnectionTimeZone: "Asia/Kolkata",
    proposal: "2025-07-17",
    proposalLabel: "17 July 2025",
    birthdayLabel: "17 November",
    birthdayDay: 17,
    countdownTarget: null as string | null,
  },
  opening: {
    kicker: "A PRIVATE LITTLE WORLD",
    line: "A little world, created just for you…",
    button: "Open Your Birthday Surprise",
    skip: "Skip the opening",
    soundHint: "Sound is quiet until you choose otherwise.",
  },
  sections: [
    { id: "invitation", number: "01", title: "Invitation Room", nav: "Invitation Room", summary: "A paper invitation opens the way into the birthday storybook." },
    { id: "garden", number: "02", title: "Birthday Garden", nav: "Birthday Garden", summary: "A garden world, opened just for you." },
    { id: "storybook", number: "03", title: "Scrapbook", nav: "Scrapbook", summary: "A little open book, with pages held for what is true." },
    { id: "timepiece", number: "04", title: "Memory Observatory", nav: "Memory Observatory", summary: "An observatory for the verified dates and elapsed time." },
    { id: "letters", number: "05", title: "Letter Room", nav: "Letter Room", summary: "Five envelopes, with only the supplied words inside." },
    { id: "gallery", number: "06", title: "Memory Gallery", nav: "Memory Gallery", summary: "Gallery mounts ready for owner-provided photographs." },
    { id: "flower-garden", number: "07", title: "Wish Garden", nav: "Wish Garden", summary: "Choose a bloom to release a wish into the day." },
    { id: "gifts", number: "08", title: "Gift Atelier", nav: "Gift Atelier", summary: "Seventeen independently accessible surprises; opening is optional." },
    { id: "music-room", number: "09", title: "Music Lounge", nav: "Music Lounge", summary: "A quiet listening room for audio you choose to add." },
    { id: "future-postcards", number: "10", title: "Future Postcards", nav: "Future Postcards", summary: "Possible futures, held lightly — never promises." },
    { id: "birthday-cake", number: "11", title: "Birthday Ballroom", nav: "Birthday Ballroom", summary: "A birthday cake, a few candles and an interactive wish." },
    { id: "finale", number: "12", title: "Finale", nav: "Finale", summary: "A closing scene for 17 November, with no year attached." },
  ] satisfies WorldSectionMeta[],
  garden: {
    eyebrow: "A BIRTHDAY GARDEN · OPEN 17 NOVEMBER",
    heading: "Happy Birthday,\nBhumi.",
    subheading: "Somewhere between the flowers and the light, a little world was waiting for you.",
    invitation: "Enter Your Little World",
    locationNote: "A small celebration · The World of You",
  },
  scrapbook: {
    eyebrow: "A HANDMADE STORYBOOK",
    intro: "A few dates from the source archive. The rest of the pages are left open for the memories only you can add.",
    turnHint: "Turn the page · swipe or use the arrows",
    spreads: [
      {
        id: "spread-origin",
        left: { kind: "record" as const, label: "FIRST RECORD", date: "11 May 2025", title: "The first connection", body: "The source archive records 11 May 2025 as the first connection. No additional moment or conversation is assumed here." },
        right: { kind: "blank" as const, label: "A PAGE HELD OPEN", date: "— — —", title: "Your words go here", body: "Add a real memory in chronosContent.ts, or leave this page blank until you are ready." },
      },
      {
        id: "spread-proposal",
        left: { kind: "record" as const, label: "A CANONICAL DATE", date: "17 July 2025", title: "The proposal", body: "The source archive records the proposal on 17 July 2025. Details belong to you to add, if you wish." },
        right: { kind: "photo" as const, label: "PHOTO MOUNT", date: "OWNER-SUPPLIED ONLY", title: "A photograph to add", body: "This mount is intentionally empty. Add a real photograph supplied by the owner; no generated art is presented as a memory." },
      },
      {
        id: "spread-birthday",
        left: { kind: "record" as const, label: "BIRTHDAY MARKER", date: "17 November", title: "A day without a year", body: "The source archive records 17 November as Bhumi's birthday. The year is not specified." },
        right: { kind: "blank" as const, label: "AN OPEN PAGE", date: "UNINDEXED", title: "A note in your words", body: "Add a true note or memory here when you choose. Nothing has been written for you." },
      },
      {
        id: "spread-open",
        left: { kind: "blank" as const, label: "EMPTY MOUNTING", date: "UNINDEXED", title: "A page for later", body: "A blank page is part of the story too. Replace it only with a real detail." },
        right: { kind: "blank" as const, label: "EMPTY MOUNTING", date: "UNINDEXED", title: "Still being written", body: "The archive stays editable. No extra relationship events are inferred." },
      },
    ],
    clockNodes: [
      { id: "origin", angle: 10, date: "11 May 2025", title: "First connection", detail: "The first connection recorded in the source project." },
      { id: "proposal", angle: 132, date: "17 July 2025", title: "The proposal", detail: "The proposal recorded in the source project." },
      { id: "birthday", angle: 250, date: "17 November", title: "Birthday marker", detail: "Bhumi's birthday. The year is not specified." },
    ],
  },
  letters: {
    intro: "A writing desk, a fountain pen and a small collection of envelopes. Only one existing letter draft was supplied; the other envelopes are intentionally empty.",
    letters: [
      {
        id: "birthday-letter",
        category: "A birthday letter",
        label: "THE EXISTING LETTER",
        title: "The Last Letter",
        salutation: "Bhumi,",
        paragraphs: [
          "If you're reading this the way I hope you are — slowly, maybe smiling a little at the dramatics — then the machine did its job. I wanted to give you something that couldn't fit in an envelope, so I built a building around it instead.",
          "On 11 May, something quietly began. On 17 July, I asked, and you said yes, and my life's entire routing changed. Those are the only two facts this archive holds as certain. Everything else is still being written.",
          "I won't pretend to know what this year held for you — the parts you showed me, and the parts you carried alone. But I watched you carry them. That's a kind of grace most people never notice. I noticed. The machine noticed.",
          "Nothing in here is a promise about the future. The future chambers are marked speculative for a reason. What is real is the record: someone was paying attention, and kept every second of it.",
          "So today — 17 November — is simply yours. The candles, the noise, all of it. And after the noise, this stays here. A tower that refuses to forget you.",
        ],
        closing: "With everything I have, quietly —",
        signature: "Rudra",
        ps: "P.S. — Seventeen doors are sealed in the chamber upstairs. You were always going to open every single one.",
        sourceDraft: true,
      },
      { id: "appreciation-letter", category: "A note of appreciation", label: "EMPTY · OWNER-WRITTEN", title: "A note to add", salutation: "", paragraphs: [], closing: "", signature: "", ps: "", sourceDraft: false },
      { id: "little-things-letter", category: "A collection of little things", label: "EMPTY · OWNER-WRITTEN", title: "A page for little things", salutation: "", paragraphs: [], closing: "", signature: "", ps: "", sourceDraft: false },
      { id: "difficult-days-letter", category: "A letter for difficult days", label: "EMPTY · OWNER-WRITTEN", title: "A note for another day", salutation: "", paragraphs: [], closing: "", signature: "", ps: "", sourceDraft: false },
      { id: "future-dream-letter", category: "A future-dream letter", label: "EMPTY · A HOPE ONLY", title: "A possible future", salutation: "", paragraphs: [], closing: "", signature: "", ps: "", sourceDraft: false },
    ],
  },
  gallery: {
    intro: "No personal photographs were supplied with the project. These Polaroid mounts stay empty until real images and captions are added by the owner.",
    photos: [
      { id: "photo-01", src: "", caption: "A photograph to add", date: "DATE HELD BACK", note: "Add an owner-supplied photograph and its accurate caption." },
      { id: "photo-02", src: "", caption: "A page held open", date: "DATE HELD BACK", note: "No image is included. Choose a real photograph if you want one here." },
      { id: "photo-03", src: "", caption: "An empty Polaroid", date: "DATE HELD BACK", note: "Write only what is true about a supplied photograph." },
      { id: "photo-04", src: "", caption: "A mount in reserve", date: "DATE HELD BACK", note: "This space is intentionally blank until a real photo is supplied." },
      { id: "photo-05", src: "", caption: "A picture to remember", date: "DATE HELD BACK", note: "No generated photograph is used as a personal memory." },
      { id: "photo-06", src: "", caption: "The next frame", date: "DATE HELD BACK", note: "Add a real image under public/assets/gallery/ and set its src." },
    ],
  },
  flowerGarden: {
    intro: "A wish is not a memory. Choose a bloom to release one of the wishes already in the source project.",
    wishes: [
      "May your tea always be exactly the right temperature.",
      "May every good song find you at the red light.",
      "May the auto arrive on the very first try.",
      "May your suitcase always close on the first attempt.",
      "May every version of your future feel like a good plot twist.",
      "May you always find the other earring.",
      "May the rain wait until you're home — or arrive exactly when you wanted it.",
      "May your softest year start today.",
      "May you never finish explaining the joke — someone will always already be laughing.",
      "And one big one, kept quiet. It's yours when you want it. — R",
    ],
  },
  gifts: {
    intro: "Seventeen distinct, independently accessible experiences. Personal reasons, recordings, photographs, coupons and future hopes remain clearly marked as owner-content slots until supplied or approved.",
    emptyMessage: "This gift is still empty. Add a real surprise, note or memory in chronosContent.ts.",
    specials: {
      "01": { title: "A little secret", message: "You are the reason this entire machine exists. That's the whole secret.", editable: false },
      "08": { title: "A note from the archive", message: "Some things I practice saying and still say badly. This archive is one of them, done properly.", editable: false },
      "17": { title: "17 November", message: "17 November. The year is not specified in this archive. Happy Birthday, Bhumi.", editable: false },
    } as Record<string, { title: string; message: string; editable: boolean }>,
  },
  music: {
    station: "BHUMI FM",
    note: "Local files only. The player stays paused until you select a track and press play.",
    emptyNote: "No audio file supplied yet.",
    tracks: [
      { id: "track-01", title: "A voice note, from Rudra", note: "Add voice-note-01.mp3 to enable.", src: "" },
      { id: "track-02", title: "A song chosen by the owner", note: "Add a licensed or owner-provided track.", src: "" },
      { id: "track-03", title: "A birthday recording", note: "Add a real recording if one is supplied.", src: "" },
    ],
  },
  future: {
    tag: "POSSIBLE FUTURE · A HOPE · NOT A FACT",
    intro: "Postcards from scenes the archive has not earned yet. These are possibilities only, never promises.",
    items: [
      { id: "future-01", place: "A mountain morning", someday: "A winter not yet indexed", caption: "Somewhere cold and quiet, where the air does half the talking. (Editable — keep only if it is a real shared hope.)", scene: "mountain", art: "/assets/postcards/mountain-morning.webp", alt: "A softly painted mountain valley at sunrise, with a winding path through wildflowers." },
      { id: "future-02", place: "The sea at blue hour", someday: "When the timing is kind", caption: "That twenty-minute sky that makes everyone honest. (Editable.)", scene: "sea", art: "/assets/postcards/sea-blue-hour.webp", alt: "A quiet shoreline at blue hour with gentle waves and flowers in the foreground." },
      { id: "future-03", place: "A city we haven't named", someday: "An ordinary weekend, someday", caption: "Getting lost on purpose, finding the coffee by accident. (Editable.)", scene: "city", art: "/assets/postcards/unnamed-city.webp", alt: "An unnamed old-world city at golden dusk, with rooftops and a warmly lit café." },
      { id: "future-04", place: "Home, whatever shape", someday: "The long record", caption: "Not a plan, never a pressure — just a door I'd like to keep in the drawing. (Editable.)", scene: "home", art: "/assets/postcards/home-whatever-shape.webp", alt: "A small flower-covered cottage with a glowing window in an evening garden." },
    ],
  },
  finale: {
    kicker: "17 NOVEMBER · A DAY FOR BHUMI",
    headline: "Happy Birthday,\nBhumi.",
    sub: "Every candle is lit for today.",
    sourceMessage: "You were never a chapter in my story. Somewhere along the way, you became the reason I keep the records at all. — Rudra",
    sourceDraft: true,
    replay: "Replay the celebration",
    letterLink: "Open the birthday letter",
    storyLink: "Return to the scrapbook",
  },
} as const;

