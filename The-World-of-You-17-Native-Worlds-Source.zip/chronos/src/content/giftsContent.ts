/**
 * Gift Atelier catalog and owner-editable copy slots.
 * Keep private/personal content blank until Rudra supplies approved text/media.
 */
export type GiftExperienceId =
  | "secret-letter"
  | "reason-jar"
  | "eternal-flower"
  | "little-universe"
  | "bhumi-fm"
  | "memory-cinema"
  | "wishes"
  | "royal-crown"
  | "open-when"
  | "happiness-machine"
  | "little-adventure"
  | "music-of-us"
  | "infinite-mirror"
  | "coupon-book"
  | "future-garden"
  | "treasure-hunt"
  | "ultimate-surprise";

export type GiftVisual =
  | "letter" | "jar" | "flower" | "orbit" | "cassette" | "cinema" | "wishes" | "crown"
  | "envelopes" | "machine" | "map" | "vinyl" | "mirror" | "coupons" | "tree" | "key" | "portal";

export interface GiftDefinition {
  id: string;
  number: string;
  title: string;
  shortTitle: string;
  subtitle: string;
  experience: GiftExperienceId;
  visual: GiftVisual;
  color: string;
  ribbon: string;
  mark: string;
}

export const giftDefinitions: readonly GiftDefinition[] = [
  { id: "gift-01", number: "01", title: "The Secret Letter", shortTitle: "Secret Letter", subtitle: "A handwritten source letter, unfolded at your pace.", experience: "secret-letter", visual: "letter", color: "#ead0c2", ribbon: "#9b5660", mark: "✉" },
  { id: "gift-02", number: "02", title: "A Jar of Reasons", shortTitle: "Jar of Reasons", subtitle: "Seventeen editable notes, waiting for owner-written reasons.", experience: "reason-jar", visual: "jar", color: "#d6e0d0", ribbon: "#81926f", mark: "✧" },
  { id: "gift-03", number: "03", title: "The Flower That Never Fades", shortTitle: "Everlasting Flower", subtitle: "Grow, turn and bloom a paper-garden flower.", experience: "eternal-flower", visual: "flower", color: "#edc9d0", ribbon: "#b56f85", mark: "✿" },
  { id: "gift-04", number: "04", title: "Our Little Universe", shortTitle: "Little Universe", subtitle: "A tiny star map of the two verified dates.", experience: "little-universe", visual: "orbit", color: "#bfc8dc", ribbon: "#687caa", mark: "✦" },
  { id: "gift-05", number: "05", title: "Bhumi FM Exclusive", shortTitle: "Bhumi FM", subtitle: "A cassette deck ready for a real, owner-provided recording.", experience: "bhumi-fm", visual: "cassette", color: "#e8c990", ribbon: "#9d7040", mark: "▣" },
  { id: "gift-06", number: "06", title: "The Memory Cinema", shortTitle: "Memory Cinema", subtitle: "A private screen, left blank for genuine photographs.", experience: "memory-cinema", visual: "cinema", color: "#c9c1bc", ribbon: "#6f6265", mark: "▤" },
  { id: "gift-07", number: "07", title: "A Thousand Wishes", shortTitle: "A Thousand Wishes", subtitle: "Collect and connect the wishes already in the source archive.", experience: "wishes", visual: "wishes", color: "#d5cbe5", ribbon: "#8774ad", mark: "✧" },
  { id: "gift-08", number: "08", title: "The Queen’s Crown", shortTitle: "Queen’s Crown", subtitle: "A small royal object to rotate and inspect.", experience: "royal-crown", visual: "crown", color: "#f0d791", ribbon: "#ad8741", mark: "♛" },
  { id: "gift-09", number: "09", title: "Open When…", shortTitle: "Open When…", subtitle: "Four sealed envelopes, waiting for your words.", experience: "open-when", visual: "envelopes", color: "#e3c2b7", ribbon: "#a46a71", mark: "▱" },
  { id: "gift-10", number: "10", title: "The Happiness Machine", shortTitle: "Happiness Machine", subtitle: "Pull a lever to reveal one of the existing birthday wishes.", experience: "happiness-machine", visual: "machine", color: "#cfb997", ribbon: "#8e7451", mark: "⚙" },
  { id: "gift-11", number: "11", title: "A Little Adventure", shortTitle: "Little Adventure", subtitle: "Explore an explicitly imaginary postcard map.", experience: "little-adventure", visual: "map", color: "#c6d5d0", ribbon: "#718e87", mark: "⌖" },
  { id: "gift-12", number: "12", title: "The Music of Us", shortTitle: "Music of Us", subtitle: "A vinyl player for licensed or owner-provided audio.", experience: "music-of-us", visual: "vinyl", color: "#d8c0c5", ribbon: "#8b6275", mark: "♫" },
  { id: "gift-13", number: "13", title: "The Infinite Mirror", shortTitle: "Infinite Mirror", subtitle: "Wipe away the mist to reveal an abstract birthday message.", experience: "infinite-mirror", visual: "mirror", color: "#cbd9db", ribbon: "#64858d", mark: "◉" },
  { id: "gift-14", number: "14", title: "The Birthday Coupon Book", shortTitle: "Coupon Book", subtitle: "A flip-through booklet for only owner-approved offers.", experience: "coupon-book", visual: "coupons", color: "#ead6ac", ribbon: "#a48651", mark: "✂" },
  { id: "gift-15", number: "15", title: "The Future Garden", shortTitle: "Future Garden", subtitle: "Grow a tree with blank leaves for hopes you choose to write.", experience: "future-garden", visual: "tree", color: "#c6d4b8", ribbon: "#71875e", mark: "♧" },
  { id: "gift-16", number: "16", title: "The Secret Treasure Hunt", shortTitle: "Treasure Hunt", subtitle: "Solve a fair symbol puzzle; use keyboard-friendly move controls.", experience: "treasure-hunt", visual: "key", color: "#d5c8b7", ribbon: "#8c7456", mark: "⌕" },
  { id: "gift-17", number: "17", title: "The Ultimate Surprise", shortTitle: "Ultimate Surprise", subtitle: "Gather the lights and open a celebratory portal.", experience: "ultimate-surprise", visual: "portal", color: "#d8bc83", ribbon: "#9e7137", mark: "✺" },
] as const;

/** Populate only with Rudra-authored, approved reasons. Blank is intentional. */
export const reasonNotes = Array.from({ length: 17 }, (_, index) => ({
  id: `reason-${String(index + 1).padStart(2, "0")}`,
  text: "",
}));

/** The prompts are safe to show; the private message bodies remain blank. */
export const openWhenLetters = [
  { id: "smile", prompt: "Open when you need a smile", message: "" },
  { id: "tired", prompt: "Open when you feel tired", message: "" },
  { id: "encouragement", prompt: "Open when you need encouragement", message: "" },
  { id: "surprise", prompt: "Open when you want a little surprise", message: "" },
] as const;

/** Add only approved coupons/promises. Empty slots are not redeemable. */
export const couponEntries = Array.from({ length: 6 }, (_, index) => ({
  id: `coupon-${String(index + 1).padStart(2, "0")}`,
  title: "",
  description: "",
}));

/** Future hopes, not commitments. Keep blank until the owner writes them. */
export const futureGardenLeaves = Array.from({ length: 8 }, (_, index) => ({
  id: `hope-${String(index + 1).padStart(2, "0")}`,
  text: "",
}));

/** Puzzle solution is a generic game mechanic, not a personal password. */
export const treasureHuntPuzzle = {
  clue: "Arrange the symbols in this order: a flower first, the moon second, and the star last.",
  initialOrder: ["star", "flower", "moon"] as const,
  solution: ["flower", "moon", "star"] as const,
  password: "OPEN",
  passwordHint: "The word describes what you did to the final gate.",
};

export const giftsContentReadiness = {
  reasons: "owner-content-required",
  voiceRecording: "not-supplied",
  memoryPhotos: "not-supplied",
  couponPromises: "owner-approval-required",
  futureHopes: "owner-content-required",
} as const;
