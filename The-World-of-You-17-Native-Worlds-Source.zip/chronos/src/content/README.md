# Editable birthday-storybook content

- `chronosContent.ts` is the source of truth for verified facts, the existing source letter, wishes, date labels, empty gallery mounts, audio tracks, and speculative postcard copy.
- `giftsContent.ts` defines all 17 gift identities and experience IDs, plus owner-editable slots for 17 reasons, four Open When letters, six coupons and eight future-garden hopes.

Content rules:

- Preserve the verified names and dates exactly; Bhumi’s birthday year remains unspecified.
- Do not add memories, quotes, photographs, recordings, reasons, coupon promises or future hopes without owner-supplied/approved material.
- The 17 gift mechanics may use generic game and visual interactions, but personal copy stays blank or explicitly marked as pending.
- Empty photo and audio slots are intentional. Use local, owner-supplied files only; do not autoplay.
- Future postcards are explicitly speculative and never a real travel history or promise.
- Generated artwork is illustrative atmosphere, not a personal photograph or recorded memory.
