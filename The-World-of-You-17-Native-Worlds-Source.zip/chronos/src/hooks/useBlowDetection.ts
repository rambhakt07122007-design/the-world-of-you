import { useCallback, useEffect, useRef, useState } from "react";

/** Heuristic only: broadband energy, not speech recognition or reliable breath identification. */
export function isBlowLike(rms: number, baseline: number, highBandRatio: number, peakShare: number) {
  return rms > Math.max(0.025, baseline * 2.4) && highBandRatio > 0.16 && peakShare < 0.16;
}
export function useBlowDetection(onBlow: () => void, enabled: boolean) {
  const [phase, setPhase] = useState<"idle" | "requesting" | "calibrating" | "listening">("idle");
  const [message, setMessage] = useState("Microphone is optional. No audio is recorded, stored or sent.");
  const [level, setLevel] = useState(0);
  const generation = useRef(0);
  const active = useRef(false);
  const frame = useRef(0);
  const stream = useRef<MediaStream | null>(null);
  const context = useRef<AudioContext | null>(null);
  const callback = useRef(onBlow); callback.current = onBlow;
  const stop = useCallback(() => {
    generation.current++;
    active.current = false;
    cancelAnimationFrame(frame.current);
    stream.current?.getTracks().forEach((track) => track.stop()); stream.current = null;
    const audio = context.current; context.current = null;
    if (audio && audio.state !== "closed") void audio.close().catch(() => {});
    setPhase("idle"); setLevel(0);
  }, []);
  useEffect(() => { if (!enabled) stop(); }, [enabled, stop]);
  useEffect(() => {
    const hide = () => { if (document.hidden) stop(); };
    document.addEventListener("visibilitychange", hide);
    return () => { document.removeEventListener("visibilitychange", hide); stop(); };
  }, [stop]);
  const start = useCallback(async () => {
    if (!enabled || active.current) return;
    if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) { setMessage("Microphone is unavailable here. Use the Blow Out Candles button instead."); return; }
    stop(); active.current = true; const id = generation.current;
    setPhase("requesting"); setMessage("Waiting for microphone permission. You can cancel at any time.");
    try {
      const media = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }, video: false });
      if (id !== generation.current || !enabled) { media.getTracks().forEach((track) => track.stop()); return; }
      stream.current = media;
      const audio = new AudioContext(); context.current = audio; await audio.resume();
      if (id !== generation.current) return;
      const analyser = audio.createAnalyser(); analyser.fftSize = 2048; analyser.smoothingTimeConstant = 0.3;
      const source = audio.createMediaStreamSource(media); source.connect(analyser); // Never routed to speakers.
      const waveform = new Float32Array(analyser.fftSize); const bins = new Uint8Array(analyser.frequencyBinCount);
      const samples: number[] = []; let baseline = 0.01; let sustained = 0; let last = performance.now(); const began = last;
      setPhase("calibrating"); setMessage("Stay quiet for one second while the room noise is calibrated.");
      const analyse = (now: number) => {
        if (id !== generation.current) return;
        const dt = Math.min(now - last, 80); last = now;
        analyser.getFloatTimeDomainData(waveform); analyser.getByteFrequencyData(bins);
        let sum = 0; for (const sample of waveform) sum += sample * sample; const rms = Math.sqrt(sum / waveform.length);
        let total = 0; let high = 0; let peak = 0;
        for (let i = 1; i < bins.length; i++) { const hz = i * audio.sampleRate / analyser.fftSize; if (hz < 120 || hz > 8000) continue; const power = Math.pow(10, (analyser.minDecibels + bins[i] / 255 * (analyser.maxDecibels - analyser.minDecibels)) / 10); total += power; if (hz > 1200) high += power; peak = Math.max(peak, power); }
        if (now - began < 1100) { samples.push(rms); }
        else {
          if (samples.length) { samples.sort((a, b) => a - b); baseline = samples[Math.floor(samples.length / 2)] || 0.01; samples.length = 0; setPhase("listening"); setMessage("Take a deep breath and make a wish. Blow gently toward the microphone. Detection is approximate; the button always works."); }
          const candidate = isBlowLike(rms, baseline, total ? high / total : 0, total ? peak / total : 1);
          sustained = candidate ? sustained + dt : Math.max(0, sustained - dt * 2);
          setLevel(Math.min(1, sustained / 450));
          if (sustained >= 450) { stop(); setMessage("Airflow-like sound detected. Microphone stopped."); callback.current(); return; }
        }
        if (now - began > 16000) { stop(); setMessage("Listening timed out and the microphone stopped. Try again or use the button."); return; }
        frame.current = requestAnimationFrame(analyse);
      };
      frame.current = requestAnimationFrame(analyse);
    } catch (error) {
      if (id !== generation.current) return;
      stop(); setMessage(error instanceof DOMException && error.name === "NotAllowedError" ? "Permission denied. You can still blow out the candles with the button." : "The microphone could not start. Use the Blow Out Candles button instead.");
    }
  }, [enabled, stop]);
  return { start, stop, phase, message, level };
}
