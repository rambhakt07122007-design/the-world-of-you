import { useEffect, useId, useRef, type ReactNode } from "react";
import { X } from "lucide-react";

interface ArchiveDialogProps {
  open: boolean;
  onClose: () => void;
  eyebrow?: string;
  title: string;
  children: ReactNode;
  variant?: "paper" | "dark";
  className?: string;
}

export function ArchiveDialog({ open, onClose, eyebrow, title, children, variant = "paper", className }: ArchiveDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      dialog.showModal();
      dialog.querySelector<HTMLButtonElement>(".archive-dialog__close")?.focus({ preventScroll: true });
    }
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      className={`archive-dialog archive-dialog--${variant}${className ? ` ${className}` : ""}`}
      ref={dialogRef}
      aria-labelledby={titleId}
      onCancel={(event) => { event.preventDefault(); onClose(); }}
      onClose={onClose}
      onClick={(event) => { if (event.target === dialogRef.current) onClose(); }}
    >
      <div className="archive-dialog__paper">
        <button className="archive-dialog__close" type="button" onClick={onClose} aria-label="Close dialog">
          <X size={19} />
        </button>
        {eyebrow && <p className="micro-label archive-dialog__eyebrow">{eyebrow}</p>}
        <h2 id={titleId}>{title}</h2>
        <div className="archive-dialog__body">{children}</div>
      </div>
    </dialog>
  );
}
