import { useEffect, useState } from "react";
import { Clock3 } from "lucide-react";
import { SceneCanvas } from "../three/SceneCanvas";
import { chronosContent } from "../content/chronosContent";
import { getElapsedTime, formatInteger } from "../utils/time";
import { WorldSection } from "./WorldSection";

export function RelationshipClock() {
  const [selectedNode, setSelectedNode] = useState<string>(chronosContent.scrapbook.clockNodes[0].id);
  const [now, setNow] = useState(() => Date.now());
  const activeNode = chronosContent.scrapbook.clockNodes.find((node) => node.id === selectedNode)!;
  const elapsed = getElapsedTime(chronosContent.dates.firstConnection, chronosContent.dates.firstConnectionTimeZone, now);

  useEffect(() => {
    const interval = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <WorldSection id="timepiece" className="timepiece-section" eyebrow="MEMORY OBSERVATORY · VERIFIED DATES" sideNote="OBSERVATORY / 04">
      <SceneCanvas kind="observatory" state={{}} label="A three-dimensional astronomical clock showing local time, with interlocking gold gears, a moving pendulum, distant moon and starfield. Verified milestones remain below." />
      <p className="timepiece-intro">A quiet observatory for the dates already in the archive — and a live, timezone-safe count from the first connection. No hour or conversation is invented.</p>
      <section className="relationship-clock" aria-label="Interactive relationship timepiece">
        <div className="relationship-clock__left">
          <p className="world-eyebrow"><Clock3 size={13} /> THE TIME WE KEEP</p>
          <h3>One true date.<br /><em>Every minute since.</em></h3>
          <p className="relationship-clock__copy">The elapsed time is calculated from the start of 11 May 2025 in {chronosContent.dates.firstConnectionTimeZone}. It updates while this page is open, without assuming a private time of day.</p>
          <div className="relationship-clock__elapsed" aria-live="polite" aria-atomic="true">
            <div><strong>{formatInteger(elapsed.days)}</strong><span>days</span></div>
            <i aria-hidden="true">·</i>
            <div><strong>{String(elapsed.hours).padStart(2, "0")}</strong><span>hours</span></div>
            <i aria-hidden="true">·</i>
            <div><strong>{String(elapsed.minutes).padStart(2, "0")}</strong><span>minutes</span></div>
          </div>
          <span className="relationship-clock__caption">SINCE {chronosContent.dates.firstConnectionLabel.toUpperCase()} · {chronosContent.dates.firstConnectionTimeZone.toUpperCase()}</span>
        </div>
        <div className="relationship-clock__right">
          <div className="pocket-watch" aria-hidden="true">
            <span className="pocket-watch__loop" />
            <div className="pocket-watch__face">
              <i className="pocket-watch__mark pocket-watch__mark--one">I</i><i className="pocket-watch__mark pocket-watch__mark--two">II</i><i className="pocket-watch__mark pocket-watch__mark--three">III</i><i className="pocket-watch__mark pocket-watch__mark--four">IV</i><i className="pocket-watch__mark pocket-watch__mark--five">V</i><i className="pocket-watch__mark pocket-watch__mark--six">VI</i>
              <span className="pocket-watch__hand pocket-watch__hand--minute" /><span className="pocket-watch__hand pocket-watch__hand--hour" /><span className="pocket-watch__pin" />
            </div>
          </div>
          <div className="relationship-clock__milestones">
            <p className="world-eyebrow">CHOOSE A DATE MARKER</p>
            <div className="relationship-clock__nodes" role="group" aria-label="Verified relationship date markers">
              {chronosContent.scrapbook.clockNodes.map((node) => <button key={node.id} type="button" onClick={() => setSelectedNode(node.id)} aria-pressed={selectedNode === node.id} className={selectedNode === node.id ? "is-selected" : ""}><span>{node.date}</span><small>{node.title}</small></button>)}
            </div>
            <div className="relationship-clock__detail" aria-live="polite"><span>{activeNode.date}</span><p>{activeNode.detail}</p></div>
          </div>
        </div>
      </section>
    </WorldSection>
  );
}
