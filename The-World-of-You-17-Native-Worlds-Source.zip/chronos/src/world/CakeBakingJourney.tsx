import { useEffect, useRef } from "react";
import { ArrowLeft, ArrowRight, RotateCcw, SkipForward } from "lucide-react";

interface CakeTimeline {
  kill: () => void;
}

const bakingSteps = [
  {
    id: "ingredients",
    label: "Gather",
    title: "A little flour, a little sugar.",
    description: "Butter, eggs, and a mixing bowl. Every good cake starts with simple ingredients.",
  },
  {
    id: "mix",
    label: "Mix",
    title: "Whisk until the batter turns silky.",
    description: "Fold everything together, then pour the batter into its waiting pan.",
  },
  {
    id: "bake",
    label: "Bake",
    title: "Warmth, time, a tiny rise.",
    description: "The oven door closes; the little cake lifts and turns golden.",
  },
  {
    id: "decorate",
    label: "Decorate",
    title: "Layers of sponge, cream, and care.",
    description: "Stack, fill, frost, and add a few berries. The cake is ready for candles.",
  },
] as const;

function BakingIllustration({ stage }: { stage: number }) {
  return (
    <svg className={`cake-bake-art cake-bake-art--${bakingSteps[stage].id}`} viewBox="0 0 520 300" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="bake-oven-light" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#f7d99d" stopOpacity=".95" />
          <stop offset="1" stopColor="#d88f5f" stopOpacity=".45" />
        </linearGradient>
        <linearGradient id="bake-frosting" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#fffaf0" />
          <stop offset="1" stopColor="#f1d9c7" />
        </linearGradient>
      </defs>
      <path d="M30 247c58-13 115-18 230-18s174 5 230 18v31H30z" fill="#d9c1a6" opacity=".58" />
      <path d="M34 246c93-18 359-18 452 0" fill="none" stroke="#b78f6c" strokeWidth="3" strokeLinecap="round" opacity=".62" />

      {stage === 0 && (
        <g className="cake-bake-ingredients">
          <path d="m78 94 16-20h72l17 20-8 137H84z" fill="#f8edda" stroke="#b99a78" strokeWidth="2.5" />
          <path d="M86 108h88M89 117h82" stroke="#ddc5a4" strokeWidth="2" />
          <path d="M102 149c9-12 22-12 30 0-7 13-21 15-30 0z" fill="#e5cfaa" />
          <text x="129" y="183" textAnchor="middle" fill="#92785e" fontSize="10" fontFamily="sans-serif" fontWeight="700" letterSpacing="2">FLOUR</text>
          <ellipse cx="241" cy="197" rx="24" ry="31" fill="#fffaf0" stroke="#d8c5a7" strokeWidth="2.5" />
          <ellipse cx="293" cy="197" rx="24" ry="31" fill="#fffaf0" stroke="#d8c5a7" strokeWidth="2.5" />
          <ellipse cx="241" cy="198" rx="11" ry="16" fill="#f1d7a0" opacity=".8" />
          <ellipse cx="293" cy="198" rx="11" ry="16" fill="#f1d7a0" opacity=".8" />
          <rect x="355" y="145" width="65" height="43" rx="7" fill="#f2dda9" stroke="#b99a78" strokeWidth="2" transform="rotate(-7 387 166)" />
          <path d="M363 157h48M362 168h48" stroke="#fff8e7" strokeWidth="3" opacity=".8" />
          <path d="M197 225c8-24 28-35 54-35s47 11 55 35z" fill="#d9c2a7" stroke="#a68769" strokeWidth="2.5" />
          <ellipse cx="251" cy="223" rx="54" ry="12" fill="#f7f0e4" stroke="#a68769" strokeWidth="2.5" />
          <path d="M219 221c11-9 51-9 64 0" fill="none" stroke="#d9bd94" strokeWidth="3" strokeLinecap="round" />
          <circle cx="128" cy="214" r="4" fill="#d6b879" />
          <circle cx="400" cy="216" r="4" fill="#c98291" />
        </g>
      )}

      {stage === 1 && (
        <g className="cake-bake-mixing">
          <ellipse cx="260" cy="225" rx="118" ry="22" fill="#c9ad8e" opacity=".45" />
          <path d="M157 145h206l-21 84c-5 20-22 34-43 34h-78c-21 0-38-14-43-34z" fill="#e8d4bd" stroke="#a98a6e" strokeWidth="3" />
          <path d="M170 175c21-18 51-4 78-9 26-5 52-19 82-5 13 6 22 12 28 18l-17 52c-5 18-19 27-40 27h-82c-21 0-35-10-40-29z" fill="#edc78e" />
          <ellipse cx="260" cy="169" rx="103" ry="22" fill="#fff7e8" stroke="#a98a6e" strokeWidth="3" />
          <path d="M189 167c25-14 48 7 72-4 20-9 46-14 70 0" fill="none" stroke="#dba56f" strokeWidth="4" strokeLinecap="round" />
          <g className="cake-bake-whisk" fill="none" stroke="#8c7969" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
            <path d="m333 65-47 101" />
            <path d="M318 92c-19-13-31-9-37 9-5 15 4 28 18 29 15 1 28-16 19-38z" />
          </g>
          <path d="M143 169h-18M395 169h-18" stroke="#d8bd98" strokeWidth="3" strokeLinecap="round" />
          <circle cx="195" cy="193" r="4" fill="#fff2cf" />
          <circle cx="310" cy="207" r="3" fill="#fff2cf" />
        </g>
      )}

      {stage === 2 && (
        <g className="cake-bake-oven">
          <rect x="126" y="43" width="268" height="207" rx="17" fill="#e7d7c3" stroke="#9d8064" strokeWidth="3" />
          <rect x="151" y="67" width="218" height="134" rx="12" fill="#574b46" stroke="#b29474" strokeWidth="4" />
          <rect className="cake-bake-oven__light" x="161" y="77" width="198" height="114" rx="8" fill="url(#bake-oven-light)" />
          <path d="M170 168h180" stroke="#96745a" strokeWidth="5" strokeLinecap="round" />
          <g className="cake-bake-oven__cake">
            <path d="M211 150h96v20h-96z" fill="#d9996c" stroke="#a76f51" strokeWidth="2" />
            <path d="M218 129h82v22h-82z" fill="#edc49b" stroke="#a76f51" strokeWidth="2" />
            <path d="M215 127c7-9 14-8 21 0s14 8 22 0 14-8 22 0 14 8 22 0" fill="none" stroke="#fff4de" strokeWidth="5" strokeLinecap="round" />
          </g>
          <rect x="160" y="211" width="198" height="11" rx="5.5" fill="#b29372" />
          <circle cx="348" cy="57" r="5" fill="#bb8580" />
          <circle cx="365" cy="57" r="5" fill="#c5a768" />
          <rect x="220" y="224" width="80" height="8" rx="4" fill="#9b7b5d" />
          <path d="M195 36c8-10 8-18 0-25M260 35c8-10 8-18 0-25M325 36c8-10 8-18 0-25" fill="none" stroke="#c69b73" strokeWidth="3" strokeLinecap="round" opacity=".55" />
        </g>
      )}

      {stage === 3 && (
        <g className="cake-bake-finished">
          <ellipse cx="260" cy="245" rx="144" ry="19" fill="#b99c79" opacity=".25" />
          <ellipse cx="260" cy="230" rx="150" ry="22" fill="#e3d2b8" stroke="#aa8b67" strokeWidth="2.5" />
          <ellipse cx="260" cy="225" rx="132" ry="14" fill="#fffaf0" stroke="#d2ba97" strokeWidth="1.7" />
          <path d="M165 162h190v52c0 10-9 18-19 18H184c-10 0-19-8-19-18z" fill="#d99670" stroke="#a86e57" strokeWidth="2.5" />
          <path d="M165 163c11-13 24-3 36-10s20 8 32 2 22-6 34 1 22-3 34-2 18 12 28 6 16-8 26 3v17H165z" fill="url(#bake-frosting)" stroke="#e3c8b2" strokeWidth="2" />
          <path d="M201 177v27m39-25v32m42-33v29m40-32v24" stroke="#f1c7a8" strokeWidth="4" strokeLinecap="round" opacity=".8" />
          <path d="M199 123h122v33c0 8-7 15-15 15h-92c-8 0-15-7-15-15z" fill="#e4b48c" stroke="#ad765b" strokeWidth="2.2" />
          <ellipse cx="260" cy="124" rx="61" ry="16" fill="url(#bake-frosting)" stroke="#dfc5ae" strokeWidth="2" />
          <path d="M203 130c9-11 15-3 23-8s14 5 22 1 14-5 22 0 14-3 22-1 11 7 18 5" fill="none" stroke="#fffdf4" strokeWidth="4" strokeLinecap="round" />
          <g fill="#c98291" stroke="#fff7ed" strokeWidth="2">
            <circle cx="222" cy="121" r="7" /><circle cx="260" cy="116" r="7" /><circle cx="298" cy="121" r="7" />
          </g>
          <g fill="#d6b879">
            <path d="M241 112c5-8 11-8 16 0-5 9-11 9-16 0z" />
            <path d="M277 111c5-8 11-8 16 0-5 9-11 9-16 0z" />
          </g>
        </g>
      )}
    </svg>
  );
}

export function CakeBakingJourney({ reducedMotion, stage, onStageChange }: { reducedMotion: boolean; stage: number; onStageChange: (stage: number) => void }) {
  const visualRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<CakeTimeline | null>(null);

  useEffect(() => {
    const visual = visualRef.current;
    if (!visual || reducedMotion) return;
    let cancelled = false;
    let timeline: CakeTimeline | null = null;

    void import("gsap").then(({ gsap }) => {
      if (cancelled || !visual.isConnected) return;
      const entrance = gsap.timeline();
      timeline = entrance;
      entrance.fromTo(visual,
        { autoAlpha: 0, y: 12, scale: 0.985 },
        { autoAlpha: 1, y: 0, scale: 1, duration: 0.38, ease: "power2.out" },
      );
      if (stage === 0) entrance.from(visual.querySelectorAll(".cake-bake-ingredients > *"), { opacity: 0, y: -8, stagger: 0.025, duration: 0.25 }, 0.15);
      if (stage === 1) entrance.fromTo(visual.querySelector(".cake-bake-whisk"), { rotation: -10, transformOrigin: "50% 90%" }, { rotation: 10, duration: 0.22, repeat: 5, yoyo: true, ease: "sine.inOut" }, 0.2);
      if (stage === 2) entrance.from(visual.querySelector(".cake-bake-oven__cake"), { scaleY: 0.65, transformOrigin: "50% 100%", duration: 1.2, ease: "power1.out" }, 0.2);
      if (stage === 3) entrance.from(visual.querySelectorAll(".cake-bake-finished > path, .cake-bake-finished > g"), { opacity: 0, y: -14, stagger: 0.09, duration: 0.35 }, 0.2);
      timelineRef.current = timeline;
    }).catch(() => {
      // The stage remains fully usable without its optional entrance flourish.
    });

    return () => {
      cancelled = true;
      timeline?.kill();
      if (timelineRef.current === timeline) timelineRef.current = null;
      if (visual.isConnected) {
        visual.style.removeProperty("opacity");
        visual.style.removeProperty("visibility");
        visual.style.removeProperty("transform");
      }
    };
  }, [stage, reducedMotion]);

  useEffect(() => () => {
    timelineRef.current?.kill();
    timelineRef.current = null;
  }, []);

  const selectStage = (nextStage: number) => {
    onStageChange(Math.max(0, Math.min(bakingSteps.length - 1, nextStage)));
  };
  const currentStep = bakingSteps[stage];
  const isFinished = stage === bakingSteps.length - 1;

  return (
    <section className="cake-bake-journey" aria-labelledby="cake-bake-heading">
      <div className="cake-bake-journey__visual" ref={visualRef} key={currentStep.id}>
        <BakingIllustration stage={stage} />
      </div>
      <div className="cake-bake-journey__details">
        <div className="cake-bake-journey__heading">
          <span className="cake-bake-journey__eyebrow">A LITTLE BAKING STORY</span>
          <h3 id="cake-bake-heading">Made one step at a time.</h3>
        </div>
        <div className="cake-bake-journey__current" aria-live="polite" aria-atomic="true">
          <span>STEP {stage + 1} OF {bakingSteps.length} · {currentStep.label.toUpperCase()}</span>
          <strong>{currentStep.title}</strong>
          <p>{currentStep.description}</p>
        </div>
        <div className="cake-bake-progress" aria-hidden="true">
          <span style={{ width: `${((stage + 1) / bakingSteps.length) * 100}%` }} />
        </div>
        <ol className="cake-bake-steps" aria-label="Baking story stages">
          {bakingSteps.map((step, index) => (
            <li key={step.id}>
              <button
                type="button"
                aria-label={`Step ${index + 1}: ${step.label}`}
                aria-current={stage === index ? "step" : undefined}
                onClick={() => selectStage(index)}
              >
                <span>{String(index + 1).padStart(2, "0")}</span>
                <small>{step.label}</small>
              </button>
            </li>
          ))}
        </ol>
        <div className="cake-bake-journey__controls">
          <button type="button" className="cake-bake-control" onClick={() => selectStage(stage - 1)} disabled={stage === 0} aria-label="Previous baking step">
            <ArrowLeft size={15} aria-hidden="true" /> <span>Previous</span>
          </button>
          <button type="button" className="cake-bake-control cake-bake-control--primary" onClick={() => selectStage(isFinished ? 0 : stage + 1)} aria-label={isFinished ? "Replay the baking story" : "Continue to the next baking step"}>
            {isFinished ? <><RotateCcw size={14} aria-hidden="true" /><span>Start again</span></> : <><span>Next step</span><ArrowRight size={15} aria-hidden="true" /></>}
          </button>
          {!isFinished && (
            <button type="button" className="cake-bake-control cake-bake-control--skip" onClick={() => selectStage(bakingSteps.length - 1)}>
              <SkipForward size={14} aria-hidden="true" /><span>Skip to finished cake</span>
            </button>
          )}
        </div>
        {isFinished && <p className="cake-bake-journey__ready">The candles are waiting just below.</p>}
      </div>
    </section>
  );
}
