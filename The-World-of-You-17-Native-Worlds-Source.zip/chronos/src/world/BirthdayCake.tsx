import { useEffect, useRef, useState } from "react";
import { CakeSlice, Flame, Sparkles, Wind } from "lucide-react";
import { SceneCanvas } from "../three/SceneCanvas";
import { useBlowDetection } from "../hooks/useBlowDetection";
import { CakeBakingJourney } from "./CakeBakingJourney";
import { WorldSection } from "./WorldSection";

const sparks = Array.from({ length: 26 }, (_, index) => ({
  id: index,
  angle: `${(index * 137.5) % 360}deg`,
  distance: `${50 + (index % 5) * 24}px`,
  delay: `${(index % 8) * 32}ms`,
  color: ["#c98291", "#d6b879", "#dfaa8f", "#9aa58c"][index % 4],
}));

export function BirthdayCake() {
  const [bakeStage, setBakeStage] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(() => window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  const [extinguishing, setExtinguishing] = useState(false);
  const [smoking, setSmoking] = useState<number[]>([]);
  const [candlesLit, setCandlesLit] = useState(0);
  const [wished, setWished] = useState(false);
  const [wishAgain, setWishAgain] = useState(false);
  const [lighting, setLighting] = useState(false);
  const [wishBurst, setWishBurst] = useState(false);
  const lightTimers = useRef<number[]>([]);
  const burstTimer = useRef<number | null>(null);

  useEffect(() => () => {
    lightTimers.current.forEach((timer) => window.clearTimeout(timer));
    if (burstTimer.current !== null) window.clearTimeout(burstTimer.current);
  }, []);

  const clearLightTimers = () => {
    lightTimers.current.forEach((timer) => window.clearTimeout(timer));
    lightTimers.current = [];
  };

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  const blow = () => {
    clearLightTimers();
    setLighting(false);
    setWishBurst(false);
    setSmoking([]);
    if (reducedMotion) {
      setCandlesLit(0);
      setWishAgain(true);
      setExtinguishing(false);
      return;
    }
    setExtinguishing(true);
    const count = candlesLit;
    for (let step = 0; step < count; step += 1) {
      lightTimers.current.push(window.setTimeout(() => {
        const wick = count - step - 1;
        setCandlesLit(wick);
        setSmoking((previous) => [...previous, wick]);
        if (wick === 0) {
          setWishAgain(true);
          setExtinguishing(false);
          setWishBurst(true);
          if (burstTimer.current !== null) window.clearTimeout(burstTimer.current);
          burstTimer.current = window.setTimeout(() => setWishBurst(false), 1050);
        }
      }, step * 150));
    }
    lightTimers.current.push(window.setTimeout(() => setSmoking([]), count * 150 + 700));
  };

  const microphone = useBlowDetection(blow, candlesLit > 0 && !lighting && !extinguishing);

  useEffect(() => {
    const section = document.getElementById("birthday-cake");
    if (!section) return;
    const observer = new IntersectionObserver(([entry]) => { if (!entry.isIntersecting) microphone.stop(); });
    observer.observe(section);
    return () => observer.disconnect();
  }, [microphone.stop]);

  const light = () => {
    microphone.stop();
    clearLightTimers();
    setSmoking([]);
    setWishBurst(false);
    if (burstTimer.current !== null) window.clearTimeout(burstTimer.current);
    setCandlesLit(0);
    setWished(false);
    setWishAgain(false);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setCandlesLit(5);
      setLighting(false);
      return;
    }
    setLighting(true);
    lightTimers.current = Array.from({ length: 5 }, (_, index) => window.setTimeout(() => {
      setCandlesLit(index + 1);
      if (index === 4) setLighting(false);
    }, (index + 1) * 210));
  };

  const makeWish = () => {
    setWished(true);
    setWishAgain(false);
    setWishBurst(false);
    blow();
  };

  return (
    <WorldSection id="birthday-cake" className="cake-section" eyebrow="A WISH BY CANDLELIGHT" sideNote="WISH / 10">
      <div className="cake-intro"><CakeSlice size={19} strokeWidth={1.1} /><p>A tiny birthday ritual. Watch the candles catch one by one, make a wish, and blow them out. Use the button, or explicitly enable the optional microphone.</p></div>
      <CakeBakingJourney reducedMotion={reducedMotion} stage={bakeStage} onStageChange={(stage) => { microphone.stop(); clearLightTimers(); setCandlesLit(0); setWished(false); setWishAgain(false); setWishBurst(false); setLighting(false); setExtinguishing(false); setSmoking([]); setBakeStage(stage); }} />
      <div className={`birthday-cake-scene${candlesLit ? " is-lit" : ""}${wished ? " has-wished" : ""}`}>
        <div className="cake-scene__glow" aria-hidden="true" />
        <div className="cake-balloon-cluster" aria-hidden="true"><i className="cake-balloon cake-balloon--rose" /><i className="cake-balloon cake-balloon--gold" /><i className="cake-balloon cake-balloon--sage" /></div>
        <div className={`cake-fireworks${wishBurst ? " is-bursting" : ""}`} aria-hidden="true"><i /><i /><i /></div>
        <div className={`cake-scene__stars${wishBurst ? " is-bursting" : ""}`} key={wishBurst ? "bursting" : "idle"} aria-hidden="true">{sparks.map((spark) => <i key={spark.id} style={{ "--spark-angle": spark.angle, "--spark-distance": spark.distance, "--spark-delay": spark.delay, "--spark-color": spark.color } as React.CSSProperties} />)}</div>
        <SceneCanvas kind="cake" state={{ bakeStage, candles: candlesLit, blowing: extinguishing, celebration: wishAgain }} label="A real-time three-dimensional layered sponge cake with piped cream, berries, five wax candles, animated flame meshes and warm candlelight." />
        <details className="cake-illustration-fallback"><summary>View the illustrated cake alternative</summary>
        <div className="cake-display">
          <svg className="cake-svg" viewBox="0 0 520 390" role="img" aria-labelledby="cake-svg-title cake-svg-desc">
            <title id="cake-svg-title">A birthday cake with five candles</title>
            <desc id="cake-svg-desc">A hand-drawn cream and blush layer cake with candles that respond to the buttons below.</desc>
            <defs>
              <linearGradient id="cake-icing" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#fff9ed" /><stop offset="1" stopColor="#f2d9c4" /></linearGradient>
              <linearGradient id="cake-sponge" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#e9b487" /><stop offset="1" stopColor="#d58e70" /></linearGradient>
              <linearGradient id="cake-plate" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#f6e5bf" /><stop offset="0.5" stopColor="#b78f5d" /><stop offset="1" stopColor="#f4e4c5" /></linearGradient>
              <filter id="cake-shadow" x="-30%" y="-20%" width="160%" height="170%"><feGaussianBlur in="SourceAlpha" stdDeviation="7" /><feOffset dy="9" /><feComponentTransfer><feFuncA type="linear" slope="0.19" /></feComponentTransfer><feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge></filter>
            </defs>
            <ellipse cx="260" cy="350" rx="176" ry="17" fill="#d9c3a5" opacity=".38" />
            <ellipse cx="260" cy="331" rx="185" ry="23" fill="url(#cake-plate)" stroke="#b18c60" strokeWidth="2" />
            <ellipse cx="260" cy="326" rx="163" ry="15" fill="#fbf5e9" stroke="#dec89f" strokeWidth="1.2" />
            <g filter="url(#cake-shadow)">
              <path d="M118 243h284v74c0 23-19 42-42 42H160c-23 0-42-19-42-42z" fill="url(#cake-sponge)" stroke="#ae735d" strokeWidth="2" />
              <path d="M118 244c0-17 15-30 34-30h216c19 0 34 13 34 30v25c-14-10-23 5-37 4-13-1-15-15-29-15s-16 16-29 16-15-17-30-17-17 16-30 16-16-16-31-16-16 15-29 15-17-13-34-8c-12 4-20 13-35 12z" fill="url(#cake-icing)" stroke="#e6d0b8" strokeWidth="2" />
              <path d="M159 213h202v23c0 16-14 29-30 29H189c-16 0-30-13-30-29z" fill="#f5d9c5" stroke="#c88383" strokeWidth="1.5" />
              <ellipse cx="260" cy="213" rx="101" ry="22" fill="url(#cake-icing)" stroke="#dec3aa" strokeWidth="1.7" />
              <path d="M168 276c19-7 30 8 45 8s20-14 36-14 19 14 35 14 22-15 38-15 22 14 40 9" fill="none" stroke="#f7dbc1" strokeWidth="5" opacity=".86" />
              <path d="M160 309c16-5 26 6 39 6 16 0 18-11 35-11 14 0 19 10 34 10 17 0 21-11 37-11 16 0 20 9 34 8" fill="none" stroke="#f1c7aa" strokeWidth="5" opacity=".76" />
              <g fill="#c98291" stroke="#fff5eb" strokeWidth="2"><circle cx="190" cy="242" r="5" /><circle cx="231" cy="228" r="5" /><circle cx="274" cy="239" r="5" /><circle cx="316" cy="226" r="5" /><circle cx="350" cy="244" r="5" /></g>
              <g fill="#d6b879"><path d="M211 255c6-10 12-10 18 0-6 10-12 10-18 0z" /><path d="M290 255c6-10 12-10 18 0-6 10-12 10-18 0z" /><path d="M331 275c6-10 12-10 18 0-6 10-12 10-18 0z" /></g>
            </g>
            <g className={candlesLit > 0 ? "cake-candles is-lit" : "cake-candles"} strokeLinecap="round">
              <g transform="translate(190 186)"><rect x="-7" y="-43" width="14" height="45" rx="5" fill="#e4bac1" stroke="#b9848d" strokeWidth="1.4" /><path d="M-6-34h12M-6-21h12M-6-8h12" stroke="#fff6eb" strokeWidth="3" />{candlesLit > 0 && <g className="cake-flame"><path d="M0-48c-16-15 2-26 2-36 14 15 16 28 4 36z" fill="#e6a764" /><path d="M2-49c-6-7 1-13 2-18 7 9 6 14 0 18z" fill="#fff5c7" /></g>}</g>
              <g transform="translate(225 177)"><rect x="-7" y="-47" width="14" height="49" rx="5" fill="#e4c39c" stroke="#aa8a58" strokeWidth="1.4" /><path d="M-6-36h12M-6-22h12M-6-8h12" stroke="#fff6eb" strokeWidth="3" />{candlesLit > 1 && <g className="cake-flame"><path d="M0-52c-16-15 2-26 2-36 14 15 16 28 4 36z" fill="#e6a764" /><path d="M2-53c-6-7 1-13 2-18 7 9 6 14 0 18z" fill="#fff5c7" /></g>}</g>
              <g transform="translate(260 172)"><rect x="-7" y="-50" width="14" height="52" rx="5" fill="#d6b879" stroke="#a98c50" strokeWidth="1.4" /><path d="M-6-39h12M-6-24h12M-6-9h12" stroke="#fff6eb" strokeWidth="3" />{candlesLit > 2 && <g className="cake-flame"><path d="M0-55c-16-15 2-26 2-36 14 15 16 28 4 36z" fill="#e6a764" /><path d="M2-56c-6-7 1-13 2-18 7 9 6 14 0 18z" fill="#fff5c7" /></g>}</g>
              <g transform="translate(295 177)"><rect x="-7" y="-47" width="14" height="49" rx="5" fill="#d8b3a1" stroke="#aa8477" strokeWidth="1.4" /><path d="M-6-36h12M-6-22h12M-6-8h12" stroke="#fff6eb" strokeWidth="3" />{candlesLit > 3 && <g className="cake-flame"><path d="M0-52c-16-15 2-26 2-36 14 15 16 28 4 36z" fill="#e6a764" /><path d="M2-53c-6-7 1-13 2-18 7 9 6 14 0 18z" fill="#fff5c7" /></g>}</g>
              <g transform="translate(330 186)"><rect x="-7" y="-43" width="14" height="45" rx="5" fill="#bdd0bc" stroke="#819b82" strokeWidth="1.4" /><path d="M-6-34h12M-6-21h12M-6-8h12" stroke="#fff6eb" strokeWidth="3" />{candlesLit > 4 && <g className="cake-flame"><path d="M0-48c-16-15 2-26 2-36 14 15 16 28 4 36z" fill="#e6a764" /><path d="M2-49c-6-7 1-13 2-18 7 9 6 14 0 18z" fill="#fff5c7" /></g>}</g>
            </g>
            <g aria-hidden="true">{smoking.map((wick) => <path key={wick} className="cake-wick-smoke" d={`M${[190,225,260,295,330][wick]} ${[138,125,117,125,138][wick]} c-9-10 9-16 0-26 s8-16 2-24`} fill="none" stroke="#98877a" strokeWidth="3" strokeLinecap="round" />)}</g>
            <g fill="#e8bfc2" stroke="#fff2e8" strokeWidth="1.5"><path d="M131 297c8-11 16-11 24 0-8 10-16 10-24 0z" /><path d="M370 295c8-11 16-11 24 0-8 10-16 10-24 0z" /></g>
          </svg>
          <span className="cake-display__plaque">HAPPY BIRTHDAY, BHUMI</span>
        </div>
        </details>
        <div className="cake-ritual">
          <div className="cake-ritual__status" aria-live="polite" aria-atomic="true">
            {!candlesLit && !wishAgain && !extinguishing && <><span className="cake-ritual__icon"><Flame size={18} /></span><strong>Ready when you are.</strong><small>Finish or skip the baking story, then light the candles.</small></>}
            {candlesLit > 0 && !wished && !extinguishing && <><span className="cake-ritual__icon is-lit"><Flame size={18} /></span><strong>The candles are glowing.</strong><small>Hold a wish quietly. It belongs to you.</small></>}
            {wished && candlesLit > 0 && !extinguishing && <><span className="cake-ritual__icon is-lit"><Sparkles size={18} /></span><strong>Your wish is yours to keep.</strong><small>Nothing is recorded or shared.</small></>}
            {extinguishing && <><strong>A gentle breath…</strong><small>The candles are going out one by one.</small></>}
            {wishAgain && !candlesLit && <><span className="cake-ritual__icon"><Wind size={18} /></span><strong>Wish made. Candles out.</strong><small>You can light them again whenever you like.</small></>}
          </div>
          <div className="microphone-panel">
            <p id="mic-privacy">{microphone.message}</p>
            <button type="button" className="cake-button" onClick={() => { if (microphone.phase === "idle") void microphone.start(); else { microphone.stop(); } }} disabled={microphone.phase === "idle" && (!candlesLit || lighting || extinguishing)} aria-describedby="mic-privacy">{microphone.phase === "idle" ? "Enable microphone for this wish" : "Cancel microphone"}</button>
            <span role="status">{microphone.phase === "calibrating" ? "Calibrating room noise…" : microphone.phase === "listening" ? "Listening for sustained airflow-like sound…" : microphone.phase === "requesting" ? "Permission requested…" : "Microphone off"}</span>
            {microphone.phase === "listening" && <meter min={0} max={1} value={microphone.level} aria-label="Sustained airflow confidence" />}
          </div>
          <div className="cake-ritual__buttons">
            <button type="button" className="cake-button cake-button--light" onClick={candlesLit ? () => { microphone.stop(); blow(); } : light} disabled={bakeStage !== 3 || lighting || extinguishing}>{candlesLit ? <><Wind size={15} /> Blow them out</> : <><Flame size={15} /> Light the candles</>}</button>
            <button type="button" className="cake-button cake-button--wish" disabled={bakeStage !== 3 || !candlesLit || lighting || extinguishing} onClick={() => { microphone.stop(); makeWish(); }}><Sparkles size={15} /> Make a wish</button>
          </div>
        </div>
      </div>
      <p className="cake-section__footnote">The 17 November birthday date is preserved without a year. No countdown is used. Microphone access is optional, starts only with permission, and stops after use, cancellation, tab hiding or timeout. No audio is recorded.</p>
    </WorldSection>
  );
}
