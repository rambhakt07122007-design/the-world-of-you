import { useEffect, useState, type CSSProperties } from "react";
import { ArrowUpRight, PackageOpen, Sparkles } from "lucide-react";
import { ArchiveDialog } from "../components/ArchiveDialog";
import { chronosContent } from "../content/chronosContent";
import { giftDefinitions, type GiftDefinition } from "../content/giftsContent";
import { GiftExperience } from "./GiftExperiences";
import { WorldSection } from "./WorldSection";

const openedGiftStorageKey = "world-of-you-opened-gifts";
const validGiftIds = new Set(giftDefinitions.map((gift) => gift.id));

function readOpenedGifts(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const saved: unknown = JSON.parse(window.localStorage.getItem(openedGiftStorageKey) ?? "[]");
    if (!Array.isArray(saved)) return [];
    return [...new Set(saved.filter((id): id is string => typeof id === "string" && validGiftIds.has(id)))];
  } catch {
    return [];
  }
}

export function GiftRoom({ soundEnabled }: { soundEnabled: boolean }) {
  const [selected, setSelected] = useState<GiftDefinition | null>(null);
  const [opened, setOpened] = useState<string[]>(readOpenedGifts);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    try { window.localStorage.setItem(openedGiftStorageKey, JSON.stringify(opened)); }
    catch { /* Private browsing or storage limits must not block the gifts. */ }
  }, [opened]);

  const openGift = (gift: GiftDefinition) => {
    setSelected(gift);
    const total = opened.includes(gift.id) ? opened.length : opened.length + 1;
    setOpened((current) => current.includes(gift.id) ? current : [...current, gift.id]);
    setNotice(`${String(total).padStart(2, "0")} of 17 gifts opened. Replaying stays available.`);
  };

  const completionLabel = opened.length === giftDefinitions.length
    ? "Collection complete · all 17 gifts remain openable and replayable."
    : notice || "Open any gift in any order. No gift is locked behind another.";

  return (
    <WorldSection id="gifts" className="gift-room-section" eyebrow="SEVENTEEN DISTINCT EXPERIENCES" sideNote="COLLECTION / 17">
      <p className="gift-room__intro">{chronosContent.gifts.intro}</p>
      <div className="gift-progress" role="status" aria-live="polite">
        <div className="gift-progress__label"><span><PackageOpen size={15} aria-hidden="true" /> GIFTS OPENED</span><strong>{String(opened.length).padStart(2, "0")} <i>/</i> 17</strong></div>
        <div className="gift-progress__bar" role="progressbar" aria-label="Gifts opened" aria-valuemin={0} aria-valuemax={17} aria-valuenow={opened.length}><i style={{ width: `${(opened.length / giftDefinitions.length) * 100}%` }} /></div>
        <span className="gift-progress__notice">{completionLabel}</span>
      </div>
      <div className="gift-parcels" role="list" aria-label="Seventeen unique gift experiences">
        {giftDefinitions.map((gift, index) => {
          const isOpen = opened.includes(gift.id);
          return (
            <div className="gift-parcel-wrap" role="listitem" key={gift.id}>
              <button
                type="button"
                onClick={() => openGift(gift)}
                className={`gift-parcel${isOpen ? " is-opened" : ""}`}
                data-gift-id={gift.id}
                data-visual={gift.visual}
                style={{ "--gift-color": gift.color, "--ribbon-color": gift.ribbon, "--gift-index": index } as CSSProperties}
                aria-label={`Open gift ${gift.number}: ${gift.title}${isOpen ? ", replay experience" : ""}`}
                aria-haspopup="dialog"
                aria-expanded={selected?.id === gift.id}
              >
                <span className="gift-parcel__number">{gift.number}</span>
                <span className="gift-parcel__preview" aria-hidden="true"><img src={`/assets/gift-previews/${gift.id}.webp`} alt="" width={480} height={360} loading="lazy" decoding="async" /></span>
                <span className="gift-parcel__title">{gift.shortTitle}</span>
                <span className="gift-parcel__subtitle">{gift.experience === "ultimate-surprise" ? "GRAND FINALE" : gift.visual.toUpperCase().replace(/-/g, " ")}</span>
                <span className="gift-parcel__action">{isOpen ? "REPLAY" : "OPEN EXPERIENCE"}<ArrowUpRight size={12} aria-hidden="true" /></span>
                {isOpen && <span className="gift-parcel__opened-mark" aria-hidden="true"><Sparkles size={15} /></span>}
              </button>
            </div>
          );
        })}
      </div>
      <p className="gift-room__note"><span aria-hidden="true">✿</span> Personal reasons, open-when notes, photos, audio, coupons and future hopes stay blank until supplied or approved. No gift is locked.</p>
      <ArchiveDialog
        open={selected !== null}
        onClose={() => setSelected(null)}
        eyebrow={selected ? `GIFT ${selected.number} OF 17 · ${selected.experience.toUpperCase().replace(/-/g, " ")}` : undefined}
        title={selected?.title ?? "A little gift"}
        variant={selected?.experience === "ultimate-surprise" ? "dark" : "paper"}
        className="archive-dialog--gift"
      >
        {selected && <GiftExperience key={selected.id} gift={selected} onReturn={() => setSelected(null)} soundEnabled={soundEnabled} />}
      </ArchiveDialog>
    </WorldSection>
  );
}
