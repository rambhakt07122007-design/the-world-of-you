import { useEffect, useRef, useState, type DragEvent, type FormEvent, type PointerEvent, type ReactNode } from "react";
import { GiftStage } from "../three/GiftStage";
import { chronosContent } from "../content/chronosContent";
import {
  couponEntries,
  futureGardenLeaves,
  openWhenLetters,
  reasonNotes,
  treasureHuntPuzzle,
  type GiftDefinition,
} from "../content/giftsContent";

type GiftExperienceProps = { gift: GiftDefinition; onReturn: () => void; soundEnabled: boolean };

function useOptionalAudio(src: string, soundEnabled: boolean) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const contextRef = useRef<AudioContext|null>(null);
  const [analyser,setAnalyser]=useState<AnalyserNode|null>(null);
  useEffect(()=>()=>{void contextRef.current?.close();},[]);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.72);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    audio.currentTime = 0;
    setPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    setError("");
    const onTime = () => setCurrentTime(audio.currentTime || 0);
    const onDuration = () => setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
    const onEnded = () => setPlaying(false);
    const onError = () => setError("This local audio file could not be loaded.");
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onDuration);
    audio.addEventListener("durationchange", onDuration);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    return () => {
      audio.pause();
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onDuration);
      audio.removeEventListener("durationchange", onDuration);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
    };
  }, [src]);
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = !soundEnabled;
    if (!soundEnabled && !audio.paused) {
      audio.pause();
      setPlaying(false);
      setError("Global sound is off; playback was paused.");
    } else if (soundEnabled) {
      setError((current) => current === "Global sound is off; playback was paused." ? "" : current);
    }
  }, [soundEnabled]);

  const play = async () => {
    const audio = audioRef.current;
    if (!audio || !src) {
      setError("No owner-provided or licensed audio has been added yet.");
      return;
    }
    if (!soundEnabled) {
      setError("Sound is off. Turn it on in the top bar, then press Play.");
      return;
    }
    setError("");
    try {
      if(!contextRef.current){const context=new AudioContext();const node=context.createAnalyser();node.fftSize=128;const source=context.createMediaElementSource(audio);source.connect(node);node.connect(context.destination);contextRef.current=context;setAnalyser(node);}
      await contextRef.current.resume();
      await audio.play();
      setPlaying(true);
    } catch {
      setPlaying(false);
      setError("Playback could not start. Check the local audio file.");
    }
  };
  const pause = () => { audioRef.current?.pause(); setPlaying(false); };
  const stop = () => { if (audioRef.current) { audioRef.current.pause(); audioRef.current.currentTime = 0; } setPlaying(false); setCurrentTime(0); };
  const rewind = () => { if (audioRef.current) audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10); };
  const changeVolume = (next: number) => {
    const safeVolume = Math.max(0, Math.min(1, next));
    setVolume(safeVolume);
    if (audioRef.current) audioRef.current.volume = safeVolume;
  };

  return {
    audioRef,
    analyser,
    playing,
    volume,
    changeVolume,
    currentTime,
    duration,
    progress: duration > 0 ? (currentTime / duration) * 100 : 0,
    play,
    pause,
    stop,
    rewind,
    error,
  };
}

function ExperienceReplay({ onReplay, label = "Replay this experience" }: { onReplay: () => void; label?: string }) {
  return <button type="button" className="gift-control gift-control--quiet" onClick={onReplay}>↻ <span>{label}</span></button>;
}

function EmptyCopy({ children }: { children: ReactNode }) {
  return <p className="gift-empty-copy" role="note">{children}</p>;
}

function SecretLetterExperience() {
  const [open, setOpen] = useState(false);
  const [writingKey, setWritingKey] = useState(0);
  const [progress, setProgress] = useState(0);
  const [skip, setSkip] = useState(false);
  const letter = chronosContent.letters.letters[0];
  return (
    <section className="gift-letter" aria-label="Secret letter experience">
      <GiftStage kind="letter" state={{ open, replay: writingKey, immediate: skip, detail: [letter.salutation,...letter.paragraphs,letter.closing,letter.signature,letter.ps].filter(Boolean).join("\n\n") }} onPick={() => {setSkip(false);setOpen(v=>!v);}} onProgress={setProgress} label="A physically thick letter bends along two rounded creases after leaving a wax-sealed hinged envelope on its writing desk." />
      <div className="gift-world-console">
      
      {open && (skip || progress >= .995) ? (
        <article className="gift-letter__reading" key={writingKey}>
          <p className="gift-letter__salutation">{letter.salutation}</p>
          {letter.paragraphs.map((paragraph, index) => <p key={index}>{paragraph}</p>)}
          <p className="gift-letter__closing">{letter.closing}<br /><strong>{letter.signature}</strong></p>
          {letter.ps && <p className="gift-letter__ps">{letter.ps}</p>}
        </article>
      ) : <EmptyCopy>Open the envelope to read the existing source letter. No new personal copy has been added.</EmptyCopy>}
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={() => {setSkip(false);setOpen((value) => !value);}}>{open ? "Fold the letter" : "Open the letter"}</button>
        <button type="button" className="gift-control" onClick={() => { setWritingKey((value) => value + 1); setSkip(false); setProgress(0); setOpen(true); }}>Replay the writing</button>
        <button type="button" className="gift-control" onClick={() => {setSkip(true);setOpen(true);}}>Skip animation</button>
        <button type="button" className="gift-control" disabled aria-describedby="gift-letter-audio-note">Play narration</button>
      </div>
      <small id="gift-letter-audio-note" className="gift-audio-note">Voice narration is not available until a real recording is supplied.</small>
    </div>
    </section>
  );
}

function ReasonJarExperience() {
  const [index, setIndex] = useState(0);
  const [lidOpen,setLidOpen]=useState(false);
  const [drawn,setDrawn]=useState(false);
  const [turn,setTurn]=useState(0);
  const [showAll, setShowAll] = useState(false);
  const [shuffleCount, setShuffleCount] = useState(0);
  const drawAnother = () => {
    setIndex((current) => (current + 1 + Math.floor(Math.random() * (reasonNotes.length - 1))) % reasonNotes.length);
    setShowAll(false); setLidOpen(true);setDrawn(true);
    setShuffleCount((count) => count + 1);
  };
  const note = reasonNotes[index];
  return (
    <section className="gift-jar" aria-label="Jar of reasons experience">
      <GiftStage kind="jar" state={{open:lidOpen,selected:drawn?index:null,turn,replay:shuffleCount}} onPick={i=>{if(lidOpen){setIndex(i);setDrawn(true);}}} label="A thick hollow glass jar with threaded rim, brass lid, fabric bow and seventeen separate folded paper notes. Open the lid, turn the jar and choose a numbered note." />
      <div className="gift-world-console">
      <div className="gift-control-row"><button type="button" className="gift-control" aria-pressed={lidOpen} onClick={()=>{setLidOpen(v=>!v);setDrawn(false);}}>{lidOpen?"Close jar lid":"Open jar lid"}</button><button type="button" className="gift-control" onClick={()=>setTurn(v=>v-.4)}>Turn jar left</button><button type="button" className="gift-control" onClick={()=>setTurn(v=>v+.4)}>Turn jar right</button><button type="button" className="gift-control" disabled={!drawn} onClick={()=>setDrawn(false)}>Put note back</button></div>
      <div className="gift-note-picker" role="group" aria-label="Pick one of seventeen physical notes">{reasonNotes.map((n,i)=><button key={n.id} type="button" disabled={!lidOpen} aria-pressed={drawn&&index===i} onClick={()=>{setIndex(i);setDrawn(true);}}>{String(i+1).padStart(2,"0")}</button>)}</div>
      <div className="gift-jar__note" aria-live="polite">
        <small>NOTE {String(index + 1).padStart(2, "0")} / 17</small>
        {note.text ? <p>{note.text}</p> : <p className="is-empty">This note is waiting for an owner-written reason.</p>}
      </div>
      {showAll && <ol className="gift-jar__all">{reasonNotes.map((item, itemIndex) => <li key={item.id}><span>{String(itemIndex + 1).padStart(2, "0")}</span>{item.text || "Reason to be written by the owner"}</li>)}</ol>}
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={drawAnother}>Draw another note</button>
        <button type="button" className="gift-control" onClick={drawAnother}>Shuffle the jar</button>
        <button type="button" className="gift-control" onClick={() => setShowAll((value) => !value)}>{showAll ? "Hide all notes" : "Read all 17"}</button>
      </div>
      <EmptyCopy>All 17 reason slots are editable in <code>src/content/giftsContent.ts</code>; they remain blank until the owner writes them.</EmptyCopy>
    </div>
    </section>
  );
}

function EternalFlowerExperience() {
  const [stage, setStage] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [messageVisible, setMessageVisible] = useState(false);
  return (
    <section className="gift-flower" aria-label="Everlasting flower experience">
      <GiftStage kind="flower" state={{ growth: stage, turn: rotation * Math.PI / 180 }} label="A procedural three-dimensional rose grows from a seed, unfolds leaves and opens twenty-one individually hinged curved petals. Grow and rotate controls follow." />
      <div className="gift-world-console">
      <p className="gift-flower__caption" aria-live="polite">{stage === 0 ? "A seed, held in the soil." : stage < 4 ? ["Seed","Roots opening beneath the soil.","A sprout emerges.","The leaves unfold."][stage] : "The bloom is open. It can begin again."}</p>
      {messageVisible && <EmptyCopy>The hidden message is an editable owner-written field; no message has been supplied yet.</EmptyCopy>}
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={() => setStage((value) => (value + 1) % 5)}>{["Grow the flower","Grow the sprout","Unfold the leaves","Open the bloom","Begin again"][stage]}</button>
        <button type="button" className="gift-control" onClick={() => setRotation((value) => value - 28)} aria-label="Rotate flower left">↶ Rotate left</button>
        <button type="button" className="gift-control" onClick={() => setRotation((value) => value + 28)} aria-label="Rotate flower right">↷ Rotate right</button>
        <button type="button" className="gift-control" onClick={() => setMessageVisible((value) => !value)}>{messageVisible ? "Hide message slot" : "Reveal hidden message"}</button>
      </div>
    </div>
    </section>
  );
}

function LittleUniverseExperience() {
  const [selected, setSelected] = useState("first-connection");
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const milestones = [
    { id: "first-connection", date: chronosContent.dates.firstConnectionLabel, title: "First connection", detail: "The verified date recorded in the source archive." },
    { id: "proposal", date: chronosContent.dates.proposalLabel, title: "The proposal", detail: "The verified date recorded in the source archive." },
  ];
  return (
    <section className="gift-universe" aria-label="Our Little Universe experience">
      <GiftStage kind="universe" state={{selected:milestones.findIndex(m=>m.id===selected),growth:zoom,turn:rotation*Math.PI/180}} onPick={i=>setSelected(milestones[i%milestones.length].id)} label="A brass miniature orrery, five orbiting planets, ringed world and two selectable star markers for the only verified dates." />
      <div className="gift-world-console">
      <div className="gift-control-row">{milestones.map(m=><button key={m.id} type="button" className="gift-control" aria-pressed={selected===m.id} onClick={()=>setSelected(m.id)}>{m.title} · {m.date}</button>)}</div>
      <article className="gift-universe__record" aria-live="polite">
        <small>VERIFIED ARCHIVE · NO OTHER DATES ADDED</small>
        <h3>{milestones.find((milestone) => milestone.id === selected)?.title}</h3>
        <p>{milestones.find((milestone) => milestone.id === selected)?.date}</p>
        <span>{milestones.find((milestone) => milestone.id === selected)?.detail}</span>
      </article>
      <div className="gift-control-row">
        <button type="button" className="gift-control" onClick={() => setZoom((value) => Math.min(1.6, value + 0.15))}>Zoom in</button>
        <button type="button" className="gift-control" onClick={() => setZoom((value) => Math.max(0.85, value - 0.15))}>Zoom out</button>
        <button type="button" className="gift-control" onClick={() => setRotation((value) => value + 24)}>Rotate the map</button>
        <button type="button" className="gift-control" onClick={() => { setZoom(1); setRotation(0); }}>Return to overview</button>
      </div>
    </div>
    </section>
  );
}

function CassetteExperience({ soundEnabled }: { soundEnabled: boolean }) {
  const track = chronosContent.music.tracks[0];
  const audio = useOptionalAudio(track.src, soundEnabled);
  const [inserted, setInserted] = useState(false);
  return (
    <section className="gift-cassette" aria-label="Bhumi FM cassette experience">
      <GiftStage kind="cassette" state={{open:inserted,playing:audio.playing}} analyser={audio.analyser} label="A wooden cassette deck with physical controls, two visible tape reels and mechanical insertion. Reels follow actual playback only." />
      <div className="gift-world-console">
      
      <audio ref={audio.audioRef} src={track.src || undefined} preload="none" muted={!soundEnabled} />
      <p className="gift-cassette__status" role="status">{track.src ? (audio.playing ? "Playing the supplied local recording." : "Cassette ready.") : "No voice recording was supplied. The deck will not fabricate one."}</p>
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={() => setInserted((value) => !value)}>{inserted ? "Eject cassette" : "Insert cassette"}</button>
        <button type="button" className="gift-control" disabled={!track.src || !inserted || audio.playing} onClick={() => void audio.play()}>Play</button>
        <button type="button" className="gift-control" disabled={!track.src || !audio.playing} onClick={audio.pause}>Pause</button>
        <button type="button" className="gift-control" disabled={!track.src} onClick={audio.stop}>Stop</button>
        <button type="button" className="gift-control" disabled={!track.src} onClick={audio.rewind}>Rewind 10s</button>
      </div>
      <label className="gift-volume">Volume <input type="range" min="0" max="1" step="0.01" value={audio.volume} disabled={!track.src} onChange={(event) => audio.changeVolume(Number(event.target.value))} aria-label="Cassette volume" /></label>
      {audio.error && <p className="gift-audio-note" role="status">{audio.error}</p>}
      {track.src && <p className="gift-audio-caption">{chronosContent.music.tracks[0].note}</p>}
    </div>
    </section>
  );
}

function MemoryCinemaExperience() {
  const stageRef = useRef<HTMLDivElement>(null);
  const [powered, setPowered] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [slide, setSlide] = useState(0);
  const photos = chronosContent.gallery.photos.filter((photo) => photo.src.trim().length > 0);
  useEffect(() => {
    if (!playing || !photos.length) return;
    const timer = window.setInterval(() => setSlide((current) => (current + 1) % photos.length), 3800);
    return () => window.clearInterval(timer);
  }, [playing, photos.length]);
  const showSlide = (direction: number) => {
    if (!photos.length) return;
    setSlide((current) => (current + direction + photos.length) % photos.length);
  };
  const toggleFullscreen = async () => {
    if (!stageRef.current) return;
    try {
      if (!document.fullscreenElement) await stageRef.current.requestFullscreen();
      else await document.exitFullscreen();
    } catch { /* Fullscreen is an optional browser permission. */ }
  };
  return (
    <section className="gift-cinema" aria-label="Memory cinema experience">
      <GiftStage kind="cinema" state={{open:powered,playing,artwork:photos[slide]?.src}} label="A miniature film projector with two metal reels, moving film path, projection beam and a screen reserved for genuine supplied photographs." />
      <div className="gift-world-console">
      <div className={`gift-cinema__theatre${powered ? " is-lit" : ""}`} ref={stageRef}>
        <div className="gift-cinema__curtain gift-cinema__curtain--left" /><div className="gift-cinema__curtain gift-cinema__curtain--right" />
        <div className="gift-cinema__screen">
          {photos.length ? <figure><img src={photos[slide].src} alt={photos[slide].caption} /><figcaption>{photos[slide].caption}</figcaption></figure> : <div className="gift-cinema__placeholder"><span>FRAME {String(slide + 1).padStart(2, "0")}</span><strong>Held for a real photograph</strong><small>No personal photos were supplied.</small></div>}
        </div>
        <div className={`gift-cinema__beam${powered ? " is-on" : ""}`} aria-hidden="true" />
        <div className="gift-cinema__seats" aria-hidden="true"><i /><i /><i /></div>
      </div>
      <p className="gift-cinema__status" role="status">{photos.length ? `Photograph ${slide + 1} of ${photos.length} · ${playing ? "slideshow playing" : "paused"}` : "The projector is ready; the memory screen stays blank until genuine photos are supplied."}</p>
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={() => setPowered((value) => !value)}>{powered ? "Dim the theatre" : "Start projector"}</button>
        <button type="button" className="gift-control" onClick={() => setPlaying((value) => !value)} disabled={!photos.length}>{playing ? "Pause" : "Play"}</button>
        <button type="button" className="gift-control" onClick={() => showSlide(-1)} disabled={!photos.length}>Previous</button>
        <button type="button" className="gift-control" onClick={() => showSlide(1)} disabled={!photos.length}>Next</button>
        <button type="button" className="gift-control" onClick={() => { setPlaying(false); setPowered(false); setSlide(0); }}>Replay</button>
        <button type="button" className="gift-control" onClick={() => void toggleFullscreen()}>Full screen</button>
      </div>
    </div>
    </section>
  );
}

function WishesExperience() {
  const wishes = chronosContent.flowerGarden.wishes;
  const [selected, setSelected] = useState<number[]>([]);
  const [showAll, setShowAll] = useState(false);
  const [activeWish, setActiveWish] = useState<number | null>(null);
  const toggleStar = (index: number) => {
    setActiveWish(index);
    setSelected((current) => current.includes(index) ? current.filter((item) => item !== index) : [...current, index]);
  };
  return (
    <section className="gift-wishes" aria-label="A Thousand Wishes experience">
      <GiftStage kind="wishes" state={{selected:activeWish,collected:selected}} onPick={toggleStar} label="A sculptural wishing tree holds ten physical star lanterns, one for each existing archive wish. Pick a star to collect its light." />
      <div className="gift-world-console">
      
      <div className="gift-wishes__note" aria-live="polite">
        <small>{activeWish === null ? "A SOURCE-ARCHIVE WISH" : `WISH ${String(activeWish + 1).padStart(2, "0")} · ${selected.includes(activeWish) ? "COLLECTED" : "RELEASED"}`}</small>
        <p>{activeWish === null ? "Choose a star to reveal one of the wishes already written for this experience." : wishes[activeWish]}</p>
      </div>
      <div className="gift-note-picker" role="group" aria-label="Wish lanterns">{wishes.map((_,i)=><button key={i} type="button" aria-pressed={selected.includes(i)} onClick={()=>toggleStar(i)}>Wish {i+1}</button>)}</div>
      <div className="gift-wishes__meta"><span>{selected.length} / {wishes.length} wishes collected</span><span>{selected.length > 1 ? "A constellation is connected." : "Collect two or more stars to connect them."}</span></div>
      {showAll && <ol className="gift-wishes__all">{wishes.map((wish, index) => <li key={index}><span>{String(index + 1).padStart(2, "0")}</span>{wish}</li>)}</ol>}
      <div className="gift-control-row">
        <button type="button" className="gift-control gift-control--primary" onClick={() => setShowAll((value) => !value)}>{showAll ? "Hide wishes" : "Display all wishes"}</button>
        <button type="button" className="gift-control" onClick={() => { setSelected([]); setActiveWish(null); }}>Clear constellation</button>
      </div>
    </div>
    </section>
  );
}

function CrownExperience() {
  const [rotation, setRotation] = useState(0);
  const [detail, setDetail] = useState("crown");
  const [messageVisible, setMessageVisible] = useState(false);
  const sourceNote = chronosContent.gifts.specials["08"].message;
  return (
    <section className="gift-crown" aria-label="Queen's Crown experience">
      <GiftStage kind="crown" state={{ turn: rotation * Math.PI / 180, detail }} label="An eight-point metallic crown assembles on a velvet plinth. Faceted gemstones, beveled gold points and molded rings can be inspected and rotated with the controls below." />
      <div className="gift-world-console">
      <div className="gift-crown__inspection" role="group" aria-label="Inspect crown details">
        {[
          ["crown", "The crown"], ["jewels", "The jewels"], ["velvet", "The velvet"],
        ].map(([id, label]) => <button type="button" key={id} className={detail === id ? "is-selected" : ""} onClick={() => setDetail(id)} aria-pressed={detail === id}>{label}</button>)}
      </div>
      <p className="gift-crown__detail" aria-live="polite">{detail === "crown" ? "A three-dimensional metallic crown, rendered without a portrait or personal likeness." : detail === "jewels" ? "Eight faceted stones catch the light as the crown turns." : "A velvet plinth anchors the object in a quiet palace scene."}</p>
      {messageVisible && <blockquote className="gift-crown__message">{sourceNote}</blockquote>}
      <div className="gift-control-row">
        <button type="button" className="gift-control" onClick={() => setRotation((value) => value - 24)}>Rotate left</button>
        <button type="button" className="gift-control" onClick={() => setRotation((value) => value + 24)}>Rotate right</button>
        <button type="button" className="gift-control gift-control--primary" onClick={() => setMessageVisible((value) => !value)}>{messageVisible ? "Hide archive note" : "Reveal birthday note"}</button>
      </div>
    </div>
    </section>
  );
}

function OpenWhenExperience() {
  const [selected, setSelected] = useState(0);
  const [opened, setOpened] = useState(false);
  const current = openWhenLetters[selected];
  return (
    <section className="gift-open-when" aria-label="Open When letter collection">
      <GiftStage kind="cabinet" state={{ open: opened,selected }} onPick={i=>{setSelected(i);setOpened(false);}} label="The selected open-when letter, represented as a reversible three-dimensional folding envelope and paper." />
      <div className="gift-world-console">
      <div className="gift-open-when__envelopes">
        {openWhenLetters.map((letter, index) => <button type="button" key={letter.id} className={`gift-open-when__envelope${selected === index ? " is-selected" : ""}${opened && selected === index ? " is-broken" : ""}`} onClick={() => { setSelected(index); setOpened(false); }} aria-pressed={selected === index}>
          <span className="gift-open-when__seal">✦</span><strong>{letter.prompt}</strong><small>{opened && selected === index ? "SEAL OPENED" : "SELECT ENVELOPE"}</small>
        </button>)}
      </div>
      <article className={`gift-open-when__letter${opened ? " is-open" : ""}`} aria-live="polite">
        {opened ? <><small>OWNER-WRITTEN LETTER · {current.prompt.toUpperCase()}</small><p>{current.message || "This letter has not been written yet. Add an owner-authored message in src/content/giftsContent.ts."}</p></> : <><small>SEALED FOR A MOMENT</small><p>Select an envelope, then break its seal to open the note.</p></>}
      </article>
      <div className="gift-control-row"><button type="button" className="gift-control gift-control--primary" onClick={() => setOpened(true)}>{opened ? "Read the letter" : "Break the seal & open"}</button><button type="button" className="gift-control" onClick={() => setOpened(false)}>Close the letter</button></div>
    </div>
    </section>
  );
}

function HappinessMachineExperience() {
  const wishes = chronosContent.flowerGarden.wishes;
  const timerRef = useRef<number | null>(null);
  const [running, setRunning] = useState(false);
  const [messageIndex, setMessageIndex] = useState<number | null>(null);
  const [cycles, setCycles] = useState(0);
  useEffect(() => () => { if (timerRef.current !== null) window.clearTimeout(timerRef.current); }, []);
  const pullLever = () => {
    if (running) return;
    setRunning(true);
    const next = Math.floor(Math.random() * wishes.length);
    setMessageIndex(next);
    setCycles((value) => value + 1);
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => { setRunning(false); timerRef.current = null; }, 780);
  };
  return (
    <section className="gift-machine" aria-label="Happiness Machine experience">
      <GiftStage kind="machine" state={{open:running,selected:messageIndex,replay:cycles}} onPick={pullLever} label="An enamel and brass workshop machine with three meshing gears, a physical lever and advancing paper ticket. The controls reveal an existing source wish." />
      <div className="gift-world-console">
      {messageIndex!==null&&<blockquote className="gift-native-copy">{wishes[messageIndex]}</blockquote>}
      
      <p className="gift-machine__status" role="status">{messageIndex === null ? "The machine reveals only wishes already present in the source archive." : "A source-archive birthday wish has been selected."}</p>
      <div className="gift-control-row"><button type="button" className="gift-control gift-control--primary" onClick={pullLever} disabled={running}>Pull the lever</button><button type="button" className="gift-control" onClick={() => { setMessageIndex(null); setCycles(0); }}>Reset machine</button></div>
    </div>
    </section>
  );
}

function AdventureExperience() {
  const locations = chronosContent.future.items;
  const [unlocked, setUnlocked] = useState(0);
  const [selected, setSelected] = useState(0);
  const location = locations[selected];
  const visit = (index: number) => {
    if (index > unlocked) return;
    setSelected(index);
    setUnlocked((current) => Math.max(current, Math.min(locations.length - 1, index + 1)));
  };
  return (
    <section className="gift-adventure" aria-label="Little Adventure map">
      <GiftStage kind="adventure" state={{selected,growth:unlocked}} onPick={visit} label="An explicitly imagined miniature raised map, brass route, four physical flags and a small travelling marker. Existing postcard progression stays below." />
      <div className="gift-world-console">
      <p className="gift-adventure__warning">IMAGINATIVE MAP · NOT A REAL TRAVEL HISTORY</p>
      <div className="gift-adventure__map">
        <svg viewBox="0 0 100 44" preserveAspectRatio="none" aria-hidden="true"><path d="M4 34 C 18 5, 25 39, 42 22 S 68 6, 79 25 S 92 21, 98 8" /></svg>
        {locations.map((item, index) => <button type="button" key={item.id} className={`gift-adventure__location gift-adventure__location--${index + 1}${index === selected ? " is-selected" : ""}${index > unlocked ? " is-locked" : ""}`} onClick={() => visit(index)} disabled={index > unlocked} aria-current={index === selected ? "step" : undefined} aria-label={`${index > unlocked ? "Locked" : "Explore"}: ${item.place}`}><span>{index > unlocked ? "·" : String(index + 1).padStart(2, "0")}</span><small>{item.place}</small></button>)}
      </div>
      <article className="gift-adventure__postcard" aria-live="polite">
        <div className="gift-adventure__art">{location?.art && <img src={location.art} alt={location.alt} />}</div>
        <div><small>POSSIBLE FUTURE · NOT A FACT</small><h3>{location?.place}</h3><p>{location?.caption}</p><span>{location?.someday}</span></div>
      </article>
      <p className="gift-adventure__progress">{Math.min(unlocked + 1, locations.length)} / {locations.length} imagined locations available</p>
    </div>
    </section>
  );
}

function MusicExperience({ soundEnabled }: { soundEnabled: boolean }) {
  const tracks = chronosContent.music.tracks;
  const [selected, setSelected] = useState(0);
  const [silentPreview, setSilentPreview] = useState(false);
  const track = tracks[selected];
  const audio = useOptionalAudio(track?.src ?? "", soundEnabled);
  return (
    <section className="gift-vinyl" aria-label="The Music of Us experience">
      <GiftStage kind="vinyl" state={{playing:audio.playing,preview:silentPreview,open:true}} analyser={audio.analyser} label="A wooden turntable with grooved vinyl, spindle, moving tonearm and playback controls. Silent mechanical preview is not real music. Visualization follows real audio data only." />
      <div className="gift-world-console">
      
      <audio ref={audio.audioRef} src={track?.src || undefined} preload="none" muted={!soundEnabled} />
      <div className="gift-vinyl__track">
        <small>TRACK {String(selected + 1).padStart(2, "0")} / {tracks.length}</small>
        <strong>{track?.title}</strong><span>{track?.src ? track.note : chronosContent.music.emptyNote}</span>
        <div className="gift-vinyl__progress" aria-label="Track progress"><i style={{ width: `${audio.progress}%` }} /></div>
      </div>
      <div className="gift-vinyl__playlist" role="group" aria-label="Available local tracks">
        {tracks.map((item, index) => <button type="button" key={item.id} className={selected === index ? "is-selected" : ""} onClick={() => { audio.stop(); setSelected(index); }} aria-pressed={selected === index}><span>{String(index + 1).padStart(2, "0")}</span><strong>{item.title}</strong><small>{item.src ? "READY" : "NO AUDIO FILE"}</small></button>)}
      </div>
      <div className="gift-control-row">
        <button type="button" className="gift-control" onClick={() => { audio.stop(); setSelected((value) => (value + tracks.length - 1) % tracks.length); }}>Previous</button>
        <button type="button" className="gift-control gift-control--primary" disabled={!track?.src} onClick={() => audio.playing ? audio.pause() : void audio.play()}>{audio.playing ? "Pause" : "Play"}</button>
        <button type="button" className="gift-control" onClick={() => { audio.stop(); setSelected((value) => (value + 1) % tracks.length); }}>Next</button>
        <button type="button" className="gift-control" disabled={!track?.src} onClick={audio.stop}>Stop</button>
        <button type="button" className="gift-control" aria-pressed={silentPreview} onClick={() => setSilentPreview((value) => !value)}>{silentPreview ? "Stop silent preview" : "Preview turntable silently"}</button>
      </div>
      <label className="gift-volume">Volume <input type="range" min="0" max="1" step="0.01" value={audio.volume} disabled={!track?.src} onChange={(event) => audio.changeVolume(Number(event.target.value))} aria-label="Music volume" /></label>
      {audio.error && <p className="gift-audio-note" role="status">{audio.error}</p>}
      {!track?.src && <EmptyCopy>No autoplay. Add only a licensed or owner-provided local track in <code>chronosContent.ts</code>.</EmptyCopy>}
    </div>
    </section>
  );
}

function MirrorExperience() {
  const [cleared,setCleared]=useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointerDown = useRef(false);
  const redrawFog = useRef<() => void>(() => {});
  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    const drawFog = () => {
      setCleared(0);
      const bounds = canvas.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.round(bounds.width * ratio));
      canvas.height = Math.max(1, Math.round(bounds.height * ratio));
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      context.globalCompositeOperation = "source-over";
      const fog = context.createLinearGradient(0, 0, bounds.width, bounds.height);
      fog.addColorStop(0, "rgba(230,239,236,.95)");
      fog.addColorStop(0.5, "rgba(205,220,218,.93)");
      fog.addColorStop(1, "rgba(235,232,222,.95)");
      context.fillStyle = fog;
      context.fillRect(0, 0, bounds.width, bounds.height);
      context.fillStyle = "rgba(255,255,255,.28)";
      context.fillRect(0, 0, bounds.width, bounds.height * 0.12);
    };
    drawFog();
    redrawFog.current = drawFog;
    const resizeObserver = "ResizeObserver" in window ? new ResizeObserver(drawFog) : null;
    resizeObserver?.observe(canvas);
    return () => resizeObserver?.disconnect();
  }, []);
  const erase = (event: PointerEvent<HTMLCanvasElement>) => {
    const canvas = event.currentTarget;
    const context = canvas.getContext("2d");
    if (!context) return;
    const bounds = canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const x = (event.clientX - bounds.left);
    const y = (event.clientY - bounds.top);
    context.save();
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    context.globalCompositeOperation = "destination-out";
    context.beginPath();
    context.arc(x, y, 37, 0, Math.PI * 2);
    context.fill();
    context.restore();
    setCleared(v=>Math.min(1,v+.035));
  };
  const revealAll = () => {
    setCleared(1);
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (canvas && context) { context.save(); context.setTransform(1, 0, 0, 1, 0, 0); context.clearRect(0, 0, canvas.width, canvas.height); context.restore(); }
  };
  return (
    <section className="gift-mirror" aria-label="Infinite Mirror experience">
      <GiftStage kind="mirror" state={{growth:cleared}} label="A gold beaded standing mirror with an inset reflective surface. Wiping the accessible pad below clears its dimensional mist layer to reveal only the original abstract birthday line." />
      <div className="gift-world-console">
      <div className="gift-mirror__frame">
        <div className="gift-mirror__reflection" aria-hidden="true"><span>✿</span><strong>Happy Birthday, Bhumi.</strong><i>✦</i><small>AN ABSTRACT REFLECTION · NO PORTRAIT</small></div>
        <canvas ref={canvasRef} className="gift-mirror__fog" onPointerDown={(event) => { pointerDown.current = true; event.currentTarget.setPointerCapture(event.pointerId); erase(event); }} onPointerMove={(event) => { if (pointerDown.current) erase(event); }} onPointerUp={() => { pointerDown.current = false; }} onPointerCancel={() => { pointerDown.current = false; }} aria-hidden="true" />
      </div>
      <p className="gift-mirror__hint">Drag a finger or pointer across the glass, or use the reveal button.</p>
      <div className="gift-control-row"><button type="button" className="gift-control gift-control--primary" onClick={revealAll}>Clear the mist</button><button type="button" className="gift-control" onClick={() => redrawFog.current()} aria-label="Reset the mirror fog">Reset mirror</button></div>
      <EmptyCopy>The mirror reveals only abstract decoration and a birthday line; it does not use a fabricated portrait.</EmptyCopy>
    </div>
    </section>
  );
}

function CouponBookExperience() {
  const [page, setPage] = useState(0);
  const [redeemed, setRedeemed] = useState<string[]>([]);
  const coupon = couponEntries[page];
  const isFilled = Boolean(coupon.title.trim() && coupon.description.trim());
  const isRedeemed = redeemed.includes(coupon.id);
  const markRedeemed = () => setRedeemed((current) => isFilled && !current.includes(coupon.id) ? [...current, coupon.id] : current);
  const restore = () => setRedeemed((current) => current.filter((id) => id !== coupon.id));
  return (
    <section className="gift-coupon" aria-label="Birthday coupon book experience">
      <GiftStage kind="coupons" state={{selected:page,open:isRedeemed}} label="A thick bound coupon booklet with brass binding rings, stacked paper, perforations and a continuously bent turning page. Empty offers remain unredeemable." />
      <div className="gift-world-console">
      <div className="gift-coupon__book">
        <div className="gift-coupon__spine"><i /><i /><i /></div>
        <article className={`gift-coupon__page${isRedeemed ? " is-redeemed" : ""}`}>
          <small>COUPON {String(page + 1).padStart(2, "0")} / {couponEntries.length}</small>
          {isFilled ? <><h3>{coupon.title}</h3><p>{coupon.description}</p></> : <><span className="gift-coupon__stamp">OWNER-APPROVED OFFER</span><h3>A coupon to write</h3><p>This coupon is intentionally unfilled. Add only an offer Rudra has approved in <code>giftsContent.ts</code>.</p></>}
          <b>{isRedeemed ? "REDEEMED" : "NOT YET REDEEMABLE"}</b>
        </article>
      </div>
      <p className="gift-coupon__status" role="status">{isFilled ? (isRedeemed ? "This owner-approved coupon is marked redeemed." : "This coupon is ready to read.") : "Empty coupon slots are not redeemable; no promise has been invented."}</p>
      <div className="gift-control-row">
        <button type="button" className="gift-control" onClick={() => setPage((value) => (value + couponEntries.length - 1) % couponEntries.length)} aria-label="Previous coupon page">Previous page</button>
        <button type="button" className="gift-control" onClick={() => setPage((value) => (value + 1) % couponEntries.length)} aria-label="Next coupon page">Next page</button>
        <button type="button" className="gift-control gift-control--primary" onClick={markRedeemed} disabled={!isFilled || isRedeemed}>Mark redeemed</button>
        <button type="button" className="gift-control" onClick={restore} disabled={!isRedeemed}>Restore coupon</button>
      </div>
    </div>
    </section>
  );
}

function FutureGardenExperience() {
  const [growth, setGrowth] = useState(0);
  const [activeLeaf,setActiveLeaf]=useState<number|null>(null);
  const leaves = futureGardenLeaves.slice(0, growth);
  return (
    <section className="gift-future-garden" aria-label="Future Garden experience">
      <GiftStage kind="hope-tree" state={{growth,selected:activeLeaf}} onPick={i=>{if(i<growth)setActiveLeaf(i);}} label="A sculpted soil cross-section with a large embedded seed, roots, growing curved trunk, eight individually unfurling leaves, instanced grass and a butterfly. Blank hopes remain below." />
      <div className="gift-world-console">
      <p className="gift-future-garden__caption" role="status">{growth === 0 ? "A seed, with room to grow." : `${growth} of ${futureGardenLeaves.length} hope leaves opened.`}</p>
      {activeLeaf!==null&&<p className="gift-native-copy">Hope {activeLeaf+1}: {futureGardenLeaves[activeLeaf].text || "Waiting for an owner-written hope."}</p>}
      {leaves.length > 0 && <div className="gift-note-picker" role="group" aria-label="Inspect hope leaves">{leaves.map((leaf,i)=><button type="button" key={leaf.id} onClick={()=>setActiveLeaf(i)} aria-pressed={activeLeaf===i}>Leaf {i+1}</button>)}</div>}
      {leaves.length > 0 && <ul className="gift-future-garden__hopes">{leaves.map((leaf) => <li key={leaf.id}>{leaf.text || "A future hope to be written by the owner."}</li>)}</ul>}
      <div className="gift-control-row"><button type="button" className="gift-control gift-control--primary" disabled={growth >= futureGardenLeaves.length} onClick={() => setGrowth((value) => Math.min(futureGardenLeaves.length, value + 1))}>{growth === 0 ? "Plant the seed" : growth >= futureGardenLeaves.length ? "Garden complete" : "Grow another leaf"}</button><button type="button" className="gift-control" onClick={() => setGrowth(0)}>Begin again</button></div>
      <EmptyCopy>All eight future-hope fields are blank. Add only hopes the owner chooses to write; no future is stated as fact or promise.</EmptyCopy>
    </div>
    </section>
  );
}

function TreasureHuntExperience() {
  const [order, setOrder] = useState<string[]>([...treasureHuntPuzzle.initialOrder]);
  const [selected, setSelected] = useState<string | null>(null);
  const [gateOpen, setGateOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [won, setWon] = useState(false);
  const isOrdered = order.join("|") === treasureHuntPuzzle.solution.join("|");
  const move = (direction: number) => {
    if (!selected) return;
    const index = order.indexOf(selected);
    const nextIndex = index + direction;
    if (index < 0 || nextIndex < 0 || nextIndex >= order.length) return;
    setOrder((current) => { const copy = [...current]; [copy[index], copy[nextIndex]] = [copy[nextIndex], copy[index]]; return copy; });
  };
  const swapDragged = (event: DragEvent<HTMLElement>, target: string) => {
    event.preventDefault();
    const source = event.dataTransfer.getData("text/plain");
    if (!source || source === target) return;
    setOrder((current) => { const copy = [...current]; const from = copy.indexOf(source); const to = copy.indexOf(target); [copy[from], copy[to]] = [copy[to], copy[from]]; return copy; });
  };
  const unlock = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password.trim().toUpperCase() === treasureHuntPuzzle.password) { setWon(true); setMessage("The chest opens."); }
    else setMessage("That word does not open the gate yet. Use the clue above.");
  };
  return (
    <section className="gift-treasure" aria-label="Secret Treasure Hunt">
      <GiftStage kind="treasure" state={{open:won,selected:selected?order.indexOf(selected):null,growth:gateOpen?1:0}} onPick={i=>setSelected(order[i])} label="A wood and brass treasure chest with a hinged lid, key, lock and three physical medallions. Solve the existing symbol and password puzzle to open it." />
      <div className="gift-world-console">
      {!gateOpen ? <>
        <div className="gift-treasure__clue"><small>CLUE 01 · SYMBOL ORDER</small><p>{treasureHuntPuzzle.clue}</p></div>
        <ol className="gift-treasure__pieces" aria-label="Arrange the symbols in the order given in the clue">
          {order.map((symbol, index) => <li key={symbol} onDragOver={(event) => event.preventDefault()} onDrop={(event) => swapDragged(event, symbol)}>
            <button type="button" className={`gift-treasure__piece is-${symbol}${selected === symbol ? " is-selected" : ""}`} draggable onDragStart={(event) => event.dataTransfer.setData("text/plain", symbol)} onClick={() => setSelected(symbol)} aria-label={`Symbol ${symbol}, position ${index + 1}; select to move`} aria-pressed={selected === symbol}><span>{symbol === "flower" ? "✿" : symbol === "moon" ? "☾" : "✦"}</span><small>{symbol}</small></button>
          </li>)}
        </ol>
        <div className="gift-control-row"><button type="button" className="gift-control" onClick={() => move(-1)} disabled={!selected || order.indexOf(selected) === 0}>Move selected left</button><button type="button" className="gift-control" onClick={() => move(1)} disabled={!selected || order.indexOf(selected) === order.length - 1}>Move selected right</button><button type="button" className="gift-control gift-control--primary" onClick={() => { if (isOrdered) { setGateOpen(true); setMessage(""); } else setMessage("Not quite. Use the stated flower → moon → star sequence."); }}>Check the order</button></div>
        <p className="gift-treasure__access-note">Drag a symbol, or select it and use the Move left/right buttons.</p>
      </> : !won ? <>
        <div className="gift-treasure__chest" aria-hidden="true"><span>✦</span><i /></div>
        <form className="gift-treasure__password" onSubmit={unlock}>
          <label htmlFor="gift-treasure-password">The chest asks for a word</label>
          <p>{treasureHuntPuzzle.passwordHint}</p>
          <input id="gift-treasure-password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="off" />
          <button className="gift-control gift-control--primary" type="submit">Unlock the chest</button>
        </form>
      </> : <div className="gift-treasure__reward" role="status"><span>✦ TREASURE FOUND ✦</span><p>{chronosContent.gifts.specials["01"].message}</p><small>Source archive message</small></div>}
      {message && <p className="gift-treasure__status" role="status">{message}</p>}
      <div className="gift-control-row"><button type="button" className="gift-control" onClick={() => { setOrder([...treasureHuntPuzzle.initialOrder]); setSelected(null); setGateOpen(false); setPassword(""); setMessage(""); setWon(false); }}>Restart the hunt</button></div>
    </div>
    </section>
  );
}

function UltimateSurpriseExperience({ onReturn }: { onReturn: () => void }) {
  const [stage, setStage] = useState<"dark" | "gathered" | "portal">("dark");
  const [soundEnabled, setSoundEnabled] = useState(false);
  return (
    <section className={`gift-ultimate gift-ultimate--${stage}`} aria-label="The Ultimate Surprise experience">
      <GiftStage kind="portal" state={{ open: stage === "portal", growth: stage === "dark" ? 0 : stage === "gathered" ? 1 : 2 }} label="Three metallic portal rings around a procedural swirling light surface, set in a three-dimensional starfield." />
      <div className="gift-world-console">
      <div className="gift-ultimate__copy" aria-live="polite">
        <small>GIFT 17 · THE GRAND FINALE</small>
        {stage === "dark" ? <><h3>Sixteen lights are waiting.</h3><p>Opening this gift does not require opening any of the others.</p><button type="button" className="gift-control gift-control--primary" onClick={() => setStage("gathered")}>Gather the sixteen lights</button></> : stage === "gathered" ? <><h3>The lights have found one another.</h3><p>A portal is ready to open.</p><button type="button" className="gift-control gift-control--primary" onClick={() => setStage("portal")}>Open the portal</button></> : <><h3>Happy Birthday, Bhumi.</h3><p>{chronosContent.finale.sourceMessage}</p><button type="button" className="gift-control gift-control--primary" onClick={() => { onReturn(); document.getElementById("birthday-cake")?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" }); }}>Enter the Birthday Ballroom</button><button type="button" className="gift-control" onClick={() => setStage("dark")}>Replay the finale</button></>}
      </div>
      <div className="gift-control-row">
        <button type="button" className="gift-control" aria-pressed={soundEnabled} onClick={() => setSoundEnabled((value) => !value)}>{soundEnabled ? "Sound permission: on" : "Sound permission: off"}</button>
        <button type="button" className="gift-control" onClick={() => setStage("dark")}>Replay journey</button>
        <button type="button" className="gift-control" onClick={onReturn}>Return to Gift Atelier</button>
      </div>
      <p className="gift-ultimate__audio-note">No sound asset is installed; this preference never starts audio. Add licensed or owner-provided sound to enable playback.</p>
    </div>
    </section>
  );
}

const experienceLabels: Record<GiftDefinition["experience"], string> = {
  "secret-letter": "Replay letter opening",
  "reason-jar": "Reset the jar",
  "eternal-flower": "Replay the bloom",
  "little-universe": "Reset the universe",
  "bhumi-fm": "Reset the cassette",
  "memory-cinema": "Reset the cinema",
  wishes: "Reset the constellation",
  "royal-crown": "Reset the crown",
  "open-when": "Reset the envelopes",
  "happiness-machine": "Reset the machine",
  "little-adventure": "Reset the map",
  "music-of-us": "Reset the record player",
  "infinite-mirror": "Reset the mirror",
  "coupon-book": "Reset the coupon book",
  "future-garden": "Reset the garden",
  "treasure-hunt": "Restart the hunt",
  "ultimate-surprise": "Replay the finale",
};

export function GiftExperience({ gift, onReturn, soundEnabled }: GiftExperienceProps) {
  const [replayKey, setReplayKey] = useState(0);
  const replay = () => setReplayKey((value) => value + 1);
  let experience;
  switch (gift.experience) {
    case "secret-letter": experience = <SecretLetterExperience />; break;
    case "reason-jar": experience = <ReasonJarExperience />; break;
    case "eternal-flower": experience = <EternalFlowerExperience />; break;
    case "little-universe": experience = <LittleUniverseExperience />; break;
    case "bhumi-fm": experience = <CassetteExperience soundEnabled={soundEnabled} />; break;
    case "memory-cinema": experience = <MemoryCinemaExperience />; break;
    case "wishes": experience = <WishesExperience />; break;
    case "royal-crown": experience = <CrownExperience />; break;
    case "open-when": experience = <OpenWhenExperience />; break;
    case "happiness-machine": experience = <HappinessMachineExperience />; break;
    case "little-adventure": experience = <AdventureExperience />; break;
    case "music-of-us": experience = <MusicExperience soundEnabled={soundEnabled} />; break;
    case "infinite-mirror": experience = <MirrorExperience />; break;
    case "coupon-book": experience = <CouponBookExperience />; break;
    case "future-garden": experience = <FutureGardenExperience />; break;
    case "treasure-hunt": experience = <TreasureHuntExperience />; break;
    case "ultimate-surprise": experience = <UltimateSurpriseExperience onReturn={onReturn} />; break;
    default: experience = <EmptyCopy>Experience is not configured.</EmptyCopy>;
  }
  return (
    <div className="gift-experience-shell">
      <p className="gift-experience-shell__intro">{gift.subtitle}</p>
      <div className="gift-experience" data-experience={gift.experience} key={`${gift.id}-${replayKey}`}>
        {experience}
      </div>
      {gift.experience !== "ultimate-surprise" && <div className="gift-experience-shell__footer"><ExperienceReplay onReplay={replay} label={experienceLabels[gift.experience]} /><span>Each gift opens independently and can be replayed.</span></div>}
    </div>
  );
}
