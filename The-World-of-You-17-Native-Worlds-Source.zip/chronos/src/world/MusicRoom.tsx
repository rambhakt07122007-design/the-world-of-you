import { useEffect, useRef, useState } from "react";
import { Disc3, Headphones, Pause, Play, SkipBack, SkipForward, Volume2, VolumeX } from "lucide-react";
import { chronosContent } from "../content/chronosContent";
import { WorldSection } from "./WorldSection";

interface MusicRoomProps { soundEnabled: boolean; onToggleSound: () => void; }

const clock = (seconds: number) => {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
};

export function MusicRoom({ soundEnabled, onToggleSound }: MusicRoomProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [trackIndex, setTrackIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.65);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [status, setStatus] = useState<string>(chronosContent.music.emptyNote);
  const track = chronosContent.music.tracks[trackIndex];
  const hasAudio = Boolean(track.src);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = volume;
    audio.muted = !soundEnabled;
    if (!soundEnabled && !audio.paused) {
      audio.pause();
      setPlaying(false);
      setStatus("Sound was turned off. Playback is paused.");
    }
  }, [volume, soundEnabled]);

  useEffect(() => {
    setPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    if (!track.src) setStatus(chronosContent.music.emptyNote);
    else setStatus(track.note);
    audioRef.current?.pause();
    if (audioRef.current) audioRef.current.currentTime = 0;
  }, [trackIndex, track.src, track.note]);

  const setTrack = (index: number) => setTrackIndex((index + chronosContent.music.tracks.length) % chronosContent.music.tracks.length);
  const togglePlayback = async () => {
    const audio = audioRef.current;
    if (!audio || !hasAudio) {
      setStatus("No audio file supplied. Add an owner-provided local file to this track.");
      return;
    }
    if (!soundEnabled) {
      setStatus("Sound is opt-in. Choose “Sound on” in the top bar, then press play.");
      return;
    }
    if (audio.paused) {
      try { await audio.play(); setPlaying(true); setStatus(`Now playing · ${track.title}`); }
      catch { setPlaying(false); setStatus("This local audio file could not be played. Check the file path and format."); }
    } else {
      audio.pause();
      setPlaying(false);
      setStatus("Playback paused.");
    }
  };

  const seek = (value: number) => {
    if (audioRef.current && Number.isFinite(audioRef.current.duration)) audioRef.current.currentTime = value;
    setCurrentTime(value);
  };

  const onTrackEnded = () => {
    setPlaying(false);
    if (trackIndex < chronosContent.music.tracks.length - 1) {
      setTrackIndex((index) => index + 1);
    } else setStatus("End of the selected listening set.");
  };

  return (
    <WorldSection id="music-room" className="music-room-section" eyebrow="A QUIET LISTENING ROOM" sideNote="SOUND / 09">
      <p className="music-room__intro">{chronosContent.music.note}</p>
      <div className="music-console">
        <div className="music-console__head"><div><span className="music-console__live"><i /> LOCAL PLAYER · OPT-IN</span><h3>{chronosContent.music.station}</h3><p>For the songs and voices you choose to bring.</p></div><Headphones size={33} strokeWidth={0.8} aria-hidden="true" /></div>
        <div className="music-console__body">
          <div className="vinyl-player" aria-label={playing ? "Vinyl record spinning" : "Vinyl record still"}>
            <div className={`vinyl-disc${playing ? " is-spinning" : ""}`}><span className="vinyl-disc__grooves" /><span className="vinyl-disc__label"><Disc3 size={25} strokeWidth={0.8} /><small>{trackIndex + 1}</small></span></div>
            <span className="vinyl-arm" aria-hidden="true"><i /></span>
            <span className="vinyl-player__flower" aria-hidden="true">✿</span>
          </div>
          <div className="music-track-panel">
            <div className="music-now-playing"><span>NOW SELECTED</span><strong>{track.title}</strong><small>{track.note}</small></div>
            <div className="music-timeline"><span>{clock(currentTime)}</span><input type="range" min={0} max={Math.max(duration, 1)} value={Math.min(currentTime, duration || 1)} onChange={(event) => seek(Number(event.target.value))} aria-label="Seek within track" disabled={!hasAudio || !soundEnabled} style={{ "--range-progress": `${duration ? (currentTime / duration) * 100 : 0}%` } as React.CSSProperties} /><span>{clock(duration)}</span></div>
            <div className="music-controls">
              <button type="button" className="music-controls__step" onClick={() => setTrack(trackIndex - 1)} aria-label="Previous track"><SkipBack size={18} fill="currentColor" /></button>
              <button type="button" className="music-controls__play" onClick={togglePlayback} disabled={!hasAudio} aria-label={playing ? "Pause track" : "Play selected track"}>{playing ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}</button>
              <button type="button" className="music-controls__step" onClick={() => setTrack(trackIndex + 1)} aria-label="Next track"><SkipForward size={18} fill="currentColor" /></button>
              <div className="music-volume"><button type="button" onClick={onToggleSound} aria-label={soundEnabled ? "Turn sound off" : "Turn sound on"} title={soundEnabled ? "Turn sound off" : "Turn sound on to hear a track"}>{soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}</button><input type="range" min={0} max={1} step={0.05} value={volume} onChange={(event) => setVolume(Number(event.target.value))} aria-label="Player volume" /></div>
            </div>
            <div className="music-status" role="status" aria-live="polite"><i />{status}</div>
            <audio ref={audioRef} src={track.src || undefined} preload="none" muted={!soundEnabled} onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime)} onDurationChange={(event) => setDuration(Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : 0)} onEnded={onTrackEnded} onError={() => hasAudio && setStatus("Audio could not be loaded. Check the owner-supplied local file.")} />
          </div>
        </div>
        <div className="music-track-list" aria-label="Available local audio tracks">
          {chronosContent.music.tracks.map((item, index) => <button key={item.id} type="button" className={trackIndex === index ? "is-active" : ""} onClick={() => setTrack(index)} aria-current={trackIndex === index ? "true" : undefined}><span className="music-track-list__number">0{index + 1}</span><span><strong>{item.title}</strong><small>{item.src ? "LOCAL FILE READY" : "EMPTY · ADD LOCAL FILE"}</small></span><i aria-hidden="true">{trackIndex === index ? "✿" : "＋"}</i></button>)}
        </div>
      </div>
      <p className="music-room__privacy"><VolumeX size={14} /> Audio starts paused. No autoplay, external stream, microphone request or recording.</p>
    </WorldSection>
  );
}
