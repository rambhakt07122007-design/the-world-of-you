import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Sparkles } from "lucide-react";
import { chronosContent } from "../content/chronosContent";

interface OpeningInvitationProps {
  onEnter: () => void;
  onSkip: () => void;
}

const flecks = Array.from({ length: 24 }, (_, index) => ({
  id: index,
  left: `${(index * 37 + 7) % 97}%`,
  top: `${(index * 53 + 13) % 88}%`,
  delay: `${(index % 9) * 160}ms`,
  size: `${3 + (index % 3)}px`,
}));

export function OpeningInvitation({ onEnter, onSkip }: OpeningInvitationProps) {
  const [opening, setOpening] = useState(false);
  const [opened, setOpened] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => () => {
    if (timer.current !== null) window.clearTimeout(timer.current);
  }, []);

  const openWorld = () => {
    if (opening) return;
    if (opened) {
      onEnter();
      return;
    }
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setOpened(true);
      onEnter();
      return;
    }
    setOpening(true);
    timer.current = window.setTimeout(() => {
      timer.current = null;
      setOpening(false);
      setOpened(true);
      onEnter();
    }, 1420);
  };

  const skipOpening = () => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = null;
    setOpening(false);
    onSkip();
  };

  return (
    <section id="invitation" data-chapter="invitation" data-scene-anchor="invitation" className="invitation-screen" aria-labelledby="invitation-title">
      <div className="invitation-screen__wash" aria-hidden="true" />
      <div className="invitation-screen__dust" aria-hidden="true">
        {flecks.map((fleck) => <i key={fleck.id} style={{ left: fleck.left, top: fleck.top, animationDelay: fleck.delay, width: fleck.size, height: fleck.size }} />)}
      </div>
      <div className="invitation-screen__brand"><span className="world-flower-seal" aria-hidden="true"><Sparkles size={17} /></span><span>{chronosContent.meta.brand}</span></div>
      <div className="invitation-card invitation-card--gift">
        <span className="invitation-card__corner invitation-card__corner--tl" aria-hidden="true" />
        <span className="invitation-card__corner invitation-card__corner--tr" aria-hidden="true" />
        <span className="invitation-card__corner invitation-card__corner--bl" aria-hidden="true" />
        <span className="invitation-card__corner invitation-card__corner--br" aria-hidden="true" />
        <p className="invitation-card__kicker">{chronosContent.opening.kicker}</p>
        <h1 id="invitation-title">{chronosContent.opening.line}</h1>
        <p className="invitation-card__byline">A birthday storybook for <span>Bhumi</span></p>

        <div className="invitation-envelope-stage">
          <img className="invitation-stage__still" src="/assets/birthday/invitation-envelope.webp" alt="" width={928} height={1152} fetchPriority="high" />
          <div className="invitation-screen__dust invitation-envelope__glimmers" aria-hidden="true">
            {flecks.slice(0, 12).map((fleck) => <i key={fleck.id} style={{ left: fleck.left, top: fleck.top, animationDelay: fleck.delay }} />)}
          </div>
          <button
            className={`invitation-envelope${opening ? " is-opening" : ""}${opened ? " is-open" : ""}`}
            type="button"
            onClick={openWorld}
            disabled={opening}
            aria-label={opening ? "Opening the birthday invitation" : opened ? "Continue into the birthday garden" : "Open the sealed birthday invitation"}
          >
            <span className="invitation-envelope__letter" aria-hidden="true">
              <span>For Bhumi</span>
              <small>with love, Rudra</small>
            </span>
            <span className="invitation-envelope__back" aria-hidden="true" />
            <span className="invitation-envelope__front invitation-envelope__front--left" aria-hidden="true" />
            <span className="invitation-envelope__front invitation-envelope__front--right" aria-hidden="true" />
            <span className="invitation-envelope__front invitation-envelope__front--bottom" aria-hidden="true" />
            <span className="invitation-envelope__flap" aria-hidden="true" />
            <span className="invitation-envelope__seal" aria-hidden="true"><i>✿</i><b /><em /></span>
            <span className="invitation-envelope__shine" aria-hidden="true" />
          </button>
          <span className="invitation-envelope-stage__note" aria-hidden="true">a little something for you</span>
        </div>

        <p className="invitation-card__hint">A birthday garden, a few saved pages, and surprises held for you.</p>
        <button className="invitation-open" type="button" onClick={openWorld} disabled={opening}>
          <span>{opening ? "Your little world is opening…" : opened ? "Continue into the garden" : chronosContent.opening.button}</span>
          <ArrowUpRight size={16} aria-hidden="true" />
        </button>
        <button className="invitation-skip" type="button" onClick={skipOpening}>Skip the opening animation</button>
        <p className="invitation-card__date">17 NOVEMBER · YEAR NOT SPECIFIED</p>
      </div>
      <div className="invitation-screen__footer"><span>AN INVITATION TO A SMALL WORLD</span><span>NO SOUND UNTIL YOU CHOOSE IT</span></div>
    </section>
  );
}
