import { useState } from "react";
import { ArrowUpRight, Compass, Sparkles } from "lucide-react";
import { ArchiveDialog } from "../components/ArchiveDialog";
import { chronosContent } from "../content/chronosContent";
import { SceneCanvas } from "../three/SceneCanvas";
import { WorldSection } from "./WorldSection";

type Postcard = (typeof chronosContent.future.items)[number];

export function FuturePostcards() {
  const [selected, setSelected] = useState<Postcard | null>(null);
  const [flipped, setFlipped] = useState(false);
  const choose = (card: Postcard) => { setFlipped(false); setSelected(card); };
  const navigate = (direction: number) => { const cards = chronosContent.future.items; choose(cards[(cards.findIndex(card => card.id === selected?.id) + direction + cards.length) % cards.length]); };
  return (
    <WorldSection id="future-postcards" className="postcards-section" eyebrow="A DRAWING OF POSSIBLE DAYS" sideNote="SOMEDAY / 11">
      <p className="postcards-intro">{chronosContent.future.intro}</p>
      <div className="postcards-warning"><Sparkles size={16} /><span>{chronosContent.future.tag}</span><i /></div>
      <div className="postcard-grid">
        {chronosContent.future.items.map((postcard, index) => <button key={postcard.id} type="button" className={`postcard postcard--${postcard.scene}`} onClick={() => choose(postcard)} aria-label={`Open speculative postcard: ${postcard.place}`}>
          <span className="postcard__scene">
            <img src={postcard.art} alt={postcard.alt} loading="lazy" width={1376} height={768} />
            <span className="postcard__scene-vignette" aria-hidden="true" />
            <span className="postcard__stamp">IMAGINED · {String(index + 1).padStart(2, "0")}</span>
            <span className="postcard__seal" aria-hidden="true"><Compass size={15} /></span>
          </span>
          <span className="postcard__text"><small>{postcard.someday}</small><strong>{postcard.place}</strong><span>{postcard.caption}</span><i><span>OPEN POSTCARD</span><ArrowUpRight size={13} /></i></span>
        </button>)}
      </div>
      <p className="postcards-footnote">These cards depict no real trips or shared memories. They are editable possibilities only; remove any that do not reflect a real, mutual hope.</p>
      <ArchiveDialog open={selected !== null} onClose={() => setSelected(null)} eyebrow={chronosContent.future.tag} title={selected?.place ?? "A possible day"}>
        {selected && <div className={`postcard-reading postcard-reading--${selected.scene}`}>
          <SceneCanvas kind="postcard" state={{open:flipped,artwork:selected.art,detail:[selected.place,selected.someday,selected.caption,"Speculative illustration — not a fact, memory, or promise."].join("\n")}} onPick={() => setFlipped(v => !v)} label="A thick three-dimensional postcard showing the original illustration on its front and the existing imagined-future message on its reverse. Flip with the accessible button below." />
          <div className="cinematic-controls"><button type="button" onClick={() => navigate(-1)}>Previous postcard</button><button type="button" aria-pressed={flipped} onClick={() => setFlipped(v => !v)}>{flipped ? "Show illustration" : "Read reverse"}</button><button type="button" onClick={() => navigate(1)}>Next postcard</button></div>
          <img src={selected.art} alt={selected.alt} width={1376} height={768} />
          <p className="postcard-reading__when">{selected.someday}</p>
          <p>{selected.caption}</p>
          <small>Speculative illustration · not a fact, memory, or promise.</small>
        </div>}
      </ArchiveDialog>
    </WorldSection>
  );
}
