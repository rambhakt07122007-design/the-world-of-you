import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Menu, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import { chronosContent } from "../content/chronosContent";

interface WorldNavProps {
  activeSection: string;
  soundOn: boolean;
  onToggleSound: () => void;
  onReplayInvitation: () => void;
}

const quick = ["garden", "storybook", "timepiece", "letters", "gifts", "finale"];

export function WorldNav({ activeSection, soundOn, onToggleSound, onReplayInvitation }: WorldNavProps) {
  const [open, setOpen] = useState(false);
  const indexButton = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        indexButton.current?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  const close = () => setOpen(false);
  const currentChapter = chronosContent.sections.find((section) => section.id === activeSection);
  const brandCaption = activeSection === "invitation"
    ? "A BIRTHDAY STORYBOOK"
    : `${currentChapter?.number ?? ""} · ${currentChapter?.nav.toUpperCase() ?? "CHAPTER"}`;
  const getName = (id: string) => chronosContent.sections.find((section) => section.id === id)?.nav ?? id;

  return (
    <>
      <header className="world-nav">
        <a href="#garden" className="world-nav__brand" onClick={close} aria-label="The World of You, return to the garden">
          <span className="world-flower-seal" aria-hidden="true"><Sparkles size={15} /></span>
          <span><strong>THE WORLD OF YOU</strong><small title={brandCaption}>{brandCaption}</small></span>
        </a>
        <nav className="world-nav__quick" aria-label="Primary navigation">
          {quick.map((id) => <a key={id} href={`#${id}`} className={activeSection === id ? "is-active" : ""} aria-current={activeSection === id ? "location" : undefined}>{getName(id)}</a>)}
        </nav>
        <div className="world-nav__tools">
          <button className={`world-sound${soundOn ? " is-on" : ""}`} type="button" onClick={onToggleSound} aria-pressed={soundOn} aria-label={soundOn ? "Turn sound off" : "Turn sound on"} title={soundOn ? "Sound on" : "Sound off"}>
            {soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}<span>{soundOn ? "Sound on" : "Sound off"}</span>
          </button>
          <button ref={indexButton} className={`world-index-toggle${open ? " is-open" : ""}`} type="button" aria-label={open ? "Close chapter index" : "Open chapter index"} aria-expanded={open} aria-controls="world-index" onClick={() => setOpen((current) => !current)}>
            <span>Chapters</span>{open ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </header>
      <div id="world-index" className={`world-index${open ? " is-open" : ""}`} aria-hidden={!open}>
        <div className="world-index__top"><span>THE LITTLE WORLD</span><span>{chronosContent.sections.length} CHAPTERS</span></div>
        <nav aria-label="All birthday chapters">
            {chronosContent.sections.map((section) => section.id === "invitation" ? (
            <button key={section.id} type="button" className={`world-index__invitation${activeSection === section.id ? " is-active" : ""}`} aria-current={activeSection === section.id ? "location" : undefined} onClick={() => { close(); onReplayInvitation(); }} tabIndex={open ? 0 : -1}>
              <span>{section.number}</span><span>{section.nav}</span><ArrowUpRight size={14} aria-hidden="true" />
            </button>
          ) : (
            <a key={section.id} href={`#${section.id}`} className={activeSection === section.id ? "is-active" : ""} aria-current={activeSection === section.id ? "location" : undefined} onClick={close} tabIndex={open ? 0 : -1}>
              <span>{section.number}</span><span>{section.nav}</span><ArrowUpRight size={14} aria-hidden="true" />
            </a>
          ))}
        </nav>
        <p>Choose a page. The rest will wait.</p>
      </div>
      {open && <button className="world-index-scrim" aria-label="Close chapter index" type="button" onClick={close} />}
    </>
  );
}
