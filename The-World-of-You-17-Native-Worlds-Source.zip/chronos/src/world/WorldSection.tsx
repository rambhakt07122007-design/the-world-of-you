import type { ReactNode } from "react";
import { chronosContent, type WorldSectionId } from "../content/chronosContent";

interface WorldSectionProps {
  id: WorldSectionId;
  eyebrow?: string;
  children: ReactNode;
  className?: string;
  sideNote?: string;
}

export function WorldSection({ id, eyebrow, children, className = "", sideNote }: WorldSectionProps) {
  const meta = chronosContent.sections.find((section) => section.id === id)!;
  return (
    <section
      id={id}
      data-chapter={id}
      data-scene-anchor={id}
      className={`world-section world-section--${id} ${className}`.trim()}
      aria-labelledby={`${id}-title`}
    >
      <div className="world-section__paper-grain" aria-hidden="true" />
      <div className="world-section__topline" aria-hidden="true">
        <span>{meta.number} · 12</span><i /><span>THE WORLD OF YOU</span>
        {sideNote && <span className="world-section__topnote">{sideNote}</span>}
      </div>
      <div className="world-section__inner">
        <header className="world-section__heading">
          <span className="world-section__medallion" aria-hidden="true"><i /></span>
          <div>
            <p className="world-eyebrow">{eyebrow ?? meta.nav}</p>
            <h2 id={`${id}-title`}>{meta.title}</h2>
            <p className="world-section__summary">{meta.summary}</p>
          </div>
          <span className="world-section__number" aria-hidden="true">{meta.number}</span>
        </header>
        {children}
      </div>
    </section>
  );
}
