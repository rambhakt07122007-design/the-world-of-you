import { useMemo, useState } from "react";
import { Flower2, RotateCcw, X } from "lucide-react";
import { chronosContent } from "../content/chronosContent";
import { WorldSection } from "./WorldSection";
import { SceneCanvas } from "../three/SceneCanvas";

export function FlowerGarden() {
  const [activeWish, setActiveWish] = useState<number | null>(null);
  const [replay, setReplay] = useState(0);
  const [draft, setDraft] = useState("");
  const [ownWish, setOwnWish] = useState("");
  const state = useMemo(() => ({ selected: activeWish, replay, planted: Boolean(ownWish) }), [activeWish, replay, ownWish]);
  const releaseWish = (index: number) => { setActiveWish(index); setReplay((value) => value + 1); };
  return <WorldSection id="flower-garden" className="wish-garden-section" eyebrow="THE LIVING CONSERVATORY" sideNote="BLOOM / 07">
    <div className="conservatory-heading"><div><span className="micro-label">TEN WISHES, ROOTED IN LIGHT</span><h3>A garden that opens<br /><em>one petal at a time.</em></h3></div><p>{chronosContent.flowerGarden.intro}<br /><small>Select a flower in the scene, or use its numbered button below.</small></p></div>
    <SceneCanvas kind="garden" state={state} onPick={releaseWish} label="Interactive 3D conservatory: curved rose, daisy and tulip petals, grass, trees and butterflies. Equivalent wish controls follow." />
    <div className="conservatory-panel"><div className="conservatory-selection" role="group" aria-label="Select a birthday wish">
      {chronosContent.flowerGarden.wishes.map((_, index) => <button type="button" key={index} onClick={() => releaseWish(index)} aria-pressed={activeWish === index} aria-label={`Release wish ${index + 1}`}><Flower2 size={17} /><span>{String(index + 1).padStart(2, "0")}</span><small>{["Rose", "Daisy", "Tulip"][index % 3]}</small></button>)}
      {ownWish && <button type="button" onClick={() => releaseWish(10)} aria-pressed={activeWish === 10}>My wish</button>}
    </div>
    <article className="conservatory-wish" aria-live="polite" aria-atomic="true"><span className="micro-label">{activeWish === null ? "A QUIET PLACE TO BEGIN" : activeWish === 10 ? "YOUR NEWLY PLANTED WISH" : `WISH ${String(activeWish + 1).padStart(2, "0")}`}</span><p>{activeWish === null ? "Choose a bloom. Let it unfold." : activeWish === 10 ? ownWish : chronosContent.flowerGarden.wishes[activeWish]}</p>{activeWish !== null && <div className="cinematic-controls"><button type="button" onClick={() => setReplay((value) => value + 1)}><RotateCcw size={14} /> Replay bloom</button><button type="button" onClick={() => setActiveWish(null)}><X size={14} /> Close wish</button></div>}</article></div>
    <form className="wish-plant-form" onSubmit={(event) => { event.preventDefault(); if (!draft.trim()) return; setOwnWish(draft.trim()); setActiveWish(10); setReplay((v) => v + 1); }}>
      <div><span className="micro-label">LEAVE SOMETHING GROWING</span><h4>Plant a wish of your own.</h4><p>Only held in this tab. Nothing is sent, recorded or shared.</p></div>
      <label>Your wish<textarea maxLength={240} rows={2} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Something you hope for…" required /></label>
      <span className="wish-plant-species">A golden daisy · grown from your words</span>
      <button type="submit">{ownWish ? "Replant my wish" : "Plant my wish"} <Flower2 size={15} /></button>
      {ownWish && <button type="button" onClick={() => { setOwnWish(""); setDraft(""); if (activeWish === 10) setActiveWish(null); }}>Remove my wish</button>}
    </form>
  </WorldSection>;
}
