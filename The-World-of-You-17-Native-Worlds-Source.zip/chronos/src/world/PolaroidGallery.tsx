import { useState } from "react";
import { ArrowLeft, ArrowRight, ImagePlus, ScanEye } from "lucide-react";
import { ArchiveDialog } from "../components/ArchiveDialog";
import { chronosContent } from "../content/chronosContent";
import { WorldSection } from "./WorldSection";

type PhotoEntry = (typeof chronosContent.gallery.photos)[number];

export function PolaroidGallery() {
  const [selected, setSelected] = useState<PhotoEntry | null>(null);
  const [focusedIndex, setFocusedIndex] = useState(0);
  const photo = chronosContent.gallery.photos[focusedIndex];
  const selectPhoto = (entry: PhotoEntry, index: number) => {
    setFocusedIndex(index);
    setSelected(entry);
  };
  const step = (direction: -1 | 1) => {
    const index = (focusedIndex + direction + chronosContent.gallery.photos.length) % chronosContent.gallery.photos.length;
    setFocusedIndex(index);
    setSelected(chronosContent.gallery.photos[index]);
  };

  return (
    <WorldSection id="gallery" className="gallery-section" eyebrow="THE PHOTO WALL · REAL IMAGES ONLY" sideNote="MOUNTS / 06">
      <p className="gallery-intro">{chronosContent.gallery.intro}</p>
      <div className="polaroid-wall" aria-label="Six empty Polaroid photo mounts">
        <span className="polaroid-wall__string polaroid-wall__string--one" aria-hidden="true" />
        <span className="polaroid-wall__string polaroid-wall__string--two" aria-hidden="true" />
        {chronosContent.gallery.photos.map((entry, index) => (
          <button key={entry.id} type="button" className={`polaroid-card polaroid-card--${index + 1}`} onClick={() => selectPhoto(entry, index)} aria-label={`Open Polaroid ${index + 1}: ${entry.caption}. Empty photo mount.`}>
            <span className="polaroid-card__clip" aria-hidden="true" />
            <span className="polaroid-card__image">
              {entry.src ? <img src={entry.src} alt={entry.caption} loading="lazy" width={1200} height={900} /> : <span className="polaroid-card__placeholder"><ImagePlus size={23} /><small>REAL PHOTO<br />GOES HERE</small></span>}
              <span className="polaroid-card__zoom"><ScanEye size={15} /><span>OPEN</span></span>
            </span>
            <span className="polaroid-card__caption">{entry.caption}</span>
            <span className="polaroid-card__date">{entry.date}</span>
          </button>
        ))}
      </div>
      <div className="gallery-bottom-note"><span className="gallery-bottom-note__pin" aria-hidden="true">✿</span><p>Every frame is a real-photo placeholder. Generated illustration is kept out of the personal gallery.</p><span className="gallery-bottom-note__line" aria-hidden="true" /></div>
      <ArchiveDialog open={selected !== null} onClose={() => setSelected(null)} eyebrow={`${String(focusedIndex + 1).padStart(2, "0")} / 06 · ${photo.date}`} title={photo.caption}>
        <div className="polaroid-lightbox">
          <div className="polaroid-lightbox__image">
            {photo.src ? <img src={photo.src} alt={photo.caption} width={1200} height={900} /> : <div><ImagePlus size={36} /><span>EMPTY PHOTO MOUNT</span><small>No personal photo supplied.</small></div>}
          </div>
          <p>{photo.note}</p>
          <div className="polaroid-lightbox__controls">
            <button type="button" onClick={() => step(-1)} aria-label="Previous photo mount"><ArrowLeft size={15} /> Previous</button>
            <button type="button" onClick={() => step(1)} aria-label="Next photo mount">Next <ArrowRight size={15} /></button>
          </div>
        </div>
      </ArchiveDialog>
    </WorldSection>
  );
}
