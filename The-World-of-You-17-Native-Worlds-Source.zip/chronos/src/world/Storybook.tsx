import { forwardRef, lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { ArrowLeft, ArrowRight, BookOpen, Feather, ImagePlus, RotateCcw } from "lucide-react";
import { chronosContent } from "../content/chronosContent";
import { WorldSection } from "./WorldSection";

const HTMLFlipBook = lazy(() => import("react-pageflip"));
const bookPages = chronosContent.scrapbook.spreads;
const storyPages = bookPages.flatMap((spread) => [spread.left, spread.right]);
const leafCount = storyPages.length;
const physicalPageCount = leafCount + 2;

interface FlipBookController {
  flipNext: () => void;
  flipPrev: () => void;
  getCurrentPageIndex: () => number;
}

interface FlipBookHandle {
  pageFlip: () => FlipBookController | null;
}

type BookOrientation = "portrait" | "landscape";
interface FlipStateEvent { data: string; }
interface OrientationEvent { data: string; }

interface MemoryLeafProps {
  page: (typeof storyPages)[number];
  pageNumber: number;
}

const MemoryLeaf = forwardRef<HTMLDivElement, MemoryLeafProps>(({ page, pageNumber }, ref) => (
  <div ref={ref} className={`storybook-leaf storybook-leaf--${page.kind}`} aria-label={`Scrapbook page ${pageNumber}: ${page.title}`}>
    <div className="storybook-leaf__paper">
      <div className="storybook-leaf__header"><span>{page.label}</span><span>{page.date}</span></div>
      {page.kind === "record" && <span className="storybook-leaf__stamp"><i /> A TRUE RECORD</span>}
      {page.kind === "blank" && <span className="storybook-leaf__empty-mark" aria-hidden="true"><Feather size={19} /></span>}
      {page.kind === "photo" && <div className="storybook-leaf__photo-mount" aria-label="Empty mount for an owner-supplied photograph"><ImagePlus size={22} /><span>REAL PHOTO<br />MOUNT</span></div>}
      <h3>{page.title}</h3>
      <p>{page.body}</p>
      {page.kind !== "record" && <span className="storybook-leaf__placeholder-note">OWNER-EDITABLE · EMPTY BY DESIGN</span>}
      <span className="storybook-leaf__number">{String(pageNumber).padStart(2, "0")}</span>
    </div>
  </div>
));
MemoryLeaf.displayName = "MemoryLeaf";

function BookFallback({ children }: { children?: ReactNode }) {
  return <div className="storybook-book__loading" role="status">{children ?? "Preparing the little book…"}</div>;
}

interface StorybookProps { soundEnabled: boolean; }

export function Storybook({ soundEnabled }: StorybookProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const flipBookRef = useRef<FlipBookHandle | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const noiseBufferRef = useRef<AudioBuffer | null>(null);
  const lastSoundAtRef = useRef(0);
  const soundEnabledRef = useRef(soundEnabled);
  const [bookReady, setBookReady] = useState(false);
  const [pageIndex, setPageIndex] = useState(0);
  const [orientation, setOrientation] = useState<BookOrientation | null>(null);
  const [reducedMotion, setReducedMotion] = useState(() => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
    if (!soundEnabled && audioContextRef.current?.state === "running") {
      void audioContextRef.current.suspend().catch(() => {});
    }
  }, [soundEnabled]);

  useEffect(() => () => {
    const context = audioContextRef.current;
    audioContextRef.current = null;
    noiseBufferRef.current = null;
    if (context && context.state !== "closed") void context.close().catch(() => {});
  }, []);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    if (!("IntersectionObserver" in window)) {
      setBookReady(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setBookReady(true);
        observer.disconnect();
      }
    }, { rootMargin: "320px 0px" });
    observer.observe(host);
    return () => observer.disconnect();
  }, []);

  const primeAudio = useCallback(() => {
    if (!soundEnabledRef.current || reducedMotion) return;
    try {
      if (!audioContextRef.current || audioContextRef.current.state === "closed") {
        audioContextRef.current = new window.AudioContext();
      }
      if (audioContextRef.current.state === "suspended") void audioContextRef.current.resume().catch(() => {});
    } catch { /* Optional audio must not block navigation. */ }
  }, [reducedMotion]);

  const playPaperRustle = useCallback(() => {
    if (!soundEnabledRef.current || reducedMotion || typeof window === "undefined") return;
    const now = window.performance.now();
    if (now - lastSoundAtRef.current < 160) return;
    lastSoundAtRef.current = now;

    try {
      const AudioContextConstructor = window.AudioContext;
      if (!AudioContextConstructor) return;
      let context = audioContextRef.current;
      if (!context || context.state === "closed") {
        context = new AudioContextConstructor();
        audioContextRef.current = context;
      }
      if (context.state === "suspended") void context.resume().catch(() => {});
      if (!noiseBufferRef.current || noiseBufferRef.current.sampleRate !== context.sampleRate) {
        const length = Math.ceil(context.sampleRate * 0.34);
        const buffer = context.createBuffer(1, length, context.sampleRate);
        const channel = buffer.getChannelData(0);
        for (let index = 0; index < length; index += 1) channel[index] = (Math.random() * 2 - 1) * (0.7 + Math.random() * 0.3);
        noiseBufferRef.current = buffer;
      }

      const startAt = context.currentTime + 0.012;
      const duration = 0.29;
      const noise = context.createBufferSource();
      const lowPass = context.createBiquadFilter();
      const highPass = context.createBiquadFilter();
      const envelope = context.createGain();
      lowPass.type = "lowpass";
      lowPass.frequency.setValueAtTime(2450, startAt);
      lowPass.frequency.exponentialRampToValueAtTime(520, startAt + duration);
      highPass.type = "highpass";
      highPass.frequency.setValueAtTime(200, startAt);
      envelope.gain.setValueAtTime(0.0001, startAt);
      envelope.gain.linearRampToValueAtTime(0.105, startAt + 0.035);
      envelope.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
      noise.buffer = noiseBufferRef.current;
      noise.connect(highPass).connect(lowPass).connect(envelope).connect(context.destination);
      noise.start(startAt);
      noise.stop(startAt + duration + 0.025);
      noise.onended = () => {
        noise.disconnect();
        highPass.disconnect();
        lowPass.disconnect();
        envelope.disconnect();
      };
    } catch {
      // Audio is an optional enhancement; unsupported or blocked playback must never break page navigation.
    }
  }, [reducedMotion]);

  const onFlip = useCallback((event: FlipStateEvent) => {
    setPageIndex(Number(event.data));
  }, []);
  const onBookState = useCallback((event: FlipStateEvent) => {
    if (event.data === "user_fold") primeAudio();
    if (event.data === "flipping") playPaperRustle();
  }, [primeAudio, playPaperRustle]);
  const onOrientation = useCallback((event: OrientationEvent) => {
    if (event.data === "portrait" || event.data === "landscape") setOrientation(event.data);
  }, []);
  const turn = useCallback((direction: "next" | "prev") => {
    primeAudio();
    const pageFlip = flipBookRef.current?.pageFlip();
    if (!pageFlip) return;
    if (direction === "next") pageFlip.flipNext();
    else pageFlip.flipPrev();
  }, [primeAudio]);

  const onBookKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "ArrowRight") {
      event.preventDefault();
      turn("next");
    } else if (event.key === "ArrowLeft") {
      event.preventDefault();
      turn("prev");
    }
  };

  const displayPage = pageIndex === 0 ? "COVER" : `${Math.min(leafCount, pageIndex)} / ${leafCount}`;
  const noPrevious = pageIndex <= 0;
  const noNext = pageIndex >= physicalPageCount - 1;
  const pageElements = useMemo(() => [
    <div key="cover" className="storybook-leaf storybook-leaf--cover" data-density="hard" aria-label="Scrapbook cover">
      <div className="storybook-cover__ornament" aria-hidden="true">✿</div>
      <span className="storybook-cover__eyebrow">THE WORLD OF YOU</span>
      <strong>Our story,<br />in paper.</strong>
      <small>BHUMI · RUDRA</small>
      <span className="storybook-cover__press" aria-hidden="true">✦</span>
    </div>,
    ...storyPages.map((page, index) => <MemoryLeaf key={`${bookPages[Math.floor(index / 2)].id}-${index}`} page={page} pageNumber={index + 1} />),
    <div key="back-cover" className="storybook-leaf storybook-leaf--back-cover" data-density="hard" aria-label="Back cover">
      <div className="storybook-back-cover__mark" aria-hidden="true">✿</div>
      <span>THE END IS A PAGE LEFT OPEN</span>
      <strong>Still being<br />written.</strong>
      <small>WITH LOVE · RUDRA</small>
    </div>,
  ], []);

  return (
    <WorldSection id="storybook" className="storybook-section" eyebrow="THE MEMORY BOOK" sideNote="PAPER / 03">
      <div className="storybook-intro">
        <span className="storybook-intro__icon" aria-hidden="true"><BookOpen size={21} /></span>
        <p>{chronosContent.scrapbook.intro}</p>
        <span className="storybook-intro__rule" aria-hidden="true" />
      </div>

      <div className="storybook-book-wrap" ref={hostRef}>
        <div
          className="storybook-book__stage"
          role="group"
          aria-label="Interactive scrapbook. Use the left and right arrow keys, page controls, or swipe to turn pages."
          tabIndex={0}
          onKeyDown={onBookKeyDown}
          onPointerDownCapture={primeAudio}
          onTouchStartCapture={primeAudio}
        >
          {bookReady ? (
            <Suspense fallback={<BookFallback />}>
              <HTMLFlipBook
                ref={flipBookRef}
                className="storybook-flipbook"
                style={{ margin: "0 auto" }}
                width={430}
                height={540}
                size="stretch"
                minWidth={270}
                maxWidth={430}
                minHeight={390}
                maxHeight={560}
                drawShadow
                flippingTime={reducedMotion ? 1 : 780}
                usePortrait
                startZIndex={20}
                autoSize
                maxShadowOpacity={0.24}
                showCover
                mobileScrollSupport={false}
                clickEventForward
                useMouseEvents
                swipeDistance={34}
                showPageCorners
                disableFlipByClick={false}
                startPage={0}
                onFlip={onFlip}
                onChangeState={onBookState}
                onChangeOrientation={onOrientation}
              >
                {pageElements}
              </HTMLFlipBook>
            </Suspense>
          ) : (
            <div className="storybook-book__fallback" aria-label="Scrapbook is ready to open">
              <div className="storybook-book__fallback-cover"><span>✿</span><strong>OUR STORY,<br />IN PAPER</strong><small>BHUMI · RUDRA</small></div>
              <div className="storybook-book__fallback-page"><small>{bookPages[0].left.date}</small><h3>{bookPages[0].left.title}</h3><p>{bookPages[0].left.body}</p></div>
            </div>
          )}
        </div>
        <div className="storybook-controls">
          <button className="storybook-turn" type="button" onClick={() => turn("prev")} disabled={noPrevious} aria-label="Turn to the previous scrapbook page"><ArrowLeft size={16} /><span>Previous</span></button>
          <div className="storybook-pagination" aria-live="polite" aria-atomic="true" aria-label={`Current scrapbook page ${displayPage}`}><span>{displayPage}</span><i /></div>
          <button className="storybook-turn storybook-turn--next" type="button" onClick={() => turn("next")} disabled={noNext} aria-label="Turn to the next scrapbook page"><span>Next page</span><ArrowRight size={16} /></button>
        </div>
        <p className="storybook-layout-status" role="status">{orientation ? (orientation === "portrait" ? "Single-page layout" : "Two-page spread layout") : "Responsive book layout"}</p>
        <p className="storybook-swipe-hint"><RotateCcw size={12} aria-hidden="true" /> {chronosContent.scrapbook.turnHint} · arrow keys supported</p>
      </div>
    </WorldSection>
  );
}
