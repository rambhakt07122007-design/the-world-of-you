import { ArrowDownRight, CakeSlice, Flower2, Sparkles } from "lucide-react";
import { chronosContent } from "../content/chronosContent";

const petals = Array.from({ length: 18 }, (_, index) => ({
  id: index,
  left: `${(index * 41 + 8) % 98}%`,
  delay: `${(index % 10) * 310}ms`,
  duration: `${12 + (index % 7) * 2}s`,
  rotation: `${index * 31}deg`,
}));

const fireflies = Array.from({ length: 14 }, (_, index) => ({
  id: index,
  left: `${(index * 59 + 11) % 96}%`,
  top: `${(index * 31 + 17) % 82}%`,
  delay: `${(index % 7) * 430}ms`,
}));

export function BirthdayGarden() {

  return (
    <section id="garden" className="birthday-garden" data-chapter="garden" data-scene-anchor="garden" aria-labelledby="birthday-garden-title">
      <p className="sr-only">The decorative scene shows a warm storybook garden path through blush, cream and peach flowers toward a small glass pavilion.</p>
      <div className="birthday-garden__veil" aria-hidden="true" />
      <div className="birthday-garden__sunwash" aria-hidden="true" />
      <div className="garden-petals" aria-hidden="true">{petals.map((petal) => <i key={petal.id} style={{ left: petal.left, animationDelay: petal.delay, animationDuration: petal.duration, rotate: petal.rotation }} />)}</div>
      <div className="garden-fireflies" aria-hidden="true">{fireflies.map((light) => <i key={light.id} style={{ left: light.left, top: light.top, animationDelay: light.delay }} />)}</div>
      <div className="garden-balloons" aria-hidden="true"><i className="garden-balloon garden-balloon--blush" /><i className="garden-balloon garden-balloon--champagne" /><i className="garden-balloon garden-balloon--cream" /></div>
      <span className="garden-butterfly garden-butterfly--one" aria-hidden="true">✦</span>
      <span className="garden-butterfly garden-butterfly--two" aria-hidden="true">✧</span>
      <div className="birthday-garden__ornament birthday-garden__ornament--flower" aria-hidden="true"><Flower2 size={75} strokeWidth={0.8} /></div>
      <div className="birthday-garden__ornament birthday-garden__ornament--cake" aria-hidden="true"><CakeSlice size={53} strokeWidth={0.9} /></div>
      <div className="birthday-garden__content">
        <p className="birthday-garden__eyebrow"><span />{chronosContent.garden.eyebrow}</p>
        <h1 id="birthday-garden-title" tabIndex={-1}>{chronosContent.garden.heading}</h1>
        <p className="birthday-garden__sub">{chronosContent.garden.subheading}</p>
        <div className="birthday-garden__actions">
          <a className="garden-cta" href="#storybook"><span>{chronosContent.garden.invitation}</span><ArrowDownRight size={17} aria-hidden="true" /></a>
          <span className="birthday-garden__seal"><Sparkles size={14} aria-hidden="true" /> 17 NOVEMBER</span>
        </div>
        <p className="birthday-garden__date-note">Bhumi’s birthday · the year is not specified in the source archive.</p>
      </div>
      <div className="birthday-garden__caption" aria-hidden="true"><span>THE WORLD OF YOU</span><i /><span>A LITTLE GARDEN FOR A BIRTHDAY</span></div>
      <a href="#storybook" className="birthday-garden__scroll" aria-label="Scroll to the scrapbook"><span>TURN THE FIRST PAGE</span><span className="birthday-garden__scroll-icon"><ArrowDownRight size={14} /></span></a>
    </section>
  );
}
