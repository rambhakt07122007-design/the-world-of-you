import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, CakeSlice, Flower2, Heart, RotateCcw, Star } from "lucide-react";
import { chronosContent } from "../content/chronosContent";

interface FinalCelebrationProps { onReplayOpening: () => void; }
const confetti = Array.from({ length: 36 }, (_, index) => ({
  id: index,
  angle: `${(index * 137.5) % 360}deg`,
  distance: `${90 + (index % 7) * 25}px`,
  delay: `${(index % 12) * 35}ms`,
  color: ["#c98291", "#d6b879", "#dfaa8f", "#9aa58c", "#f6e8d0"][index % 5],
}));
const fallingStars = Array.from({ length: 8 }, (_, index) => ({
  id: index,
  left: `${9 + ((index * 29) % 82)}%`,
  delay: `${index * 1.7}s`,
  duration: `${5 + (index % 3)}s`,
}));

export function FinalCelebration({ onReplayOpening }: FinalCelebrationProps) {
  const [celebrating, setCelebrating] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    if (typeof IntersectionObserver === "undefined") {
      setCelebrating(true);
      timer.current = window.setTimeout(() => setCelebrating(false), 1700);
      return () => { if (timer.current !== null) window.clearTimeout(timer.current); };
    }
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      setCelebrating(true);
      timer.current = window.setTimeout(() => setCelebrating(false), 1700);
      observer.disconnect();
    }, { threshold: 0.22 });
    observer.observe(section);
    return () => {
      observer.disconnect();
      if (timer.current !== null) window.clearTimeout(timer.current);
    };
  }, []);

  const replay = () => {
    setCelebrating(false);
    window.requestAnimationFrame(() => setCelebrating(true));
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setCelebrating(false), 1700);
  };
  return (
    <section ref={sectionRef} id="finale" data-chapter="finale" data-scene-anchor="finale" className={`final-celebration${celebrating ? " is-replaying" : ""}`} aria-labelledby="finale-title">
      <div className="final-celebration__starfield" aria-hidden="true">{fallingStars.map((star) => <i key={star.id} style={{ left: star.left, animationDelay: star.delay, animationDuration: star.duration }} />)}</div>
      <div className="final-celebration__particles" aria-hidden="true">{confetti.map((item) => <i key={item.id} style={{ "--confetti-angle": item.angle, "--confetti-distance": item.distance, "--confetti-delay": item.delay, "--confetti-color": item.color } as React.CSSProperties} />)}</div>
      <div className="final-celebration__content">
        <div className="final-celebration__flower-seal" aria-hidden="true"><Flower2 size={29} strokeWidth={0.9} /><i><Star size={10} fill="currentColor" /></i></div>
        <p className="final-celebration__kicker">{chronosContent.finale.kicker}</p>
        <h2 id="finale-title">{chronosContent.finale.headline}</h2>
        <div className="final-celebration__divider" aria-hidden="true"><span /><Heart size={13} /><span /></div>
        <p className="final-celebration__sub">{chronosContent.finale.sub}</p>
        <blockquote>{chronosContent.finale.sourceMessage}<cite>— RUDRA · SOURCE DRAFT</cite></blockquote>
        <div className="final-celebration__signoff"><span>✿</span><small>A BIRTHDAY STORYBOOK FOR BHUMI</small><span>✿</span></div>
        <p className="final-celebration__signature">Made with love by <span>Rudra</span></p>
        <nav className="final-celebration__links" aria-label="Final chapter links">
          <a href="#letters"><span>{chronosContent.finale.letterLink}</span><ArrowUpRight size={15} /></a>
          <a href="#storybook"><span>{chronosContent.finale.storyLink}</span><ArrowUpRight size={15} /></a>
        </nav>
        <div className="final-celebration__controls">
          <button type="button" onClick={replay}><RotateCcw size={14} /> {chronosContent.finale.replay}</button>
          <button type="button" onClick={onReplayOpening}><CakeSlice size={14} /> Replay Experience</button>
        </div>
      </div>
      <div className="final-celebration__footer"><span>THE WORLD OF YOU</span><i /><span>17 NOVEMBER · YEAR NOT SPECIFIED</span></div>
    </section>
  );
}
