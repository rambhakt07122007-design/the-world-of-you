import { useEffect, useRef, useState } from "react";
import { Feather, Heart, Mail, PenLine } from "lucide-react";
import { ArchiveDialog } from "../components/ArchiveDialog";
import { chronosContent } from "../content/chronosContent";
import { SceneCanvas } from "../three/SceneCanvas";
import { WorldSection } from "./WorldSection";

type LetterEntry = (typeof chronosContent.letters.letters)[number];

export function LetterRoom() {
  const [closing, setClosing] = useState(false);
  const [paperOpen, setPaperOpen] = useState(false);
  const [paperReplay, setPaperReplay] = useState(0);
  const [immediate, setImmediate] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selected, setSelected] = useState<LetterEntry | null>(null);
  const timer = useRef<number | null>(null);
  useEffect(() => () => { if (timer.current !== null) window.clearTimeout(timer.current); }, []);
  const finishClose = () => { setSelected(null); setClosing(false); };
  const openLetter = (letter: LetterEntry) => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    setClosing(false); setProgress(0); setPaperOpen(false); setImmediate(false); setSelected(letter);
  };
  const closeLetter = () => {
    if (!selected || closing) return;
    setPaperOpen(false); setImmediate(false);
    if (progress === 0 || window.matchMedia("(prefers-reduced-motion: reduce)").matches) { finishClose(); return; }
    setClosing(true);
    // Fallback watchdog: progress normally completes closure, but unavailable WebGL must never trap the dialog.
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(finishClose, 5100);
  };
  const togglePaper = () => { if (!closing) { setImmediate(false); setPaperOpen(v => !v); } };
  const readable = paperOpen && (progress >= .995 || immediate);
  const phase = progress < .14 ? "Breaking the wax seal" : progress < .36 ? "Opening the hinged flap" : progress < .65 ? "Drawing the letter from its pocket" : progress < .84 ? "Unfolding the first crease" : progress < .995 ? "Unfolding the second crease" : "Letter open. The original message is ready below.";

  return (
    <WorldSection id="letters" className="letters-section" eyebrow="A WRITING DESK · FIVE ENVELOPES" sideNote="SEALED / 05">
      <p className="letters-intro">{chronosContent.letters.intro}</p>
      <div className="letters-room">
        <figure className="letters-desk">
          <img src="/assets/paper/writing-desk.webp" alt="An illustrated blank letter, fountain pen and flowers on a warm cream writing desk." width={1200} height={896} loading="lazy" />
          <figcaption><span><Feather size={13} /> A PLACE FOR WORDS</span><i aria-hidden="true" />
            <p>Only a real letter belongs here.</p>
          </figcaption>
        </figure>
        <div className="letter-shelf" aria-label="Five letter envelopes">
          {chronosContent.letters.letters.map((letter, index) => {
            const isSource = letter.sourceDraft;
            return (
              <button key={letter.id} className={`letter-envelope${isSource ? " letter-envelope--source" : ""}`} type="button" onClick={() => openLetter(letter)} aria-label={`Open ${letter.category}${isSource ? ", source letter included" : ", empty owner-editable envelope"}`}>
                <span className="letter-envelope__number">0{index + 1}</span>
                <span className="letter-envelope__paper" aria-hidden="true"><span>{isSource ? "Bhumi," : "A note for you"}</span><i /></span>
                <span className="letter-envelope__body" aria-hidden="true" />
                <span className="letter-envelope__flap" aria-hidden="true" />
                <span className="letter-envelope__seal" aria-hidden="true">{isSource ? <Heart size={13} /> : <span>✿</span>}</span>
                <span className="letter-envelope__title">{letter.category}</span>
                <span className="letter-envelope__status">{isSource ? "SOURCE LETTER" : "EMPTY · OWNER-WRITTEN"}</span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="letters-note"><PenLine size={15} aria-hidden="true" /><span>Personal words stay editable in <code>src/content/chronosContent.ts</code>. The four unfilled envelopes will remain blank until their owner writes them.</span></div>
      <ArchiveDialog open={selected !== null} onClose={closeLetter} eyebrow={selected?.label} title={selected?.title ?? "A letter"}>
        {selected && <div className="letter-reading">
          <SceneCanvas kind="letter" state={{ open: paperOpen, replay: paperReplay, immediate, detail: [selected.salutation, ...selected.paragraphs, selected.closing, selected.signature, selected.ps].filter(Boolean).join("\n\n") }} onPick={togglePaper} onProgress={(value) => { setProgress(value); if (closing && value === 0) { if (timer.current !== null) window.clearTimeout(timer.current); finishClose(); } }} label="A warm wooden writing desk. A split wax seal, thick hinged envelope flap and continuous paper mesh open in sequence, bending along two rounded creases. Use the buttons below for keyboard access." />
          <div className="cinematic-controls" aria-label="Letter animation controls">
            <button type="button" disabled={closing} onClick={togglePaper}>{paperOpen ? "Close Letter" : "Open Letter"}</button>
            <button type="button" disabled={closing} onClick={() => { setProgress(0); setImmediate(false); setPaperOpen(true); setPaperReplay(v => v + 1); }}>Replay Animation</button>
            <button type="button" onClick={() => { if (closing) { finishClose(); return; } setPaperOpen(true); setProgress(1); setImmediate(true); }}>Skip Animation</button>
          </div>
          <p className="paper-status" role="status">{closing ? "Refolding and returning the letter to its envelope…" : paperOpen ? phase : progress > 0 ? "Refolding along the original creases…" : "Letter folded. Open it to read the message. Skip also works without 3D."}</p>
          <div className={readable ? "physical-letter-copy is-open" : "physical-letter-copy"} hidden={!readable}>
          {selected.salutation && <p className="letter-reading__salutation">{selected.salutation}</p>}
          {selected.paragraphs.length ? <div className="letter-reading__body">{selected.paragraphs.map((paragraph, index) => <p key={index}>{paragraph}</p>)}</div> : <div className="letter-empty"><Mail size={24} /><p>{selected.title} has not been written yet.</p><small>This envelope is intentionally empty. Add only owner-written words to its entry in chronosContent.ts.</small></div>}
          {selected.closing && <p className="letter-reading__closing">{selected.closing}<br /><strong>{selected.signature}</strong></p>}
          {selected.ps && <p className="letter-reading__ps">{selected.ps}</p>}
        </div></div>}
      </ArchiveDialog>
    </WorldSection>
  );
}
