import { useEffect, useRef, useState } from "react";
import { Flower2 } from "lucide-react";
import { BirthdayCake } from "./world/BirthdayCake";
import { BirthdayGarden } from "./world/BirthdayGarden";
import { FinalCelebration } from "./world/FinalCelebration";
import { FlowerGarden } from "./world/FlowerGarden";
import { FuturePostcards } from "./world/FuturePostcards";
import { GiftRoom } from "./world/GiftRoom";
import { LetterRoom } from "./world/LetterRoom";
import { MusicRoom } from "./world/MusicRoom";
import { OpeningInvitation } from "./world/OpeningInvitation";
import { PolaroidGallery } from "./world/PolaroidGallery";
import { RelationshipClock } from "./world/RelationshipClock";
import { Storybook } from "./world/Storybook";
import { WorldNav } from "./world/WorldNav";
import { chronosContent } from "./content/chronosContent";
import { SceneExperience } from "./scenes/SceneExperience";

export default function App() {
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [activeSection, setActiveSection] = useState("invitation");
  const [invitationKey, setInvitationKey] = useState(0);
  const progressRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    document.title = chronosContent.meta.docTitle;
    document.documentElement.dataset.theme = "birthday";
    return () => { delete document.documentElement.dataset.theme; };
  }, []);

  useEffect(() => {
    const rawHash = window.location.hash.slice(1);
    if (!rawHash) return;
    let targetId = rawHash;
    try { targetId = decodeURIComponent(rawHash); } catch { /* keep the raw fragment */ }
    const frame = window.requestAnimationFrame(() => {
      document.getElementById(targetId)?.scrollIntoView({ block: "start", behavior: "instant" });
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const sections = Array.from(document.querySelectorAll<HTMLElement>("[data-chapter]"));
    let frame = 0;
    let currentId = "invitation";
    let disposed = false;
    const updateScrollState = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        const readingLine = window.innerHeight * 0.5;
        const current = sections.find((section) => {
          const bounds = section.getBoundingClientRect();
          return bounds.top <= readingLine && bounds.bottom > readingLine;
        }) ?? [...sections].reverse().find((section) => section.getBoundingClientRect().top <= readingLine);
        const id = current?.getAttribute("data-chapter");
        if (id && id !== currentId) {
          currentId = id;
          setActiveSection(id);
        }
        const scrollable = document.documentElement.scrollHeight - window.innerHeight;
        const progress = scrollable > 0 ? Math.min(100, Math.max(0, (window.scrollY / scrollable) * 100)) : 0;
        progressRef.current?.style.setProperty("width", `${progress}%`);
      });
    };
    const content = document.getElementById("main-content");
    const layoutObserver = content && "ResizeObserver" in window ? new ResizeObserver(updateScrollState) : null;
    if (content) layoutObserver?.observe(content);
    updateScrollState();
    window.addEventListener("scroll", updateScrollState, { passive: true });
    window.addEventListener("resize", updateScrollState);
    document.fonts?.ready.then(() => { if (!disposed) updateScrollState(); });
    return () => {
      disposed = true;
      layoutObserver?.disconnect();
      window.cancelAnimationFrame(frame);
      window.removeEventListener("scroll", updateScrollState);
      window.removeEventListener("resize", updateScrollState);
    };
  }, []);

  const reducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const setSceneHash = (id: string) => {
    window.history.replaceState(window.history.state, "", `${window.location.pathname}${window.location.search}#${id}`);
  };
  const goToGarden = () => {
    setSceneHash("garden");
    document.getElementById("garden")?.scrollIntoView({ behavior: reducedMotion() ? "instant" : "smooth", block: "start" });
    window.setTimeout(() => document.getElementById("birthday-garden-title")?.focus({ preventScroll: true }), reducedMotion() ? 0 : 320);
  };
  const replayInvitation = () => {
    setSoundEnabled(false);
    setInvitationKey((key) => key + 1);
    setSceneHash("invitation");
    window.scrollTo({ top: 0, behavior: reducedMotion() ? "instant" : "smooth" });
  };

  return (
    <>
      <a className="skip-link" href="#garden">Skip to the birthday garden</a>
      <SceneExperience />
      <div className="world-site">
        <div className="reading-progress" aria-hidden="true"><span ref={progressRef} /></div>
        <main id="main-content" tabIndex={-1}>
          <OpeningInvitation key={invitationKey} onEnter={goToGarden} onSkip={goToGarden} />
          <WorldNav
            activeSection={activeSection}
            soundOn={soundEnabled}
            onToggleSound={() => setSoundEnabled((current) => !current)}
            onReplayInvitation={replayInvitation}
          />
          <BirthdayGarden />
          <Storybook soundEnabled={soundEnabled} />
          <RelationshipClock />
          <LetterRoom />
          <PolaroidGallery />
          <FlowerGarden />
          <GiftRoom soundEnabled={soundEnabled} />
          <MusicRoom soundEnabled={soundEnabled} onToggleSound={() => setSoundEnabled((current) => !current)} />
          <FuturePostcards />
          <BirthdayCake />
          <FinalCelebration onReplayOpening={replayInvitation} />
        </main>
        {activeSection !== "invitation" && (
          <a href="#garden" className="back-to-garden" aria-label="Return to the birthday garden">
            <Flower2 size={17} aria-hidden="true" /><span>GARDEN</span>
          </a>
        )}
      </div>
    </>
  );
}
