import { useEffect, useRef, useState } from "react";
import { SCENE_CATALOG, TRANSITION_PRESETS, type SceneId } from "./sceneCatalog";

type MotionMode = "css" | "gsap";

function sceneAtReadingLine(): SceneId {
  const line = window.innerHeight * 0.52;
  let current = SCENE_CATALOG[0].id;
  for (const scene of SCENE_CATALOG) {
    const anchor = document.getElementById(scene.anchorId);
    if (anchor && anchor.getBoundingClientRect().top <= line) current = scene.id;
    else if (anchor) break;
  }
  return current;
}

export function SceneExperience() {
  const stageRef = useRef<HTMLDivElement>(null);
  const [activeScene, setActiveScene] = useState<SceneId>("invitation");
  const [motionMode, setMotionMode] = useState<MotionMode>("css");
  const [reducedMotion, setReducedMotion] = useState(() =>
    typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updatePreference = () => setReducedMotion(preference.matches);
    preference.addEventListener("change", updatePreference);
    return () => preference.removeEventListener("change", updatePreference);
  }, []);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    let disposed = false;
    let observer: IntersectionObserver | null = null;
    let layoutObserver: ResizeObserver | null = null;
    let refreshFrame = 0;
    let revertGsap = () => {};

    const observeCurrentScene = () => {
      if (!("IntersectionObserver" in window)) return;
      observer?.disconnect();
      observer = new IntersectionObserver((entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        const anchorId = visible?.target.getAttribute("data-chapter");
        const scene = SCENE_CATALOG.find((candidate) => candidate.anchorId === anchorId);
        if (scene) setActiveScene(scene.id);
      }, { rootMargin: "-20% 0px -48% 0px", threshold: [0.05, 0.2, 0.45, 0.72] });
      for (const scene of SCENE_CATALOG) {
        const anchor = document.getElementById(scene.anchorId);
        if (anchor) observer.observe(anchor);
      }
    };

    setActiveScene(sceneAtReadingLine());

    if (reducedMotion) {
      setMotionMode("css");
      observeCurrentScene();
      return () => observer?.disconnect();
    }

    void Promise.all([import("gsap"), import("gsap/ScrollTrigger")])
      .then(([gsapModule, scrollModule]) => {
        if (disposed) return;
        const gsap = gsapModule.gsap;
        const { ScrollTrigger } = scrollModule;
        gsap.registerPlugin(ScrollTrigger);

        const layers = Array.from(stage.querySelectorAll<HTMLElement>("[data-scene-layer]"));
        const currentId = sceneAtReadingLine();
        const currentIndex = Math.max(0, SCENE_CATALOG.findIndex((scene) => scene.id === currentId));

        const context = gsap.context(() => {
          gsap.set(layers, { autoAlpha: 0, scale: 1.045, xPercent: 0 });
          gsap.set(layers[currentIndex], { autoAlpha: 1, scale: 1, xPercent: 0 });

          for (let index = 0; index < SCENE_CATALOG.length; index += 1) {
            const scene = SCENE_CATALOG[index];
            const layer = layers[index];
            const anchor = document.getElementById(scene.anchorId);
            const far = layer?.querySelector<HTMLElement>(".scene-world__far");
            const mid = layer?.querySelector<HTMLElement>(".scene-world__mid");
            const near = layer?.querySelector<HTMLElement>(".scene-world__near");
            if (anchor && far && mid && near) {
              const parallax = gsap.timeline({
                scrollTrigger: { trigger: anchor, start: "top bottom", end: "bottom top", scrub: true, invalidateOnRefresh: true },
              });
              parallax
                .fromTo(far, { yPercent: 1.4 }, { yPercent: -1.4, ease: "none", immediateRender: false }, 0)
                .fromTo(mid, { yPercent: 0.8 }, { yPercent: -0.8, ease: "none", immediateRender: false }, 0)
                .fromTo(near, { yPercent: 0 }, { yPercent: -2.2, ease: "none", immediateRender: false }, 0);
            }
          }

          for (let index = 1; index < SCENE_CATALOG.length; index += 1) {
            const scene = SCENE_CATALOG[index];
            const previousScene = SCENE_CATALOG[index - 1];
            const outgoing = layers[index - 1];
            const incoming = layers[index];
            const outgoingMotion = TRANSITION_PRESETS[previousScene.transition];
            const incomingMotion = TRANSITION_PRESETS[scene.transition];
            const trigger = document.getElementById(scene.anchorId);
            if (!trigger || !outgoing || !incoming) continue;

            const transition = gsap.timeline({
              scrollTrigger: {
                trigger,
                start: "top 82%",
                end: "top 30%",
                scrub: true,
                invalidateOnRefresh: true,
                onEnter: () => setActiveScene(scene.id),
                onEnterBack: () => setActiveScene(scene.id),
                onLeaveBack: () => setActiveScene(SCENE_CATALOG[index - 1].id),
              },
            });

            transition
              .fromTo(outgoing,
                { autoAlpha: 1, scale: 1, xPercent: 0 },
                { autoAlpha: 0, scale: outgoingMotion.exitScale, xPercent: outgoingMotion.exitX, ease: "none", immediateRender: false },
                0,
              )
              .fromTo(incoming,
                { autoAlpha: 0, scale: incomingMotion.enterScale, xPercent: incomingMotion.enterX },
                { autoAlpha: 1, scale: 1, xPercent: 0, ease: "none", immediateRender: false },
                0,
              );
          }

          // Headings stay readable at rest; no repeated slide/fade entrance on every chapter.

        }, stage);

        revertGsap = () => context.revert();
        const narrative = document.getElementById("main-content");
        if (narrative && "ResizeObserver" in window) {
          layoutObserver = new ResizeObserver(() => {
            window.cancelAnimationFrame(refreshFrame);
            refreshFrame = window.requestAnimationFrame(() => {
              if (!disposed) ScrollTrigger.refresh();
            });
          });
          layoutObserver.observe(narrative);
        }
        setActiveScene(currentId);
        setMotionMode("gsap");
        requestAnimationFrame(() => {
          if (!disposed) ScrollTrigger.refresh();
        });
        void document.fonts?.ready.then(() => {
          if (!disposed) ScrollTrigger.refresh();
        });
      })
      .catch(() => {
        if (disposed) return;
        setMotionMode("css");
        observeCurrentScene();
      });

    return () => {
      disposed = true;
      observer?.disconnect();
      layoutObserver?.disconnect();
      window.cancelAnimationFrame(refreshFrame);
      revertGsap();
    };
  }, [reducedMotion]);

  const activeIndex = Math.max(0, SCENE_CATALOG.findIndex((scene) => scene.id === activeScene));

  return (
    <div
      ref={stageRef}
      className="scene-stage"
      data-active-scene={activeScene}
      data-motion-mode={motionMode}
      aria-hidden="true"
    >
      {SCENE_CATALOG.map((scene, index) => {
        const isActive = scene.id === activeScene;
        const shouldLoadArt = Math.abs(index - activeIndex) <= 1;
        return (
          <div
            key={scene.id}
            className={`scene-world scene-world--${scene.id}${isActive ? " is-active" : ""}`}
            data-scene-layer={scene.id}
            data-active={isActive ? "true" : "false"}
            data-near={shouldLoadArt ? "true" : "false"}
          >
            {scene.background && shouldLoadArt && (
              <img
                className="scene-world__image"
                src={scene.background}
                alt=""
                aria-hidden="true"
                width={1376}
                height={768}
                loading={isActive ? "eager" : "lazy"}
                fetchPriority={isActive ? "high" : "low"}
                style={{ objectPosition: scene.objectPosition ?? "center" }}
              />
            )}
            <span className="scene-world__wash" />
            <span className="scene-world__glow" />
            <span className="scene-world__far" />
            <span className="scene-world__mid" />
            <span className="scene-world__near" />
            <span className="scene-world__grain" />
          </div>
        );
      })}
    </div>
  );
}
