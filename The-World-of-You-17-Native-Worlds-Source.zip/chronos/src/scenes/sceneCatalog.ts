export type SceneId =
  | "invitation"
  | "garden"
  | "scrapbook"
  | "observatory"
  | "letters"
  | "gallery"
  | "wishes"
  | "atelier"
  | "music"
  | "postcards"
  | "ballroom"
  | "finale";

export type SceneTransition = "bloom" | "garden-drift" | "page-turn" | "starlight" | "warm-dissolve" | "gallery-fade" | "velvet-rise" | "horizon" | "celebration" | "finale";

export interface SceneConfig {
  id: SceneId;
  anchorId: string;
  title: string;
  transition: SceneTransition;
  background?: string;
  objectPosition?: string;
}

/** Small, reversible 2.5D offsets; the scroll position remains native. */
export const TRANSITION_PRESETS: Record<SceneTransition, { enterScale: number; enterX: number; exitScale: number; exitX: number }> = {
  bloom: { enterScale: 1.055, enterX: 0.6, exitScale: 1.03, exitX: -0.8 },
  "garden-drift": { enterScale: 1.04, enterX: 1, exitScale: 1.03, exitX: -1 },
  "page-turn": { enterScale: 1.045, enterX: -0.9, exitScale: 1.03, exitX: 0.7 },
  starlight: { enterScale: 1.06, enterX: 0.8, exitScale: 1.035, exitX: -0.8 },
  "warm-dissolve": { enterScale: 1.045, enterX: -0.5, exitScale: 1.025, exitX: 0.5 },
  "gallery-fade": { enterScale: 1.035, enterX: 0.4, exitScale: 1.025, exitX: -0.4 },
  "velvet-rise": { enterScale: 1.05, enterX: -0.6, exitScale: 1.03, exitX: 0.6 },
  horizon: { enterScale: 1.035, enterX: 0.8, exitScale: 1.03, exitX: -0.8 },
  celebration: { enterScale: 1.06, enterX: 0, exitScale: 1.035, exitX: 0 },
  finale: { enterScale: 1.055, enterX: 0, exitScale: 1.03, exitX: 0 },
};

/** Visual-only map. Narrative copy and interactive state stay in the chapter components. */
export const SCENE_CATALOG: readonly SceneConfig[] = [
  { id: "invitation", anchorId: "invitation", title: "Invitation Room", transition: "bloom", background: "/assets/scenes/invitation-room.webp", objectPosition: "center 58%" },
  { id: "garden", anchorId: "garden", title: "Birthday Garden", transition: "garden-drift", background: "/assets/backgrounds/birthday-garden.webp", objectPosition: "center 53%" },
  { id: "scrapbook", anchorId: "storybook", title: "Scrapbook", transition: "page-turn" },
  { id: "observatory", anchorId: "timepiece", title: "Memory Observatory", transition: "starlight", background: "/assets/scenes/memory-observatory.webp", objectPosition: "center 52%" },
  { id: "letters", anchorId: "letters", title: "Letter Room", transition: "warm-dissolve" },
  { id: "gallery", anchorId: "gallery", title: "Memory Gallery", transition: "gallery-fade" },
  { id: "wishes", anchorId: "flower-garden", title: "Wish Garden", transition: "garden-drift" },
  { id: "atelier", anchorId: "gifts", title: "Gift Atelier", transition: "velvet-rise" },
  { id: "music", anchorId: "music-room", title: "Music Lounge", transition: "velvet-rise" },
  { id: "postcards", anchorId: "future-postcards", title: "Future Postcards", transition: "horizon" },
  { id: "ballroom", anchorId: "birthday-cake", title: "Birthday Ballroom", transition: "celebration", background: "/assets/scenes/birthday-ballroom.webp", objectPosition: "center 52%" },
  { id: "finale", anchorId: "finale", title: "Finale", transition: "finale" },
] as const;
