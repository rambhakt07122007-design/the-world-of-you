export interface ElapsedTime {
  days: number;
  hours: number;
  minutes: number;
}

/**
 * Convert the start of a YYYY-MM-DD calendar date in an IANA time zone to an
 * instant. No historical hour is invented: callers pass a date-only value and
 * this function deliberately anchors it at local midnight in the configured
 * zone.
 */
export function zonedStartOfDate(dateOnly: string, timeZone: string): number {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateOnly);
  if (!match) throw new Error(`Expected YYYY-MM-DD, got ${dateOnly}`);
  const [, yearText, monthText, dayText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const targetWallClock = Date.UTC(year, month - 1, day, 0, 0, 0, 0);

  // Start with UTC midnight, then iteratively correct the offset so formatting
  // the candidate in `timeZone` yields 00:00 on the requested calendar date.
  let candidate = targetWallClock;
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });

  for (let attempt = 0; attempt < 4; attempt += 1) {
    const parts = formatter.formatToParts(new Date(candidate));
    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    const representedWallClock = Date.UTC(
      Number(values.year),
      Number(values.month) - 1,
      Number(values.day),
      Number(values.hour),
      Number(values.minute),
      Number(values.second),
    );
    const correction = targetWallClock - representedWallClock;
    candidate += correction;
    if (correction === 0) break;
  }
  return candidate;
}

export function getElapsedTime(
  dateOnly: string,
  timeZone: string,
  now = Date.now(),
): ElapsedTime {
  const start = zonedStartOfDate(dateOnly, timeZone);
  const elapsedMinutes = Math.max(0, Math.floor((now - start) / 60_000));
  return {
    days: Math.floor(elapsedMinutes / (60 * 24)),
    hours: Math.floor((elapsedMinutes % (60 * 24)) / 60),
    minutes: elapsedMinutes % 60,
  };
}

export function formatInteger(value: number): string {
  return new Intl.NumberFormat("en-IN").format(value);
}
