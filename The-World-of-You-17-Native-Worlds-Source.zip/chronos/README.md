# The World of You

> **Current local 17-world implementation:** `3D_IMPLEMENTATION_REPORT.md` and `3D_TRANSFORMATION_AUDIT.md` supersede historical scope counts below. All 17 gifts now have native scene integrations; this is not a claim of complete photoreal art direction. Vercel production remains the earlier deployment. Preview the current built project on port 4182.


> **Latest local refinement:** see `IMPLEMENTATION_REPORT.md` and `WEBSITE_AUDIT.md`. The new letter/postcard changes are implemented locally and previewed on port 4182, but **have not replaced the earlier Vercel production deployment**. Deployment statements below refer to the previous build.


> **Current native-3D build:** see `START_HERE.md` and `FINAL_IMPLEMENTATION_REPORT.md` for current scope, new browser evidence and limitations. Earlier findings/deployment descriptions below are historical. Current core QA: 12/12 pass; final native rose/crown/portal QA: 3/3 pass. No production deployment of this transformation has occurred.


A cinematic, scroll-linked birthday storybook for Bhumi. The experience begins with an invitation and travels through twelve connected rooms while the existing chapters, controls and natural document scrolling remain intact.

**Stack:** React 19 · TypeScript · Vite · GSAP/ScrollTrigger · `react-pageflip` · custom CSS. No WebGL runtime or new 3D dependency is used. The Gift Atelier contains 17 independently openable and replayable experiences. Playfair Display, Cormorant Garamond, DM Sans and Caveat are self-hosted locally.

## Run locally

```bash
npm ci
npm run dev
```

Build and preview the production bundle:

```bash
npm run build
npm run preview
```

Vite dev and preview servers bind to `0.0.0.0` for sandbox/preview hosting.

## Scene order

1. Invitation Room
2. Birthday Garden
3. Scrapbook
4. Memory Observatory
5. Letter Room
6. Memory Gallery
7. Wish Garden
8. Gift Atelier
9. Music Lounge
10. Future Postcards
11. Birthday Ballroom
12. Finale

The fixed decorative stage is driven by native document scroll. Text and interactions stay in the semantic chapter components. Only the current and neighboring scene art is eligible to load; other environments use CSS atmosphere/depth layers. The stage uses GSAP/ScrollTrigger when standard motion is allowed and a CSS/IntersectionObserver fallback under reduced motion or animation-load failure.

## Existing interactions retained

- Invitation envelope, open/skip flow, replay, chapter index and reading progress.
- Scrapbook page-flip controls, keyboard arrows and fallback.
- Verified-date timepiece, letter archive and empty real-photo mounts.
- Selectable birthday wishes and 17 distinct gift experiences, all independently accessible, replayable and tracked in local storage.
- Opt-in local music player (paused/no autoplay), speculative future postcards, candle/wish/blow cake ritual, and finale replay.

## Code map

- `src/scenes/sceneCatalog.ts` — stable scene IDs, chapter anchors, art and transition presets.
- `src/scenes/SceneExperience.tsx` — twelve-layer stage, adjacent-art loading, parallax/crossfade lifecycle, reduced-motion and CSS fallback.
- `src/styles/sceneSystem.css` — environment palettes, readable surfaces, depth, mobile focal points and reduced-motion rules.
- `src/App.tsx` — composition root, active chapter/progress, deep-hash landing and invitation/garden hash synchronization.
- `src/world/*.tsx` — chapter content and component-owned interactions.
- `src/world/GiftRoom.tsx` / `GiftExperiences.tsx` — 17 gift experiences, isolated replayable interactions and safe local progress.
- `src/content/chronosContent.ts` — verified dates, source copy, wishes, letters, audio/gallery slots and postcards.
- `src/content/giftsContent.ts` — gift definitions and clearly empty owner-editable personal-copy slots.
- `src/styles/designTokens.css`, `global.css`, `premium.css`, `giftAtelier.css` — tokens, responsive editorial styles and gift-specific visuals.
- `public/assets/` — local illustrations, self-hosted fonts and intentionally empty owner-media folders.
- `docs/screenshots/` — production baseline and scene captures; `docs/screenshots/gifts/` contains one capture for each gift.

## Personal-content and media rules

The source establishes the names **Bhumi** and **Rudra**, first connection **11 May 2025**, proposal **17 July 2025**, and birthday **17 November** (year unspecified). The time counter uses the start of 11 May 2025 in `Asia/Kolkata`; it does not imply a private hour or conversation.

No personal photographs or audio were supplied. Six gallery mounts and three audio entries therefore remain explicitly empty. No AI faces, synthetic “memories,” voice notes or invented promises are used. Four generated landscapes are labeled as speculative postcards, not trips or shared events. Unfilled letters and gift messages remain empty/editable.

To personalize the site:

1. Edit verified chapter/source copy in `src/content/chronosContent.ts`; edit the separate gift names and personal-copy slots in `src/content/giftsContent.ts`.
2. Add only owner-supplied photographs to `public/assets/gallery/` with accurate alt text and captions.
3. Add only owner-provided or appropriately licensed local audio to `public/assets/audio/`, then set the matching `src`. Preserve opt-in/no-autoplay behavior.
4. Do not present generated art as a personal photograph, memory, or real shared event.

## QA and project documentation

- [`PROJECT_AUDIT.md`](PROJECT_AUDIT.md) — pre-implementation repository/live-site audit.
- [`DESIGN_SYSTEM.md`](DESIGN_SYSTEM.md) — palette, typography, responsive and motion rules.
- [`SCENE_ARCHITECTURE.md`](SCENE_ARCHITECTURE.md) — scene ownership, IDs, transitions, fallback and lifecycle.
- [`ASSET_GENERATION_GUIDE.md`](ASSET_GENERATION_GUIDE.md) — prompts, asset policy and budgets.
- [`ANIMATION_SPECIFICATION.md`](ANIMATION_SPECIFICATION.md) — scroll progress, depth motion and reduced-motion behavior.
- [`ASSET_MANIFEST.md`](ASSET_MANIFEST.md) — shipped assets, licenses, empty media slots and final screenshots.
- [`PERFORMANCE_REPORT.md`](PERFORMANCE_REPORT.md) — measured production chunks/assets and limits.
- [`ACCESSIBILITY_REPORT.md`](ACCESSIBILITY_REPORT.md) — keyboard, labels, focus, reduced motion and testing limitations.
- [`GIFT_ATELIER_SPECIFICATION.md`](GIFT_ATELIER_SPECIFICATION.md) — the seventeen distinct gift experiences and their content/media gates.
- [`GIFT_CONTENT_GUIDE.md`](GIFT_CONTENT_GUIDE.md) — owner-editable fields and personal-content rules.
- [`AUDIO_IMPLEMENTATION.md`](AUDIO_IMPLEMENTATION.md) — local-only opt-in audio behavior and missing media status.
- [`FINAL_QA_REPORT.md`](FINAL_QA_REPORT.md) — scene baseline, local QA scope and existing deployment smoke status.
- [`GIFT_QA_REPORT.md`](GIFT_QA_REPORT.md) — current 17-experience build, responsive, interaction, keyboard, storage, reduced-motion and screenshot results.
- [`PROJECT_PROGRESS.md`](PROJECT_PROGRESS.md) — implementation status, production boundary and remaining security/deployment gates.
- [`SOURCE_RECONSTRUCTION.md`](SOURCE_RECONSTRUCTION.md) — available source boundary and verified facts.

No formal axe/WCAG certification, screen-reader session, or real-device GPU/memory profile is claimed; see the QA reports for precise scope.

## Source boundary

The requested canonical ZIP was not present in the workspace. The current React/Vite project is a transformation of the available project/reference materials, not a claimed byte-for-byte edit of a missing archive. See `SOURCE_RECONSTRUCTION.md` and `docs/source-reference/`.

## Deployment status

The cinematic twelve-scene release is live on the Vercel production alias [the-world-of-you-birthday-storybook.vercel.app](https://the-world-of-you-birthday-storybook.vercel.app/). Current deployment: `dpl_9QT11nqNWa6tDXHyNk9c3AYoUMjU` (**READY / PROMOTED**, production). [Direct deployment URL](https://the-world-of-you-birthday-storybook-4ibr1qnh1.vercel.app/).

The deployed twelve-scene release returned HTTP 200 in smoke tests; the page rendered all twelve scene layers, loaded the active scene art without broken images, and a fresh `#timepiece` deep link selected the Observatory. No browser errors, HTTP errors, or failed requests were observed. The latest Gift Atelier audio/ballroom updates are deployed as **preview only**: `dpl_5gXRjLs1zbJo1eTENg8UxVNz8CR2` (**READY / STAGED**) at [the preview URL](https://the-world-of-you-birthday-storybook-7ythm9x51.vercel.app/). The Vercel build passed (2,092 modules; 4.05 seconds), but access protection redirected the hosted page check to sign-in, so hosted interaction testing was not possible. The production alias remains unchanged; no production promotion occurred. See `QA_REPORT.md`, `FINAL_QA_REPORT.md`, and `PROJECT_PROGRESS.md`.
