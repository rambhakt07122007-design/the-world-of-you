# Project documentation

- `source-reference/` preserves supplied specification/reference PDFs and extracted text; those materials describe an earlier CHRONOS baseline and do not override the current **The World of You** direction.
- `../SOURCE_RECONSTRUCTION.md` explains that the canonical ZIP was missing and defines the reconstruction boundary.
- `../PROJECT_AUDIT.md` records repository findings and the pre-implementation audit.
- `../DESIGN_SYSTEM.md`, `../SCENE_ARCHITECTURE.md`, and `../ANIMATION_SPECIFICATION.md` document the design, twelve-scene ownership, scroll motion and reduced-motion fallback.
- `../ASSET_GENERATION_GUIDE.md`, `../ASSET_GENERATION_BACKLOG.md`, and `../ASSET_MANIFEST.md` cover generated room art, source/usage constraints, optimized assets, fonts and owner-media slots.
- `../COMPONENT_INVENTORY.md` and `../IMPLEMENTATION_CHECKLIST.md` map the chapter/component responsibilities and implementation gates.
- `../GIFT_ATELIER_SPECIFICATION.md`, `../GIFT_CONTENT_GUIDE.md`, and `../AUDIO_IMPLEMENTATION.md` define the 17 gift experiences, editable content gates and audio rules.
- `../GIFT_QA_REPORT.md` records local build, interaction, viewport, keyboard, motion, persistence and screenshot results for Gift Atelier.
- `../PROJECT_PROGRESS.md` records the deployed twelve-scene baseline, local gift expansion, QA status and credential cleanup.
- `../PERFORMANCE_REPORT.md` and `../ACCESSIBILITY_REPORT.md` record tested local scope and limitations.
- `../FINAL_QA_REPORT.md` is the authoritative local and hosted browser/build/interaction report. `../QA_REPORT.md` summarizes the current production deployment and smoke test.
- `screenshots/` contains the pre-scene production baseline and refreshed local screenshots for all twelve cinematic scenes plus representative mobile views.
