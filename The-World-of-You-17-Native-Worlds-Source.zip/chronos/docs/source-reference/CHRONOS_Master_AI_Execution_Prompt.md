# CHRONOS — Master AI Execution Prompt

> Attach this document/PDF and the actual extracted project ZIP/folder to your coding agent. The ZIP is the source code; this document is the specification.

## Mission And Source-Of-Truth Rules

You are the senior creative technologist, product designer, motion designer, 3D art director, frontend architect, and QA engineer responsible for transforming the supplied CHRONOS website repository into a finished, cinematic birthday experience for Bhumi.

The supplied ZIP is the actual working codebase. The accompanying Markdown guide and this PDF are the product/design specification. Read every page of this PDF from beginning to end before editing. Do not skim headings and start coding. Extract the requirements into an internal implementation checklist, map each requirement to repository files, and then execute the work in the repository.

Treat the PDF like a structured project archive: parse all sections, tables, constraints, file paths, visual requirements, and acceptance criteria. If a separate source-code PDF is supplied, use its file headings and path labels to understand the code, but prefer the real extracted ZIP files as canonical source. Do not assume a PDF is an executable ZIP or blindly paste its entire text into one file. Reconstruct code only when a real source file is missing, and verify reconstructed files against the original project and build.

Do not answer with only advice, a mockup, or a list of suggestions. Make changes directly in the project files, create required assets where the environment supports image/3D generation, integrate them, run the app, and validate the result. Never claim a feature works unless you have run or inspected it.

## The Owner'S Creative Vision

The website should not look like a common birthday template. It should feel like a premium interactive product film and a secret world built around one relationship.

The central visual metaphor is an ancient clock tower that secretly contains an advanced extraterrestrial time machine. Outside: old stone architecture, brass, Roman numerals, mechanical gears, a pendulum, fog, dust, rain-washed stone, and warm windows. Inside: precise holographic rings, cyan energy, orbital diagrams, glass interfaces, alien-inspired symbols, data pulses, and a living timeline. The contrast between ancient craft and impossible technology is the identity of the experience.

The second major visual metaphor is a physical memory archive. Memories should look like tactile paper objects: handwritten notes, aged parchment, notebook pages, folded letters, wax seals, ink stamps, brass clips, archival labels, old photographs in museum mounts, and documents recovered from a time machine. A user should feel that each note is a physical artefact with a history—not just a card in a web grid.

The relationship clock must show elapsed time from the known first-connection date and connect that time to the story. It should be an actual useful interface, not just a decorative clock. Its antique face and moving hands should coexist with modern alien-tech readouts and selectable date nodes.

The complete website should feel like a carefully directed film: an opening shot, controlled reveals, scene changes, intimate details, a rising emotional arc, and a strong birthday finale. Use cinematic restraint. Avoid random effects, overdecorated layouts, generic stock romance imagery, and a purple/pink template look.

## Canonical Facts — Never Invent

The current project content identifies these facts:
• 11 May 2025 — first connection.
• 17 July 2025 — proposal.
• 17 November — Bhumi's birthday; the year is not specified in the source content.
• Names used in the project: Bhumi and Rudra.

Preserve these facts exactly unless the owner supplies a correction. Do not invent dates, messages, events, private jokes, photos, voice recordings, family details, or promises. Do not fabricate a birthday year or countdown target. Future postcards must be clearly labelled as dreams, hopes, or imagined future scenes—not historical facts or guaranteed outcomes.

Never generate a fake photograph of Bhumi or Rudra. AI may create environmental artwork, architecture, abstract objects, props, textures, symbolic illustrations, and non-human 3D objects. Real people/photos must come from the owner. Never present generated art as an authentic relationship memory.

## Repository Audit Before Coding

Start by listing the repository tree and reading package.json, README.md, all design/research/asset Markdown documents, src/App.tsx, src/content/chronosContent.ts, all chapter components, shared components, hooks, styles, and utility files. Inspect the existing ten PNG assets under public/assets/3d/ before creating replacements.

Run npm install only if needed, then npm run dev and npm run build. Capture the baseline errors and visual issues. Inspect the running page at desktop and mobile dimensions. Check console errors, missing assets, broken links, navigation targets, and the existing interaction model.

Do not delete working chapters or rewrite the whole project without first understanding it. Preserve useful content, accessibility hooks, reduced-motion logic, audio opt-in behavior, and the central editable content architecture. The current `src/content/chronosContent.ts` is designed as the main personal-content editing location.

## Full Theme Replacement — Visual System

Replace the old visual identity comprehensively. Do not merely add a few cyan glows on top of the previous theme. Create a consistent new art direction across hero, navigation, chapter backgrounds, paper surfaces, cards, buttons, typography, overlays, cursor, loading sequence, and footer.

Use this palette as the base:
• Midnight navy #080F1C
• Deep blue #101B2B
• Antique brass #B18A55
• Champagne gold #D9BD82
• Holographic cyan #6EDCE8
• Muted teal #376D75
• Parchment #E8D8B8
• Ink #342A23
• Warm ivory #F5EBDD

Use antique brass and champagne highlights for mechanical/tower elements; cyan/teal for alien-tech interfaces; parchment/ink/ivory for notes and letters. Do not force all chapters into the same dark background. Give the Memory Archive its own warm paper environment, the Observatory its own celestial dome, the Music Chamber its own intimate listening space, and the Finale a clear visual crescendo.

Typography: pair a characterful editorial serif for emotional titles with a highly legible modern sans-serif for UI and technical labels. Handwriting may be used sparingly for annotations or signatures. Use hierarchy, whitespace, controlled line lengths, and strong contrast. Avoid illegible decorative fonts for important information.

## Opening — The Clock Tower

Create an unforgettable first viewport. It should feel like a film opening, not a landing-page template. Show a monumental old clock tower in a night landscape. The tower face contains Roman numerals and brass hands; subtle cyan rings and a faint holographic mechanism reveal that the clock is not ordinary. Add atmospheric fog, slow-moving clouds, restrained particles, a few lit windows, and a distant sense of scale.

The title CHRONOS — THE ARCHIVE OF US should appear with editorial precision. Keep the emotional copy concise. Add one strong action such as “Enter the archive”. The initial loading/preloader must be short, skippable, accessible, and never trap the user. The sound remains off until explicitly enabled.

Generate a custom hero background/illustration if image generation is available. Prefer layered assets that can be animated independently: tower silhouette, clock face, fog, light, and foreground detail. If a 3D asset is generated, optimize it and provide a static/mobile fallback. Do not use generic stock photos.

## The Relationship Clock — Chrono Core

Upgrade the existing ClockTower and ChronoCore into the signature interaction.

Visual construction:
1. Outer antique tower-clock bezel, aged brass and dark stone.
2. Roman numeral dial with precise ticks and elegant hands.
3. Mechanical gear train and a visible pendulum.
4. Inner holographic rings, orbital traces, fine cyan circuits, and alien-tech readouts.
5. Selectable date nodes with clear focus/hover/touch states.
6. A live elapsed-time display, updating accurately from 11 May 2025.

The elapsed counter should calculate from a timezone-safe date/time configuration. Because the exact time of first connection is not known, do not imply second-level historical precision. Use an owner-configurable date/time; if only the date is known, label the counter “time since 11 May 2025” and calculate from the start of that local calendar date, with a visible note or settings comment explaining the assumption. Do not hard-code a fabricated time of day.

When a known milestone is selected, animate the clock hands and rings toward that node, then open its real record. Include reset/return controls. Empty nodes must be labelled “unindexed” or “add a real memory”; do not populate them with invented events. Ensure the clock remains usable on touch devices and with keyboard navigation.

## Memory Archive — Paper Notes And Letters

This chapter is a central emotional feature. Make it look like a carefully curated physical archive, not a generic card grid.

Create a library of varied paper artefacts:
• aged parchment sheets with subtle fibres and deckled edges;
• notebook pages with restrained ruled lines;
• folded notes with visible creases;
• sealed envelopes with wax seals;
• archival cards with date, record ID, and status stamp;
• clipped photographs in museum mounts;
• handwritten margin notes and tiny ink marks.

Interactions:
• click/tap a note to unfold or expand it;
• open a letter with a deliberate seal-break sequence;
• reveal a hidden message under a folded flap;
• allow page turning only if it stays smooth and readable;
• support Escape, focus management, and close controls for overlays.

Paper textures must remain subtle. Body text must have strong contrast and comfortable line length. On mobile, do not rely on hover. If no real content exists, show a tasteful editable placeholder and clearly indicate it is awaiting a real memory.

## Chapter-By-Chapter Experience

Keep the 12 existing narrative chapters and refine them into one coherent world:

01 Chrono Core — living relationship clock and date nodes.
02 Observatory — star map plotted from real milestone dates; stars open true records.
03 Timeline — a physical/mechanical time rail with known events and editable empty slots.
04 Memory Archive — paper notes, letters, wax seals, archival records.
05 Memory Gallery — user-supplied photos displayed as museum plates; elegant placeholders if none supplied.
06 Wish Garden / Transmission — wishes represented as seeds/light transmissions; do not claim wishes are real events.
07 Recovered Fragments — small true details; empty/editable content until supplied.
08 Secret Chamber — exactly 17 doors/surprises, one for the 17th birthday day motif. Each door may reveal user-provided content; no invented personal facts.
09 Music Chamber / Bhumi FM — tasteful player, optional licensed music or owner-provided audio, visible play/pause and volume controls; no autoplay.
10 Future Archives — future postcards clearly marked “possible future / a hope”, not facts.
11 Last Letter — intimate letter, paper/envelope/wax-seal presentation.
12 Birthday Portal — emotional finale, cinematic lighting, celebratory objects, final birthday message, controlled particle bloom.

The order and naming should stay consistent across content config, component map, navbar, chapter IDs, and anchor targets. Preserve existing component files where practical; refactor only when the result is clearer and tested.

## Image And Object Generation — Required Asset Workflow

Do not leave the experience dependent on emoji, generic gradients, or placeholder rectangles. Produce a coherent asset pack where custom visuals materially improve the design.

First inspect existing assets and create an asset-gap list. For each needed image/object, document:
• asset name and destination path;
• chapter/use case;
• aspect ratio and approximate resolution;
• transparent or opaque background;
• material, lighting, camera angle, palette;
• whether it must be layered/animated;
• file-size budget and fallback.

Generate assets where the environment supports image generation. If image generation is unavailable, create `ASSET_GENERATION_BACKLOG.md` with precise prompts ready for a generator—do not pretend images were generated.

Priority asset concepts:
A. Hero tower: ancient stone clock tower at night, cinematic wide composition, brass clock, subtle cyan alien energy, no text, no people.
B. Clock core: isolated antique brass clock mechanism with Roman numerals, layered holographic rings, cyan energy traces, transparent background if possible.
C. Gear/pendulum object set: matching brass gears, pendulum, clock hands, precision components.
D. Paper set: parchment sheet, notebook page, folded note, envelope, wax seal, archival stamp, paperclip; consistent top-down/three-quarter lighting.
E. Observatory: brass telescope, celestial dome, antique star chart, glowing constellations.
F. Secret vault: coherent family of 17 unique sealed door/token illustrations; distinct numbers/marks without generated gibberish text.
G. Music room: vintage gramophone/headphones fused with restrained futuristic audio waveform elements.
H. Finale: ornate birthday cake, gift object, portal frame, warm gold/cyan light, tasteful celebration.
I. Ambient scene layers: fog, dust, starfield, subtle stone texture, parchment fibre texture.

All generated images must have no watermark, no random readable text, no logos, and no fake people. For interface text and labels, render real HTML/SVG text in the app, not text baked into generated images. Use transparent backgrounds for isolated objects. Use WebP/AVIF for photographic/large raster backgrounds where supported; keep PNG for transparency when appropriate. Compress and lazy-load below-the-fold assets.

## 3D Objects And Scene Technology

Use the simplest technology that achieves the quality target. CSS/SVG can create gears, dials, simple holographic rings, and small decorative objects. Use Three.js/React Three Fiber or a Spline embed only for a genuinely valuable 3D scene. Avoid installing multiple overlapping render stacks.

If using 3D:
• lazy-load the scene and its assets;
• cap device pixel ratio;
• use compressed GLB/glTF where possible;
• limit lights, shadows, geometry, and particle counts;
• provide a poster/static fallback;
• disable or simplify 3D on low-power/mobile/reduced-motion contexts;
• avoid blocking first contentful paint;
• check memory and GPU usage;
• provide meaningful accessible text for the scene.

A 3D object must have a clear purpose and polished materials/lighting. Do not scatter unrelated floating objects everywhere.

## Motion, Sound, And Scroll

Use motion as storytelling. Slow gear rotation, pendulum movement, paper unfolding, date-node selection, star connections, and portal activation should have clear cause and effect. Use short high-quality transitions rather than constant motion.

GSAP ScrollTrigger may be used for scene reveals, pinning a limited feature panel, and controlled timeline sequences. Keep native scrolling; do not hijack the entire page. If adding GSAP, install and configure it explicitly. Do not assume it is in the current dependencies. Avoid combining several scroll libraries.

Respect `prefers-reduced-motion`. Use IntersectionObserver or existing hooks for lightweight reveals. Do not animate every paragraph. Sound must be opt-in, with a visible toggle and persistent user preference if practical. No autoplay music or surprise audio. Provide pause/mute controls.

## Responsive Design And Accessibility

Design desktop first for cinematic composition, then deliberately adapt to tablet and mobile. On mobile:
• collapse complex tower scenes to a lightweight composition;
• keep text readable and controls reachable;
• make paper notes tap-to-open;
• replace hover-only interactions with click/touch;
• avoid horizontal overflow;
• maintain stable layout while images load;
• reduce particles and expensive animation;
• ensure the clock remains legible.

Accessibility:
• semantic headings and landmarks;
• keyboard-operable controls;
• visible focus rings;
• accessible names for icon-only buttons;
• sufficient text/background contrast;
• dialog focus management and Escape-to-close;
• meaningful alt text for informative images;
• decorative visuals marked aria-hidden;
• reduced-motion support;
• no flashing or strobing effects.

## Implementation Order — Do Not Build Everything Blindly

Work in controlled stages:

Stage 1 — Audit and baseline. Run the existing project; inspect all code and visuals; note errors.
Stage 2 — Design tokens and global shell. Replace theme foundations and typography; confirm all chapters inherit the new system.
Stage 3 — Hero/tower. Create the opening cinematic scene and responsive fallback.
Stage 4 — Chrono Core. Implement accurate elapsed-time display and working milestone selection.
Stage 5 — Paper Archive. Build reusable document artefacts and interactions.
Stage 6 — Remaining chapters. Refine each chapter with its own environment and narrative role.
Stage 7 — Asset production. Generate, integrate, optimize, and document custom assets.
Stage 8 — Motion/audio. Add controlled transitions, sound opt-in, and reduced-motion behavior.
Stage 9 — QA. Test desktop, tablet, mobile, keyboard, audio, broken assets, and build.
Stage 10 — Handover. Update README and provide changed-file list, asset manifest, run commands, and known limitations.

After each stage, run `npm run build` and fix errors before continuing. Do not defer all testing until the end.

## Acceptance Criteria — Definition Of Done

The work is not complete until all of the following are true:
1. The old theme has been replaced comprehensively; the site reads as CHRONOS, not a reskinned template.
2. The ancient tower + alien-tech visual metaphor is unmistakable and coherent.
3. The relationship clock displays elapsed time from the known first-connection date without pretending to know an unknown time of day.
4. The paper archive looks and behaves like tactile documents.
5. All 12 chapters exist and navigation targets work.
6. 17 Secret Chamber entries/doors are present; content is editable and not fabricated.
7. AI-generated assets are used only for non-personal artwork; real photos remain user-supplied.
8. Future content is labelled speculative.
9. Audio is opt-in.
10. Reduced-motion and mobile fallbacks work.
11. No broken image paths, missing imports, or console-breaking runtime errors.
12. `npm run build` succeeds.
13. README and asset manifest are updated.
14. The agent reports what it actually changed and what remains incomplete.

If a requirement cannot be implemented because the environment lacks image generation, browser preview, or a dependency, state that limitation honestly and provide a ready-to-use backlog/prompt. Never fabricate tool execution or test results.

## Final Instruction To The Agent

Now execute the transformation in the supplied repository. Start by reading the whole specification and auditing the codebase. Then implement in the staged order above. Make the strongest visual decisions you can while respecting the canonical facts and the owner's creative vision. Generate the missing environmental artwork and 3D-style objects wherever the available tools support it, integrate the assets into real components, and validate every interaction.

Do not stop after producing a plan. Do not return only a homepage mockup. Do not replace personal content with invented copy. Deliver a working, coherent, responsive website and a concise engineering handover with the build result, changed files, new assets, and known limitations.

