# CHRONOS — The Archive of Us
## Project handover, setup guide, code map, and AI implementation notes

> **Core idea:** an intimate relationship story presented as a cinematic archive housed inside an ancient clock tower fused with advanced alien technology.  
> **Tagline:** “Every second remembers us.”

This guide is generated from the supplied `bhumi-birthday-website-prd.zip`. It documents the actual files present in that archive and gives a practical route for running, reviewing, and upgrading the project.

---

## 1. What is in the ZIP

The archive contains a React + TypeScript + Vite website with 12 narrative chapters, reusable interface components, CSS design layers, a central editable content file, and ten transparent/isolated 3D-style PNG assets.

### Main structure

```text
bhumi-birthday-website-prd/
├── README.md
├── DESIGN_AUDIT.md
├── DESIGN_RESEARCH.md
├── DESIGN_SYSTEM.md
├── WORLD_BUILDING.md
├── ASSET_GUIDE.md
├── IMAGE_GENERATION_PROMPTS.md
├── REDESIGN_REPORT.md
├── RESEARCH_REPORT.md
├── COMPONENT_INVENTORY.md
├── package.json
├── index.html
├── vite.config.ts
├── tsconfig.json
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   ├── app/ExperienceContext.tsx
│   ├── chapters/
│   ├── components/
│   ├── content/chronosContent.ts
│   ├── hooks/
│   ├── styles/
│   └── utils/
└── public/assets/3d/
    ├── star.png
    ├── moon.png
    ├── flower.png
    ├── cake.png
    ├── gift.png
    ├── heart.png
    ├── envelope.png
    ├── headphones.png
    ├── lock.png
    └── butterfly.png
```

### Stack detected from `package.json`

- React **19.2.6**
- TypeScript **5.9.3**
- Vite **7.3.2**
- Tailwind CSS **4.1.17** with `@tailwindcss/vite`
- `lucide-react`, `clsx`, and `tailwind-merge`
- Vite single-file plugin is installed

The current package scripts are:

```bash
npm run dev
npm run build
npm run preview
```

**Important:** GSAP, Three.js, React Three Fiber, Lenis, and Spline are not currently listed as dependencies in the supplied `package.json`. Do not assume they are already installed. An AI coding agent must inspect the existing setup and add dependencies deliberately only when they are genuinely needed.

---

## 2. Run the project locally

1. Extract the ZIP into a normal project folder.
2. Open that folder in VS Code.
3. Open the integrated terminal in the project root.
4. Check that Node.js and npm are installed:

```bash
node -v
npm -v
```

5. Install dependencies:

```bash
npm install
```

6. Start the development server:

```bash
npm run dev
```

7. Open the local URL printed by Vite, commonly `http://localhost:5173`.
8. Before sharing/deploying, run:

```bash
npm run build
npm run preview
```

If installation fails, inspect the exact error first. Do not randomly delete the lockfile or replace the project's dependency versions.

---

## 3. The creative direction — what this website should become

### CHRONOS: ancient architecture × extraterrestrial precision

The experience should feel like discovering a secret machine hidden inside a centuries-old clock tower. From outside, it is stone, brass, weather, fog, and a slow pendulum. Inside, the clock is an advanced time engine: concentric holographic rings, luminous cyan circuits, orbital tracks, glass interfaces, subtle alien glyphs, and precise mechanical movement.

The romance should come from the real story and the objects that preserve it—not from generic hearts, random quotes, or excessive pink/purple gradients.

### Visual palette

| Role | Suggested colour |
|---|---|
| Midnight base | `#080F1C` |
| Deep blue | `#101B2B` |
| Antique brass | `#B18A55` |
| Champagne gold | `#D9BD82` |
| Holographic cyan | `#6EDCE8` |
| Muted teal | `#376D75` |
| Parchment | `#E8D8B8` |
| Ink | `#342A23` |
| Warm ivory | `#F5EBDD` |

Use parchment and warm ivory for paper artefacts; midnight, brass, and cyan for the tower and machine. Avoid one flat colour treatment across every chapter.

### Paper-note visual language

The Memory Archive should contain physical-feeling documents:
- aged paper sheets with imperfect edges and subtle fibres;
- notebook pages with restrained ruled lines;
- folded letters, paper clips, brass corners, ink stamps, wax seals;
- handwritten annotations and margin notes;
- photographs presented as archival plates, not generic image tiles;
- date, archive ID, record status, and a small index label.

Interaction ideas:
- click/tap a document to unfold it;
- open a sealed letter with a deliberate wax-seal animation;
- reveal a handwritten note beneath a folded corner;
- hover/focus to lift a paper card slightly;
- flip between front/back only when it remains readable on mobile.

Keep text contrast high. Texture must not make the writing difficult to read.

### The clock that tracks the relationship

The clock must be more than a decorative SVG. It should become the central interactive object:
- an antique tower clock face with Roman numerals and brass hands;
- exposed mechanical gears and a pendulum;
- an inner holographic ring and alien-tech orbital markings;
- a digital readout that calculates elapsed time from the first connection date;
- selectable memory nodes that rotate/animate the dial and open a real archive record;
- a clearly labelled “time since first connection” counter.

Known canonical milestones in the current content:
- **11 May 2025** — first connection.
- **17 July 2025** — proposal.
- **17 November** — Bhumi's birthday (year not specified in the source content).

Do not invent additional relationship events. Empty slots should remain editable placeholders until the user supplies real memories. Do not infer the birthday year or use a fake countdown target.

---

## 4. The 12 story chapters already represented in the code

The current `src/App.tsx` maps these chapter IDs to React components:

| Order | Chapter | Component | Purpose |
|---:|---|---|---|
| 01 | Chrono Core | `ChronoCore.tsx` | Interactive time mechanism and selectable moments |
| 02 | Observatory | `ConstellationChapter.tsx` | Star chart plotted from real dates |
| 03 | Time Machine / Timeline | `StoryTimeline.tsx` | Relationship milestone rail |
| 04 | Memory Archive | `Scrapbook.tsx` | Paper notes, letters, and sealed records |
| 05 | Memory Gallery | `MemoryMuseum.tsx` | User-supplied photographs as archival plates |
| 06 | Transmission / Wish Garden | `WishGarden.tsx` | Wishes released into the time stream |
| 07 | Recovered Fragments | `MirrorChapter.tsx` | Small true details and fragments |
| 08 | Secret Chamber | `SecretVault.tsx` | 17 sealed doors/surprises |
| 09 | Music Chamber | `BhumiFM.tsx` | Music and optional voice-note experience |
| 10 | Future Archives | `FuturePostcards.tsx` | Clearly speculative future postcards |
| 11 | Last Letter | `LetterScene.tsx` | Personal letter in a sealed envelope |
| 12 | Birthday Portal | `FinaleScene.tsx` | Cinematic birthday finale |

The code's chapter metadata and content should stay consistent. If a chapter is renamed or reordered, update the content config, navigation targets, chapter component mapping, and any chapter-specific visual state.

---

## 5. Where to edit the personal content

**Primary content file:** `src/content/chronosContent.ts`

The file itself explicitly states that it is intended to be the main file Rudra edits. It contains:
- her/his names and site title;
- navigation labels;
- canonical dates;
- intro copy;
- chapter names and descriptions;
- Chrono Core nodes;
- constellation records;
- timeline milestones;
- other chapter copy, secrets, music, postcards, and letter content.

### Content integrity rules

1. Preserve the canonical dates above unless the user explicitly corrects them.
2. Never fabricate memories, quotes, messages, photos, voice notes, or events.
3. Empty records are intentional and should remain visibly editable.
4. Future postcards must be framed as hopes, dreams, or imagined possibilities—not facts or promises.
5. Personal photos must be supplied by the user. Do not generate synthetic photos and present them as real memories.
6. Do not invent a birthday year or a countdown target.

---

## 6. Asset generation and placement

The archive already includes ten visual assets in `public/assets/3d/`. Review them before generating replacements. Avoid duplicating assets that already work.

### Where to place new assets

Suggested structure:

```text
public/assets/
├── 3d/             # isolated 3D objects / transparent renders
├── tower/          # tower hero, stone architecture, clock closeups
├── paper/          # parchment, notebook, letter, wax-seal textures
├── gallery/        # real user-provided photos only
├── audio/          # licensed music and user-provided voice notes
└── ui/             # small decorative textures and interface elements
```

### Generate assets only where they add real value

Potential custom assets:
- hero: ancient clock tower at night with an illuminated alien mechanism;
- Chrono Core: antique brass clock face fused with cyan holographic rings;
- paper archive: parchment sheets, sealed envelope, wax seal, archival stamps;
- Observatory: star map, brass telescope, celestial dome;
- Secret Chamber: 17 distinct but visually coherent sealed doors/tokens;
- finale: birthday portal, cake, gift, warm light, and a controlled burst of particles.

For generated assets, specify:
- intended placement and aspect ratio;
- transparent background when the object must float independently;
- consistent lighting, material language, and palette;
- no embedded text, logos, watermark, or fake UI;
- no people or invented personal photographs;
- export format and destination path.

Use CSS/SVG for simple shapes and lightweight ornaments. Use raster/3D assets for visually distinctive hero objects. Do not make every small icon a heavy 3D render.

---

## 7. Motion and interaction principles

- Use cinematic scene transitions, but keep normal browser scrolling.
- Do not hijack scroll or trap keyboard/touch users.
- Motion should explain the story: gears respond to date selection, papers unfold, seals open, stars connect, the portal activates.
- Use restrained parallax, slow ambient movement, and a few high-impact transitions.
- Respect `prefers-reduced-motion`.
- Provide a visible sound toggle; sound must be opt-in and never autoplay unexpectedly.
- Provide keyboard focus states and accessible labels for interactive controls.
- Mobile should have simplified effects and touch-friendly targets.

If adding GSAP ScrollTrigger, Three.js, React Three Fiber, Spline embeds, or a smooth-scroll library, verify compatibility with the installed Vite/React setup and provide a fallback. Do not install several overlapping animation libraries.

---

## 8. Code map

| Path | Responsibility |
|---|---|
| `src/App.tsx` | App shell, chapter registry, global layers, scene tint |
| `src/main.tsx` | React entry point |
| `src/app/ExperienceContext.tsx` | Shared experience state |
| `src/content/chronosContent.ts` | Editable copy, dates, records, and chapter content |
| `src/chapters/` | Individual narrative scenes |
| `src/components/` | Reusable UI, clock tower, navigation, transitions |
| `src/hooks/` | Reusable view and reduced-motion hooks |
| `src/styles/` | Global styles, tokens, scenes, motion, premium layers |
| `src/utils/ambientAudio.ts` | Ambient audio helpers |
| `src/utils/storage.ts` | Local persistence helpers |
| `public/assets/3d/` | Existing isolated visual assets |

---

## 9. AI coding-agent workflow

Give the AI the extracted project folder and the separate master prompt PDF. The AI should:

1. Read this Markdown guide and every relevant existing project document.
2. Inspect the entire repository before editing.
3. Run the existing app and record baseline build/runtime errors.
4. Audit the actual rendered experience at desktop and mobile sizes.
5. Map each requested design change to exact files.
6. Create an asset plan before generating or importing images/objects.
7. Generate only missing assets; do not replace real personal photos with AI images.
8. Implement in small, testable phases.
9. Run `npm run build` after each major phase.
10. Fix regressions rather than hiding or bypassing them.
11. Deliver a file-change summary, asset manifest, setup instructions, and known limitations.

### Mandatory quality gates

- `npm run build` succeeds.
- No broken image paths or missing imports.
- No placeholder copy is accidentally presented as a real memory.
- No fake relationship events or invented personal photos.
- Mobile layout is usable at narrow widths.
- Sound is opt-in.
- Reduced-motion mode works.
- Navigation targets resolve to the correct chapters.
- All important interactions work with keyboard and touch.
- The experience remains performant; large textures and 3D assets are optimized.

---

## 10. Recommended implementation phases

### Phase A — Baseline and repair
Run the project, fix broken imports/assets, inspect the current design, and preserve working features.

### Phase B — Full visual identity replacement
Replace the old theme with the clock-tower/alien-technology art direction. Establish tokens, typography, backgrounds, surfaces, borders, and scene-specific colour systems.

### Phase C — Hero and Chrono Core
Make the tower visually compelling and turn the clock into a functioning relationship-time interface.

### Phase D — Paper Memory Archive
Build tactile document cards, folded notes, wax seals, and readable letter layouts.

### Phase E — Cinematic chapters
Improve the Observatory, Timeline, Gallery, Secret Chamber, Music Chamber, Future Archives, Letter, and Finale as coherent scenes.

### Phase F — Asset production
Generate/place custom tower, clock, parchment, envelope, seal, and scene objects. Optimize formats and sizes.

### Phase G — QA and delivery
Test desktop, tablet, mobile, keyboard, reduced motion, audio, loading, and production build.

---

## 11. Practical warning

A long prompt does not guarantee a good website. The AI must work in the repository, inspect the actual rendered result, and validate each stage. Do not accept a response that merely claims it completed the redesign. Require a successful build and a working local preview.

---

## 12. Original documents included in the ZIP

The source archive also contains the original project documents. Keep them in the repository:
- `README.md`
- `DESIGN_AUDIT.md`
- `DESIGN_RESEARCH.md`
- `DESIGN_SYSTEM.md`
- `WORLD_BUILDING.md`
- `ASSET_GUIDE.md`
- `IMAGE_GENERATION_PROMPTS.md`
- `REDESIGN_REPORT.md`
- `RESEARCH_REPORT.md`
- `COMPONENT_INVENTORY.md`

They are supporting project context, not disposable files.
