# Asset plan and owner-media backlog

## Completed generic artwork

| Asset | Path | Purpose |
|---|---|---|
| Invitation envelope | `public/assets/birthday/invitation-envelope.webp` | Opening still life/detail |
| Birthday garden | `public/assets/backgrounds/birthday-garden.webp` | Birthday Garden scene only; not reused in the finale |
| Writing desk | `public/assets/paper/writing-desk.webp` | Letter-room still life |
| Invitation Room environment | `public/assets/scenes/invitation-room.webp` | Scene-stage background |
| Memory Observatory environment | `public/assets/scenes/memory-observatory.webp` | Scene-stage background |
| Birthday Ballroom environment | `public/assets/scenes/birthday-ballroom.webp` | Scene-stage background |
| Mountain morning | `public/assets/postcards/mountain-morning.webp` | Speculative landscape postcard |
| Sea at blue hour | `public/assets/postcards/sea-blue-hour.webp` | Speculative shoreline postcard |
| Unnamed city | `public/assets/postcards/unnamed-city.webp` | Speculative city postcard |
| Home, whatever shape | `public/assets/postcards/home-whatever-shape.webp` | Speculative cottage postcard |

The invitation, garden, desk and four postcard illustrations were already present in the workspace. The three scene environments were generated as separate generic images, inspected, optimized to WebP and integrated. Dimensions, sizes and provenance are in `ASSET_MANIFEST.md`. These are not photos or depictions of Bhumi or Rudra. The finale uses its distinct CSS dawn/starfield scene.

## Waiting for owner-supplied material (intentionally blank)

- Up to six real photographs with accurate captions/dates for the Polaroid wall.
- Four owner-written letter entries (the supplied birthday-letter draft is retained).
- Real notes/surprises for the 14 gift records without source messages; the three supplied messages are preserved in `src/content/chronosContent.ts`.
- Up to three local audio files with playback rights/consent. The player remains paused by default and never streams or records.
- Optional keepsakes only when provenance and caption are known.

Do not generate synthetic portraits, personal-photo substitutes, fake voice notes, invented shared events, fabricated handwriting or additional promises. Future-postcard scenes are explicitly speculative and should be removed if they do not reflect a real, mutual hope. Further decorative art should remain generic, non-personal, text-free and clearly illustrative.
